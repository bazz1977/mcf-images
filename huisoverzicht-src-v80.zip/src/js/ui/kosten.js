// ===== (v80) € KOSTEN: stroom en water, totaal voor het huis en per verbruiker; aan/uit met de knop '€ Kosten' =====
const kostLbl = (()=>{ const el = document.createElement('div'); el.className = 'label elabel'; el.style.borderColor = 'var(--ok)'; labelsEl.appendChild(el); return el; })();
const KOST_POS = new THREE.Vector3(mx(3.2), H_REST+0.9, mz(D_M/2));   // boven het midden van het huis
function kostTotaal(){
  const gW = energy.grid==null ? null : (GRID_POS_IS_IMPORT ? energy.grid : -energy.grid);
  const stroomDag = energy.impToday==null ? null : energy.impToday*TARIEF.stroom - (energy.expToday||0)*TARIEF.terug;
  const waterDag = WATER.m3Today==null ? null : WATER.m3Today*TARIEF.water;
  const bespaard = WATER.spoelingen*WATER.spoelL/1000*TARIEF.water;
  return {nu:perUur(energy.house), net:gW==null ? null : perUur(Math.max(0,gW)), stroomDag, waterDag, bespaard, totaalDag:(stroomDag??0)+(waterDag??0)};
}
function verbruikers(){   // alles met een vermogen: stekkers, airco's (schatting uit vandaag), warmtepomp, lampen (±6 W per lamp aan)
  const L = [];
  rooms.forEach(r=>r.plugs.forEach(p=>{ if(p.on && (p.w||0) > 0.5) L.push({naam:p.name, waar:r.name, w:p.w}); }));
  Object.values(HP).forEach(u=>{ if((u.v.pin||0) > 0.5) L.push({naam:'Warmtepomp', waar:'Weheat', w:u.v.pin}); });
  const lampen = lampList.filter(l=>l.on && !l.nc).length; if(lampen) L.push({naam:lampen+' lampen', waar:'schatting ±6 W per lamp', w:lampen*6});
  return L.sort((a,b)=>b.w-a.w);
}
function renderKost(){
  const el = $('kostcard'); if(!el) return; el.hidden = !KOST.on; if(!KOST.on) return;
  const k = kostTotaal(), top = verbruikers().slice(0,8);
  const inp = (key, val, stap, eenheid)=> `<label class="sub" style="display:flex;align-items:center;gap:6px">${eenheid} <input type="number" step="${stap}" min="0" value="${val}" data-tarief="${key}" style="width:70px;background:var(--panel2);border:1px solid var(--line);border-radius:6px;color:var(--text);font:inherit;padding:3px 6px"></label>`;
  el.innerHTML = `<p class="eyebrow">Kosten · stroom &amp; water</p>
    <div class="stats">
      <div class="stat"><small>Huis nu</small><strong>${euro(k.nu)}</strong><em> /uur</em></div>
      <div class="stat"><small>Van het net nu</small><strong>${euro(k.net)}</strong><em> /uur</em></div>
      <div class="stat"><small>Stroom vandaag</small><strong>${euro(k.stroomDag)}</strong><em> ${energy.impToday!=null ? fmt(energy.impToday,1)+' kWh' : ''}</em></div>
      <div class="stat"><small>Water vandaag</small><strong>${euro(k.waterDag)}</strong><em> ${WATER.m3Today!=null ? fmt(WATER.m3Today*1000,0)+' L' : 'geen watermeter'}</em></div>
    </div>
    <div class="sub" style="margin-top:8px">Totaal vandaag <b style="color:var(--text)">${euro(k.totaalDag)}</b>${TARIEF.terug>0 && energy.expToday ? ` · teruglevering −${euro(energy.expToday*TARIEF.terug)}` : ''} · regenwater bespaard ${euro(k.bespaard)} (${WATER.spoelingen}× doorgespoeld)</div>
    <p class="eyebrow" style="margin:12px 0 4px">Verbruikers nu</p>
    ${top.map(v=>`<div class="plug" style="grid-template-columns:1fr auto auto"><span>${v.naam}<span style="color:var(--faint)"> · ${v.waar}</span></span><span class="v">${fmtW(v.w)}</span><span class="v" style="color:var(--ok);white-space:nowrap">${euro(perUur(v.w),3)}/u</span></div>`).join('') || '<div class="sub">Niets aan.</div>'}
    <p class="eyebrow" style="margin:12px 0 4px">Tarieven (fictief, aan te passen)</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap">${inp('stroom',TARIEF.stroom,0.01,'€/kWh')}${inp('terug',TARIEF.terug,0.01,'terug €/kWh')}${inp('water',TARIEF.water,0.1,'€/m³')}</div>
    <button class="mini" id="tarief-reset" style="margin-top:8px">Standaard (0,25 · 0 · 5,00)</button>`;
  el.querySelectorAll('[data-tarief]').forEach(i=>i.onchange = ()=>{ const v = parseFloat(String(i.value).replace(',','.')); if(isFinite(v) && v>=0){ TARIEF[i.dataset.tarief] = v; try{ localStorage.setItem('huis-tarieven', JSON.stringify(TARIEF)); }catch(_){} } renderPanel(); updateLabels(); });
  $('tarief-reset').onclick = ()=>{ Object.assign(TARIEF, TARIEF_STANDAARD); try{ localStorage.removeItem('huis-tarieven'); }catch(_){} renderPanel(); updateLabels(); };
}
function kostLabel(){
  if(!KOST.on || !lbl.all){ kostLbl.style.display = 'none'; return; }
  const k = kostTotaal(), t = `<b>Huis · kosten</b><span class="t">nu ${euro(k.nu)}/u</span> <span>·</span> <span>vandaag ${euro(k.totaalDag)} (stroom ${euro(k.stroomDag)} · water ${euro(k.waterDag)})</span>`;
  if(t!==kostLbl._t){ kostLbl.innerHTML = t; kostLbl._t = t; } placeLabel(kostLbl, KOST_POS, true);
}
function setKost(on){ KOST.on = on; $('kostbtn').setAttribute('aria-pressed', String(on)); try{ localStorage.setItem('huis-kosten', on ? '1' : '0'); }catch(_){} renderPanel(); updateLabels(); }
$('kostbtn').onclick = ()=> setKost(!KOST.on);
$('kostbtn').setAttribute('aria-pressed', String(KOST.on));
// watermeter in HA zoeken (device_class water; bij voorkeur 'vandaag/today/dag'); eenheid L of m³
function detectWater(states){
  const W2 = states.filter(st=>st.entity_id.startsWith('sensor.') && ((st.attributes||{}).device_class==='water' || /water.*(verbruik|meter|usage)/i.test(st.entity_id)) && /^(L|l|m³|m3)$/.test((st.attributes||{}).unit_of_measurement||''));
  const h = WATER.ent ? W2.find(s=>s.entity_id===WATER.ent) : (W2.find(s=>/vandaag|today|dag|daily/i.test(s.entity_id+' '+((s.attributes||{}).friendly_name||''))) || null);
  WATER.m3Today = null; if(!h){ console.info('Huis 3D · watermeter: geen dagverbruik-sensor gevonden', W2.map(s=>s.entity_id).join(', ')); return; }
  WATER.ent = h.entity_id; on(h.entity_id, st=>{ const v = num(st), u = (st.attributes||{}).unit_of_measurement; WATER.m3Today = v==null ? null : (/^l$/i.test(u) ? v/1000 : v); });
  console.info('Huis 3D · watermeter:', WATER.ent);
}
