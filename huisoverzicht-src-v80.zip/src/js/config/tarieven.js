// ===== (v80) TARIEVEN — fictief, aan te passen (ook in de kaart 'Kosten' zelf; dat wordt per browser onthouden) =====
//  stroom = € per kWh afname · terug = € per kWh teruglevering · water = € per m³ leidingwater
const TARIEF_STANDAARD = {stroom:0.25, terug:0.00, water:5.00};
const TARIEF = {...TARIEF_STANDAARD};
try{ Object.assign(TARIEF, JSON.parse(localStorage.getItem('huis-tarieven')||'{}')); }catch(_){}
// watermeter (leidingwater): ent leeg = automatisch zoeken in HA (sensor met device_class water, bij voorkeur 'vandaag'); spoelL = liters per doorspoeling (regenwater)
const WATER = {ent:null, m3Today:0.18, spoelL:6, spoelingen:0, dag:new Date().getDate()};
const KOST = {on:false};
try{ KOST.on = localStorage.getItem('huis-kosten')==='1'; }catch(_){}
const euro = (v, d=2)=> v==null || !isFinite(v) ? '–' : '€ '+v.toFixed(d).replace('.',',');
const perUur = w => w==null ? null : Math.max(0, w)/1000*TARIEF.stroom;              // € per uur bij dit vermogen
