#!/usr/bin/env python3
"""Huisoverzicht: bouwt uit sjabloon.html + de bronbestanden
  1) index.html                        → Home Assistant (/config/www/huis/), live
  2) offline_geanonimiseerd.html       → demo zonder internet en zonder persoonlijke gegevens
Gebruik:  python3 bouw.py [doelmap]   (standaard: de map boven src/)
Elke regel '{{bron:pad}}' in sjabloon.html wordt vervangen door de inhoud van dat bestand."""
import pathlib, re, sys
d = pathlib.Path(__file__).parent
dst = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else d.parent
t = (d/'sjabloon.html').read_text(encoding='utf-8')
html = re.sub(r'\{\{bron:([^}]+)\}\}\n', lambda m: (d/m.group(1)).read_text(encoding='utf-8'), t)
HEAD = '<!doctype html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>\n'
(dst/'index.html').write_text(HEAD + html + '\n</body></html>\n', encoding='utf-8')

# ---------- offline + geanonimiseerd ----------
a = html
def must(old, new):
    global a
    assert old in a, 'niet gevonden: ' + old[:60]
    a = a.replace(old, new)
must('const ANON = false;', 'const ANON = true;')
# three.js ingebakken (geen CDN), geen Google Fonts
a = re.sub(r'<link rel="preconnect"[^>]*>\n?', '', a)
a = re.sub(r'<link rel="stylesheet" href="https://fonts\.googleapis\.com[^>]*>\n?', '', a)
a = re.sub(r'<script type="importmap">.*?</script>\n?', '', a, flags=re.S)
vendor = (d/'vendor'/'three-0.160.0-bundel.js').read_text(encoding='utf-8').replace('</script', '<\\/script')
lic = (d/'vendor'/'LICENSE-three.txt').read_text(encoding='utf-8').strip()
must("import * as THREE from 'three';\nimport { OrbitControls } from 'three/addons/controls/OrbitControls.js';\nimport { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';",
     "const { THREE, OrbitControls, mergeGeometries } = window.__HUIS3D;")
a = a.replace('<script type="module">', '<script>/* ' + lic + ' */\n' + vendor + '\n</script>\n<script type="module">', 1)
# persoonsgegevens → neutraal (eerst de langste, daarna losse namen; ook in entity-namen)
NAMEN = [('Slaapkamer Bas & Debbie','Slaapkamer 1'), ('Bas & Debbie','ouders'), ('Kamer Lucas 2','Kamer 4'), ('Kamer Lucas','Kamer 3'),
         ('Kamer Jolie','Kamer 2'), ('Kamer Amélie','Kamer 5'), ('Dressing Amélie','Dressing kelder'),
         ('Debbie','Partner'), ('debbie','partner'), ('Bas','Bewoner'), ('bas','bewoner'),
         ('Jolie','Kind 1'), ('jolie','kind1'), ('Lucas','Kind 2'), ('lucas','kind2'),
         ('Amélie','Kind 3'), ('Amelie','Kind 3'), ('amélie','kind3'), ('amelie','kind3'), ('Essen','Demo')]
for old, new in NAMEN:
    a = re.sub(r'(?<![A-Za-zÀ-ÿ])' + re.escape(old) + r'(?![A-Za-zÀ-ÿ])', new, a)
a = a.replace('sn_0y95_422y', 'weheat_unit').replace('{lat:51.47, lon:4.47,', '{lat:51.0, lon:4.4,')
a = a.replace('title="Versie van het huisoverzicht">', 'title="Versie van het huisoverzicht">demo · ', 1)
left = re.findall(r'(?i)(?<![a-zà-ÿ])(bas|debbie|jolie|lucas|am[ée]lie|essen)(?![a-zà-ÿ])', a)
assert not left, 'nog namen over: ' + str(set(left))
assert 'cdn.jsdelivr' not in a and 'googleapis' not in a
(dst/'offline_geanonimiseerd.html').write_text(HEAD + a + '\n</body></html>\n', encoding='utf-8')
print('geschreven:', dst/'index.html', 'en', dst/'offline_geanonimiseerd.html')
