// ---------- meldingen & tips ----------
const dismissed = new Set();
const cycles = {};   // apparaten: wanneer klaar?
let doneMsgs = [];
function trackAppliances(){
  const now = Date.now();
  rooms.forEach(r=>r.plugs.forEach(p=>{
    if(!['Wasmachine','Droger','Vaatwasser'].includes(p.name)) return;
    const c = cycles[p.name] ||= {running:false, lowSince:null};
    const w = p.w||0;
    if(w > 100){ c.running = true; c.lowSince = null; }
    else if(c.running && w < 5){ c.lowSince ??= now; if(now - c.lowSince > 120000){ c.running = false; c.lowSince = null;
      doneMsgs = doneMsgs.filter(d=>d.name!==p.name); doneMsgs.push({name:p.name, at:now}); } }
  }));
  doneMsgs = doneMsgs.filter(d=> now - d.at < 3*3600e3);
}
function computeAlerts(){
  const A = [], add = (sev, key, html)=>{ if(!dismissed.has(key)) A.push({sev, key, html}); };
  const tNow = new Date();
  if(LOCK.state==='jammed') add('crit','lockjam','<b>Voordeurslot geblokkeerd</b>. Controleer de Bold smart lock.');
  if(LOCK.state==='unlocked' && night) add('warn','lockopen','<b>Voordeur</b> is niet op slot.');
  regenAlerts(add);
  if(LEAK.on) add('crit','leak',`<b>Water gedetecteerd</b> in de ${LEAK.name}! Controleer direct.`);
  if(LIVE && ha && starlink.ok===false) add('warn','star','<b>Starlink</b> is offline.');
  const gW = energy.grid==null ? null : (GRID_POS_IS_IMPORT ? energy.grid : -energy.grid);
  if(gW!=null && gW > 3000) add('warn','grid',`<b>Hoge afname</b> van het net: ${fmtW(gW)}.`);
  if(energy.batt!=null && energy.batt >= 95 && gW!=null && gW < -800) add('tip','surplus',`<b>Veel zonnestroom over</b> (${fmtW(-gW)} teruglevering, batterij ${Math.round(energy.batt)}%). Goed moment voor wasmachine, droger of vaatwasser.`);
  if(energy.batt!=null && energy.batt < 15 && night) add('info','battlow',`Thuisbatterij bijna leeg (${Math.round(energy.batt)}%).`);
  doneMsgs.forEach(d=> add('tip','done-'+d.name+d.at, `<b>${d.name} is klaar</b> · ${new Date(d.at).toLocaleTimeString('nl-BE',{hour:'2-digit',minute:'2-digit'})}`));
  rooms.forEach(x=>{
    if(x.hum!=null && x.hum>=65) add('warn','hum-'+x.id, `<b>${x.name}</b>: luchtvochtigheid ${Math.round(x.hum)}%. Ventileren aanbevolen.`);
    if(x.clim && x.temp!=null && x.target!=null && x.climState==='heat' && x.temp<x.target-1.5) add('info','cold-'+x.id, `<b>${x.name}</b>: ${fmt(x.temp)} °C, nog onder de doeltemperatuur.`);
    if(x.clim && x.climState==='cool' && outside.temp!=null && x.temp!=null && outside.temp < x.temp - 3) add('tip','vent-'+x.id, `<b>${x.name}</b>: buiten is het ${fmt(outside.temp)} °C. Ventileren in plaats van koelen?`);
    if(x.sensor && x.sensor.lastMotion && !x.sensor.motion && x.lampObjs.some(l=>l.on) && Date.now()-x.sensor.lastMotion > 15*60e3) add('tip','idle-'+x.id, `<b>${x.name}</b>: licht brandt al 15 min zonder beweging.`);
  });
  if(!night && byId.buiten && byId.buiten.lampObjs.some(l=>l.on && l.kind!=='unplaced')) add('tip','outday','<b>Buitenverlichting</b> brandt overdag.');
  Object.entries(BATTS).forEach(([n,v])=>{ if(v!=null && v < 15) add('warn','bat-'+n, `<b>Batterij bijna leeg</b>: ${n} (${Math.round(v)}%).`); });
  const bad = lampList.filter(l=>l.nc && (l.status==='unavail' || l.status==='broken'));
  if(bad.length) add('info','unav', `${bad.length} lamp${bad.length>1?'en':''} niet bereikbaar/defect: ${bad.slice(0,4).map(l=>l.room.name+' '+l.name).join(', ')}${bad.length>4?' …':''}`);
  const ord = {crit:0, warn:1, tip:2, info:3};
  return A.sort((a,b)=>ord[a.sev]-ord[b.sev]);
}
function renderAlerts(){
  const A = computeAlerts();
  $('alerts').innerHTML = A.map(a=>`<div class="alert ${a.sev}"><span>${a.html}</span><button class="x" data-dismiss="${a.key}" aria-label="Melding verbergen">×</button></div>`).join('') || `<div class="alert none">Alles in orde.</div>`;
  $('alerts').querySelectorAll('[data-dismiss]').forEach(b=>b.onclick=()=>{ dismissed.add(b.dataset.dismiss); renderAlerts(); });
}
function applyAC(){
  rooms.forEach(r=>{ if(!r.ac || !r.ac.ledMat) return;
    const m = r.climState, onn = m && m!=='off' && m!=='unavailable';
    const col = m==='heat' ? 0xff8a3d : m==='dry' ? 0xc9a6ff : m==='fan_only' ? 0xdddddd : 0x3fa7ff;
    r.ac.ledMat.emissive.setHex(col); r.ac.ledMat.emissiveIntensity = onn ? 2 : 0;
    r.ac.airMat.color.setHex(col); r.ac.airMat.opacity = onn ? 0.14 : 0; });
}
let eBuilt = false;
function renderEnergy(){
  const svg = $('esvg'); if(!svg) return;
  const N = {pv:[62,28,'Zon','#ffc46b'], house:[238,28,'Huis','#f2efe6'], batt:[62,122,'Batterij','#8fd17a'], grid:[238,122,'Net','#7fb6ff']};
  const H = [150,75];
  if(!eBuilt){
    let h = '';
    Object.entries(N).forEach(([k,[x,y,nm,c]])=>{ h += `<path class="base" d="M${x},${y} L${H[0]},${H[1]}"/><path id="ef-${k}" class="fl" stroke="${c}" d="M${x},${y} L${H[0]},${H[1]}"/>`; });
    h += `<circle cx="${H[0]}" cy="${H[1]}" r="21" fill="var(--panel2)" stroke="var(--line)"/><text x="${H[0]}" y="${H[1]+4}" text-anchor="middle" class="nm">GoodWe</text>`;
    Object.entries(N).forEach(([k,[x,y,nm,c]])=>{
      h += `<circle cx="${x}" cy="${y}" r="19" fill="var(--panel2)" stroke="${c}"/><text x="${x}" y="${y+4}" text-anchor="middle" class="nm">${nm}</text>`;
      const ty = y<75 ? y-24 : y+32; h += `<text id="ev-${k}" x="${x}" y="${ty}" text-anchor="middle">–</text>`;
    });
    svg.innerHTML = h; eBuilt = true;
  }
  const pvW = energy.pv!=null ? energy.pv*1000 : null;
  const bW = energy.battW==null ? null : (BATT_POS_IS_DISCHARGE ? energy.battW : -energy.battW);   // + = ontladen
  const gW = energy.grid==null ? null : (GRID_POS_IS_IMPORT ? energy.grid : -energy.grid);       // + = afname
  const set = (k, w, towardHub, txt)=>{ const el = $('ef-'+k); if(!el) return;
    const idle = w==null || Math.abs(w) < 30;
    el.setAttribute('class', 'fl' + (idle ? ' idle' : (towardHub ? '' : ' rev')));
    el.setAttribute('stroke-width', idle ? 2 : Math.min(7, 2 + Math.sqrt(Math.abs(w))/12));
    $('ev-'+k).textContent = txt; };
  // pad loopt van knooppunt naar GoodWe: 'vooruit' = naar GoodWe toe
  set('pv', pvW, true, fmtW(pvW));
  set('house', energy.house, false, fmtW(energy.house));
  set('batt', bW, bW>0, (energy.batt!=null ? Math.round(energy.batt)+'% · ' : '') + (bW==null ? '–' : (Math.abs(bW)<30 ? 'rust' : (bW>0 ? 'ontladen ' : 'laden ') + fmtW(Math.abs(bW)))));
  set('grid', gW, gW>0, gW==null ? '–' : (Math.abs(gW)<30 ? '0 W' : (gW>0 ? 'afname ' : 'teruglevering ') + fmtW(Math.abs(gW))));
  $('etoday').innerHTML = `<span>Vandaag: opgewekt ${fmt(energy.pvToday,1)} kWh</span><span>afname ${fmt(energy.impToday,1)} kWh</span><span>teruglevering ${fmt(energy.expToday,1)} kWh</span>`;
  // 3D-stromen + labels
  setFlow(FLOWS.pv1, pvW||0, true); setFlow(FLOWS.pv2, pvW||0, true);
  setFlow(FLOWS.batt, Math.abs(bW||0), (bW||0) < 0);           // vooruit = GoodWe → batterij (laden)
  setFlow(FLOWS.house, energy.house||0, true);
  setFlow(FLOWS.grid, Math.abs(gW||0), (gW||0) < 0);
  { const zp = byId.buiten.plugs.find(p=>p.name==='Zwembadpomp'), zw = zp && zp.on ? (zp.w||0) : 0; setFlow(FLOWS.zwembad, zw, true);   // (v76)
    eLabels.zwembad.innerHTML = `<b>Zwembadpomp</b><span class="t">${!zp || (!zp.sw && !zp.pw) ? 'stopcontact nog niet in HA' : fmtW(zw)}</span>`; }
  setFlow(FLOWS.hp, Object.values(HP).reduce((s,u)=>s+(u.v.pin||0),0), true);           // vooruit = meterkast → straat (teruglevering)
  eLabels.pv.innerHTML = `<b>Zonnepanelen</b><span class="t">${fmtW(pvW)}</span>`;
  eLabels.batt.innerHTML = `<b>BYD batterij</b><span class="t">${energy.batt!=null?Math.round(energy.batt)+'%':'–'}</span> <span>${bW==null?'':Math.abs(bW)<30?'rust':(bW>0?'ontladen ':'laden ')+fmtW(Math.abs(bW))}</span>`;
  eLabels.house.innerHTML = `<b>Huisverbruik</b><span class="t">${fmtW(energy.house)}</span>`;
  const hpIn = Object.values(HP).reduce((s,u)=>s+(u.v.pin||0),0);
  eLabels.hp.innerHTML = `<b>Warmtepomp</b><span class="t">${fmtW(hpIn)}</span> <span>${Object.values(HP).map(u=>HP_MODE(u.v.status)[1]).join(' / ')}</span>`;
  eLabels.grid.innerHTML = `<b>Net</b><span class="t">${gW==null?'–':Math.abs(gW)<30?'0 W':(gW>0?'afname ':'teruglevering ')+fmtW(Math.abs(gW))}</span>`;
}
let showEnergy = false;
function renderLegend(){
  const el = $('legend');
  if(colorMode==='none'){ el.innerHTML=''; return; }
  const stops = colorMode==='temp'?TEMP_STOPS:HUM_STOPS;
  const a=stops[0][0], b=stops[stops.length-1][0];
  const grad = stops.map(([v,c])=>`${c} ${((v-a)/(b-a)*100).toFixed(0)}%`).join(',');
  el.innerHTML = `<span>${a}${colorMode==='temp'?' °C':'%'}</span><span class="bar" style="background:linear-gradient(90deg,${grad})"></span><span>${b}${colorMode==='temp'?' °C':'%'}</span>`;
}

