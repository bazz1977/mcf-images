/* ---------- Labels ---------- */
const labelsEl = document.getElementById('labels');
rooms.forEach(r=>{
  const el = document.createElement('div');
  el.className = 'label';
  el.addEventListener('click',()=>select(r));
  labelsEl.appendChild(el); r.labelEl = el;
});
const outLabel = document.createElement('div');
outLabel.className = 'label out';
labelsEl.appendChild(outLabel);
const eLabels = {};
['pv','batt','house','grid','hp','zwembad'].forEach(k=>{ const el = document.createElement('div'); el.className = 'label elabel'; labelsEl.appendChild(el); eLabels[k] = el; });
const OUT_POS = new THREE.Vector3(W_M/2+2.5, 1.2, -D_M/2-2.5);
// (v28) gevelnamen in beeld
const GEVELS = [['Voorgevel', 2.6, -1.4, 0.2, [0,-1]], ['Achtergevel', W_M/2, D_M+1.6, -1.1, [0,1]], ['Linkergevel', W_M+1.8, D_M/2, -0.3, [1,0]], ['Rechtergevel', TR_X0-0.9, D_M/2, 0.2, [-1,0]]]
  .map(([n,x,y,h,nv])=>{ const el = document.createElement('div'); el.className = 'label gevel'; el.textContent = n; labelsEl.appendChild(el); return {el, n:nv, pos:new THREE.Vector3(mx(x), h, mz(y))}; });

// label-instellingen (per viewer onthouden in de browser)
// (v39) windrichtingen N/O/Z/W rond het huis (kompas Bas: linkergevel 156° ZO)
const KOMPAS = [['N',0],['O',90],['Z',180],['W',270]].map(([n,b])=>{ const el = document.createElement('div'); el.className = 'label kompas'; el.textContent = n; el.title = {N:'Noord',O:'Oost',Z:'Zuid',W:'West'}[n]; labelsEl.appendChild(el);
  const rel = (b - 156)*Math.PI/180; return {el, pos:new THREE.Vector3(Math.cos(rel)*17, 0.4, Math.sin(rel)*17)}; });
const LBL_KEY = 'huis-labels-v1';
const lbl = {all:true, outside:true, gevels:true, kompas:true, floors:{'-1':true,0:true,1:true}, rooms:{}, parts:{name:true,temp:true,hum:true,power:false}};
try{ const saved = JSON.parse(localStorage.getItem(LBL_KEY)||'null'); if(saved) Object.assign(lbl, saved, {floors:{...lbl.floors,...saved.floors}, parts:{...lbl.parts,...saved.parts}, rooms:{...saved.rooms}}); }catch(e){}
const saveLbl = ()=>{ try{ localStorage.setItem(LBL_KEY, JSON.stringify(lbl)); }catch(e){} };
const roomOn = r => lbl.rooms[r.id] !== false;
const anyPart = ()=> lbl.parts.name || lbl.parts.temp || lbl.parts.hum || lbl.parts.power;
