rooms.forEach(r=>{
  const parent = r.floor===1 ? upper : r.floor===-1 ? cellar : house;
  r.slabMat = new THREE.MeshStandardMaterial({color:NEUTRAL, roughness:.8});
  if(!r.outdoor) r.rects.forEach(([a,b,c,d],k)=>{
    const slab = new THREE.Mesh(slabGeo(a+0.005,b+0.005,c-0.005,d-0.005, r.hole && k===0), r.slabMat);
    slab.receiveShadow = true;
    slab.userData.room = r; pickables.push(slab); parent.add(slab);
  });
  const ceilGroup = r.floor===1 ? upWalls : r.floor===-1 ? cellarWalls : walls;   // spots zakken mee met de muren
  const ceil = (r.ceil || (r.floor===-1 ? K_H : CEIL_UP)) - 0.02;
  r.lampObjs = r.lamps.map(([px,py,name,on,kind='spot',ha=null,status=null,face='x-',wh=1.8],i)=>{
    const nc = !!status;
    const bulbMat = new THREE.MeshStandardMaterial({color:nc?0x555a60:0xfff3dc, emissive:0xffc46b, emissiveIntensity:0});
    const lamp = {room:r, i, on: nc ? false : on, bulbMat, name, kind, ha, nc, status, placed: kind!=='unplaced', bri:200, kelvin:2700, cmode:'color_temp', modes:['color_temp','xy']};
    lampList.push(lamp);
    if(!lamp.placed) return lamp;
    const lx=mx(px), lz=mz(py);
    let hit;
    if(kind==='floor'){
      // Hue staande lamp: voet, stang, kap
      const g = new THREE.Group();
      const foot = new THREE.Mesh(new THREE.CylinderGeometry(.18,.18,.03,24), spotRing); foot.position.y = .015;
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(.015,.015,1.4,8), spotRing); pole.position.y = .72;
      g.add(foot, pole);
      const shade = new THREE.Mesh(new THREE.CylinderGeometry(.2,.24,.32,24,1,true), bulbMat); shade.material.side = THREE.DoubleSide;
      shade.position.y = 1.5; g.add(shade);
      g.position.set(lx,0,lz); g.traverse(o=>o.castShadow=true); parent.add(g);
      lamp.light = new THREE.PointLight(0xffc46b, 0, 7, 1.6); lamp.light.position.set(lx,1.45,lz); parent.add(lamp.light);
      hit = new THREE.Mesh(new THREE.CylinderGeometry(.35,.35,1.8,8), new THREE.MeshBasicMaterial({visible:false}));
      hit.position.set(lx,0.9,lz); parent.add(hit);
    } else if(kind==='pendant'){
      // hanglamp: snoer + kap + lamp
      const cord = box(0.01, ceil-1.95, 0.01, spotRing, lx, 1.95, lz);
      const shade = new THREE.Mesh(new THREE.SphereGeometry(.17,20,12,0,Math.PI*2,0,Math.PI/2), new THREE.MeshStandardMaterial({color:0x2b3238, side:THREE.DoubleSide, roughness:.6}));
      shade.position.set(lx,1.9,lz);
      const bulb = new THREE.Mesh(new THREE.SphereGeometry(.07,16,10), bulbMat); bulb.position.set(lx,1.88,lz);
      hit = new THREE.Mesh(new THREE.SphereGeometry(.3,8,8), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(lx,1.9,lz);
      ceilGroup.add(cord,shade,bulb,hit);
    } else if(kind==='ground'){
      // grondspot in het terras
      const ring = new THREE.Mesh(new THREE.CylinderGeometry(.06,.06,.02,20), nc ? new THREE.MeshStandardMaterial({color:0x6b6f73}) : spotRing); ring.position.set(lx,-0.11,lz);
      const lens = new THREE.Mesh(new THREE.CircleGeometry(.045,20), bulbMat); lens.rotation.x = -Math.PI/2; lens.position.set(lx,-0.098,lz);
      const beam = new THREE.Mesh(new THREE.ConeGeometry(.35, 1.4, 20, 1, true), beamMat); beam.rotation.x = Math.PI; beam.position.set(lx, 0.6, lz); beam.visible = false; lamp.beam = beam;
      hit = new THREE.Mesh(new THREE.SphereGeometry(.25,8,8), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(lx,0.05,lz);
      parent.add(ring, lens, beam, hit);
    } else if(kind==='post'){
      // (v74) tuinspot op een paaltje (paaltje zelf: js/scene/voortuin-regenwater.js), kop gericht naar 'face'
      const g = new THREE.Group(), base = gradeAt(lx, lz);
      const head = new THREE.Mesh(new THREE.CylinderGeometry(.04,.05,.12,16), nc ? new THREE.MeshStandardMaterial({color:0x6b6f73}) : spotRing); head.rotation.z = Math.PI/2; head.position.x = .06;
      const lens = new THREE.Mesh(new THREE.CircleGeometry(.036,16), bulbMat); lens.rotation.y = Math.PI/2; lens.position.x = .121;
      const beam = new THREE.Mesh(new THREE.ConeGeometry(.55, 2.0, 20, 1, true), beamMat); beam.rotation.z = Math.PI/2 + 0.18; beam.position.set(1.12, -.18, 0); beam.visible = false; lamp.beam = beam;
      g.add(head, lens, beam); g.rotation.y = {'x+':0, 'x-':Math.PI, 'y+':-Math.PI/2, 'y-':Math.PI/2}[face]; g.position.set(lx, base+wh, lz); parent.add(g);
      hit = new THREE.Mesh(new THREE.SphereGeometry(.2,8,8), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(lx, base+wh, lz); parent.add(hit);
    } else if(kind==='wall' || kind==='outwall'){
      // wandlamp: plaat + lichtbak, gericht de ruimte in
      const g = new THREE.Group();
      const plate = new THREE.Mesh(new THREE.BoxGeometry(.02,.2,.12), spotRing); plate.position.x = .01;
      const glow = new THREE.Mesh(new THREE.BoxGeometry(.05,.13,.09), bulbMat); glow.position.x = .045;
      g.add(plate, glow);
      if(kind==='outwall'){ // Hue Appear: licht omhoog en omlaag langs de gevel
        [1,-1].forEach(d=>{ const b = new THREE.Mesh(new THREE.ConeGeometry(.28, 1.1, 16, 1, true), beamMat); b.rotation.z = d>0 ? Math.PI : 0; b.position.set(.07, d*.62, 0); g.add(b); (lamp.beams ||= []).push(b); });
      }
      g.rotation.y = {'x+':0, 'x-':Math.PI, 'y+':-Math.PI/2, 'y-':Math.PI/2}[face];
      g.position.set(lx, wh, lz);
      hit = new THREE.Mesh(new THREE.SphereGeometry(.25,8,8), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(lx,wh,lz);
      wallMount(g, wh, ceilGroup); wallMount(hit, wh, ceilGroup);
    } else if(kind==='tl'){
      const tube = box(0.12, 0.05, 1.2, bulbMat, lx, ceil-0.07, lz);
      hit = new THREE.Mesh(new THREE.BoxGeometry(.4,.3,1.3), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(lx,ceil-0.2,lz);
      ceilGroup.add(tube,hit);
    } else {
      // Hue inbouwspot in het plafond + lichtbundel
      const ring = new THREE.Mesh(new THREE.CylinderGeometry(.075,.075,.025,20), nc ? new THREE.MeshStandardMaterial({color:0x6b6f73}) : spotRing);
      ring.position.set(lx,ceil,lz);
      const lens = new THREE.Mesh(new THREE.CircleGeometry(.055,20), bulbMat);
      lens.rotation.x = Math.PI/2; lens.position.set(lx,ceil-0.014,lz);
      const beam = new THREE.Mesh(new THREE.ConeGeometry(.55, ceil, 24, 1, true), beamMat);
      beam.position.set(lx, ceil/2, lz); beam.visible = false; lamp.beam = beam;
      hit = new THREE.Mesh(new THREE.SphereGeometry(.3,8,8), new THREE.MeshBasicMaterial({visible:false}));
      hit.position.set(lx,ceil-0.15,lz);
      ceilGroup.add(ring,lens,beam,hit);
    }
    hit.userData.lamp = lamp; pickables.push(hit);
    return lamp;
  });
  // één lichtbron per kamer voor alle plafondlampen samen (sneller dan een licht per lamp)
  const sp = r.lampObjs.filter(l=>l.placed && l.kind!=='floor' && !l.nc);
  if(sp.length){
    r.spotLight = new THREE.PointLight(0xffc46b, 0, 9, 1.4);
    r.spotLight.position.set(sp.reduce((a,l)=>a+mx(r.lamps[l.i][0]),0)/sp.length, ceil-0.5, sp.reduce((a,l)=>a+mz(r.lamps[l.i][1]),0)/sp.length);
    ceilGroup.add(r.spotLight);
  }
  // LG airco binnenunit op de muur
  if(r.ac && r.ac.pos){
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(.2,.28,.82), new THREE.MeshStandardMaterial({color:0xf3f3f1, roughness:.35}));
    body.position.x = .1; body.castShadow = true;
    r.ac.ledMat = new THREE.MeshStandardMaterial({color:0x222, emissive:0x3fa7ff, emissiveIntensity:0});
    const led = new THREE.Mesh(new THREE.BoxGeometry(.01,.015,.45), r.ac.ledMat); led.position.set(.205,-.08,0);
    r.ac.airMat = new THREE.MeshBasicMaterial({color:0x6fc3ff, transparent:true, opacity:0, depthWrite:false, side:THREE.DoubleSide, blending:THREE.AdditiveBlending});
    const air = new THREE.Mesh(new THREE.PlaneGeometry(1.1,.8), r.ac.airMat);
    air.rotation.set(0,0,-0.55); air.rotation.order = 'YXZ'; air.position.set(.62,-.42,0);
    const airG = new THREE.Group(); air.rotation.set(Math.PI/2,0,0); airG.add(air); airG.rotation.z = -0.5; airG.position.set(.2,-.14,0);
    air.position.set(.55,0,0);
    g.add(body, led, airG);
    g.rotation.y = {'x+':0, 'x-':Math.PI, 'y+':-Math.PI/2, 'y-':Math.PI/2}[r.ac.face];
    g.position.set(mx(r.ac.pos[0]), r.ac.h, mz(r.ac.pos[1]));
    const hit = new THREE.Mesh(new THREE.BoxGeometry(.5,.5,1), new THREE.MeshBasicMaterial({visible:false})); hit.position.copy(g.position); hit.userData.room = r;
    wallMount(g, r.ac.h, ceilGroup); wallMount(hit, r.ac.h, ceilGroup); pickables.push(hit); dev(g, 'Airco '+r.name);
  }
  // slimme stekkers met positie
  r.plugs.forEach(p=>{
    if(!p.pos) return;
    const [px,py,ph,face] = p.pos;
    p.ledMat = new THREE.MeshStandardMaterial({color:0x222, emissive:0x46d17a, emissiveIntensity:0});
    const g = new THREE.Group();
    if(face==='floor'){
      const plate = new THREE.Mesh(new THREE.BoxGeometry(.14,.02,.14), spotRing); plate.position.y = .01;
      const led = new THREE.Mesh(new THREE.TorusGeometry(.035,.008,8,20), p.ledMat); led.rotation.x = Math.PI/2; led.position.y = .025;
      g.add(plate, led); g.position.set(mx(px), 0, mz(py)); parent.add(g); dev(g, p.name, 'stekker');
    } else {
      const plate = new THREE.Mesh(new THREE.BoxGeometry(.015,.09,.09), new THREE.MeshStandardMaterial({color:0xf3f3f1, roughness:.4})); plate.position.x = .008;
      const led = new THREE.Mesh(new THREE.TorusGeometry(.028,.006,8,20), p.ledMat); led.rotation.y = Math.PI/2; led.position.x = .018;
      g.add(plate, led); g.rotation.y = {'x+':0, 'x-':Math.PI, 'y+':-Math.PI/2, 'y-':Math.PI/2}[face];
      g.position.set(mx(px), ph, mz(py)); wallMount(g, ph, ceilGroup); dev(g, p.name, 'stekker');
    }
    const hit = new THREE.Mesh(new THREE.SphereGeometry(.2,8,8), new THREE.MeshBasicMaterial({visible:false}));
    hit.position.set(mx(px), face==='floor' ? .1 : ph, mz(py)); hit.userData.room = r; if(face==='floor') parent.add(hit); else wallMount(hit, ph, ceilGroup); pickables.push(hit);
  });
  // Sony Bravia 65" (16:9): beeld 1,439 × 0,809 m, toestel ±1,447 × 0,833 m, 3,5 cm diep, aan de muur hal | woonkamer
  if(r.id==='woon'){
    const g = new THREE.Group();
    const W = 1.447, H = 0.833, SW = 1.439, SH = 0.809;
    const body = new THREE.Mesh(new THREE.BoxGeometry(.035, H, W), new THREE.MeshStandardMaterial({color:0x16171a, roughness:.35, metalness:.5}));
    body.position.set(.0175+.02, 0, 0); body.castShadow = true;
    const mount = new THREE.Mesh(new THREE.BoxGeometry(.02,.4,.6), new THREE.MeshStandardMaterial({color:0x222}));
    mount.position.x = .01;
    tvScreen = new THREE.MeshStandardMaterial({color:0x040506, emissive:0x2c5f97, emissiveIntensity:0, roughness:.12, metalness:.2});
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(SW, SH), tvScreen); screen.rotation.y = Math.PI/2; screen.position.set(.0555, (H-SH)/2 - .006, 0);
    const logo = new THREE.Mesh(new THREE.BoxGeometry(.002,.006,.05), new THREE.MeshStandardMaterial({color:0x777, metalness:.8})); logo.position.set(.057, -H/2+.009, 0);
    g.add(mount, body, screen, logo); g.position.set(mx(6.52), 0, mz(1.2));
    wallMount(g, 1.2, ceilGroup); dev(g, 'Sony tv', 'media');
    const hit = new THREE.Mesh(new THREE.BoxGeometry(.2, H, W), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(mx(6.6), 0, mz(1.2)); hit.userData.room = r;
    wallMount(hit, 1.2, ceilGroup); pickables.push(hit);
  }
  // Kleine apparaten: Apple TV (9,3 × 9,3 × 3,1 cm) en PS5 Slim (staand 35,8 × 9,6 × 21,6 cm) op een zwevend plankje
  const blackBox = (w,h,d,col=0x151618)=>{ const b = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), new THREE.MeshStandardMaterial({color:col, roughness:.35, metalness:.3})); b.castShadow = true; return b; };
  const ledOf = m=>{ const lm = new THREE.MeshStandardMaterial({color:0x222, emissive:0xffffff, emissiveIntensity:.15}); m.led = lm; return lm; };
  const shelf = (len)=>{ const p = new THREE.Mesh(new THREE.BoxGeometry(.28,.025,len), new THREE.MeshStandardMaterial({color:0x2a2c2f, roughness:.7})); p.position.set(.14,-.0125,0); p.castShadow = true; return p; };
  if(r.id==='woon'){
    // rechts naast de Sony (vanaf de bank gezien) = richting voorgevel; plankje op 0,5 m
    const g = new THREE.Group();
    const ps = blackBox(.216,.358,.096,0xf1f1ee); ps.position.set(.13,.179,.1);
    const psMid = blackBox(.22,.358,.02); psMid.position.set(.13,.179,.1);
    const psLed = new THREE.Mesh(new THREE.BoxGeometry(.004,.12,.004), ledOf(MEDIA.ps5)); psLed.position.set(.241,.2,.1);
    const atv = blackBox(.093,.031,.093); atv.position.set(.12,.0155,-.08);
    const atvLed = new THREE.Mesh(new THREE.BoxGeometry(.002,.004,.004), ledOf(MEDIA.atvWoon)); atvLed.position.set(.167,.016,-.08);
    g.add(shelf(.42), ps, psMid, psLed, atv, atvLed); g.position.set(mx(6.49), 0, mz(0.27));   // + Bold Connect (hieronder)
    wallMount(g, 0.5, ceilGroup); dev(g, 'Apple TV + PS5', 'media');
    // Bold Connect-bridge achter de tv (in het stopcontact, onzichtbaar achter het toestel)
    // (v78) Bold Connect-bridge ligt naast de Apple TV op het plankje
    const bc = blackBox(.06,.018,.06,0xf4f4f2); bc.position.set(.225,.009,-.08); g.add(bc);
    const hit = new THREE.Mesh(new THREE.BoxGeometry(.3,.45,.45), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(mx(6.62),0,mz(0.27)); hit.userData.room = r;
    wallMount(hit, 0.7, ceilGroup); pickables.push(hit);
  }
  if(r.id==='slaap'){
    // Philips 55" (beeld 1,21 × 0,68 m) op de muur trap | slaapkamer, kijkend naar het bed
    const m = MEDIA.tvSlaap, g = new THREE.Group();
    const W = 1.232, H = 0.713, SW = 1.21, SH = 0.68;
    const body = new THREE.Mesh(new THREE.BoxGeometry(.045, H, W), new THREE.MeshStandardMaterial({color:0x1a1b1e, roughness:.35, metalness:.5})); body.position.x = .0425; body.castShadow = true;
    m.screen = new THREE.MeshStandardMaterial({color:0x040506, emissive:0x2c5f97, emissiveIntensity:0, roughness:.12, metalness:.2});
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(SW, SH), m.screen); screen.rotation.y = Math.PI/2; screen.position.set(.066, .006, 0);
    // (v49) Ambilight: gloed op de muur achter de Philips, kleur volgt light.*ambilight
    m.glowMat = new THREE.MeshBasicMaterial({color:0xff8a3d, transparent:true, opacity:0, depthWrite:false, blending:THREE.AdditiveBlending, side:THREE.DoubleSide});
    const glow = new THREE.Mesh(new THREE.PlaneGeometry(W+0.7, H+0.5), m.glowMat); glow.rotation.y = Math.PI/2; glow.position.x = .02; glow.renderOrder = 3;
    g.add(glow, body, screen); g.rotation.y = -Math.PI/2; g.position.set(mx(2.55), 0, mz(2.5));
    wallMount(g, 1.3, ceilGroup); dev(g, 'Philips tv', 'media');
    // Apple TV linksonder op een plankje
    const a = new THREE.Group();
    const atv = blackBox(.093,.031,.093); atv.position.set(.12,.0155,0);
    const atvLed = new THREE.Mesh(new THREE.BoxGeometry(.002,.004,.004), ledOf(MEDIA.atvSlaap)); atvLed.position.set(.167,.016,0);
    a.add(shelf(.3), atv, atvLed); a.rotation.y = -Math.PI/2; a.position.set(mx(1.98), 0, mz(2.52));
    wallMount(a, 0.75, ceilGroup);
    const hit = new THREE.Mesh(new THREE.BoxGeometry(W, H, .25), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(mx(2.55),0,mz(2.62)); hit.userData.room = r;
    wallMount(hit, 1.3, ceilGroup); pickables.push(hit);
  }
  if(r.id==='hal'){
    // Bold smart lock: ronde cilinder binnenzijde glazen voordeur (x 5,47–6,47), slotkant bij de woonkamermuur (aanname)
    const g = new THREE.Group();
    const cyl = new THREE.Mesh(new THREE.CylinderGeometry(.03,.03,.07,32), new THREE.MeshStandardMaterial({color:0x2b2d30, roughness:.3, metalness:.7}));
    cyl.rotation.x = Math.PI/2; cyl.position.z = .035; cyl.castShadow = true;
    LOCK.ledMat = new THREE.MeshStandardMaterial({color:0x222, emissive:0x46d17a, emissiveIntensity:0});
    const ring = new THREE.Mesh(new THREE.TorusGeometry(.024,.003,8,28), LOCK.ledMat); ring.position.z = .071;
    g.add(cyl, ring); g.position.set(mx(LOCK.pos[0]), 0, mz(LOCK.pos[1]) + .06);
    wallMount(g, 1.05, ceilGroup);
    const hit = new THREE.Mesh(new THREE.SphereGeometry(.15,8,8), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(mx(LOCK.pos[0]),0,mz(LOCK.pos[1])+.12); hit.userData.room = r;
    wallMount(hit, 1.05, ceilGroup); pickables.push(hit);
  }
  // Muur naast de keukeninham (x 5,3, y 4,7–6,7, zijde hal): IKEA Symfonisk boekenplankspeaker (Sonos) en TP-Link Omada EAP225
  if(r.id==='hal'){
    const sp = new THREE.Group();
    const cab = new THREE.Mesh(new THREE.BoxGeometry(.10,.15,.31), new THREE.MeshStandardMaterial({color:0x1c1d1f, roughness:.85}));
    cab.position.x = .05; cab.castShadow = true;
    sonosLed = new THREE.MeshStandardMaterial({color:0x222, emissive:0xffffff, emissiveIntensity:0});
    const led = new THREE.Mesh(new THREE.SphereGeometry(.006,8,8), sonosLed); led.position.set(.101,.055,.12);
    sonosWaves = [0,1,2].map(i=>{ const m = new THREE.Mesh(new THREE.TorusGeometry(.12+i*.07,.006,6,28,Math.PI*0.8), new THREE.MeshBasicMaterial({color:0xffc46b, transparent:true, opacity:0, depthWrite:false}));
      m.rotation.set(0,Math.PI/2,Math.PI*0.6); m.position.x = .14+i*.03; sp.add(m); return m; });
    sp.add(cab, led); sp.position.set(mx(5.35), 0, mz(6.15)); wallMount(sp, 1.6, ceilGroup); dev(sp, 'Symfonisk', 'media');
    const spHit = new THREE.Mesh(new THREE.SphereGeometry(.25,8,8), new THREE.MeshBasicMaterial({visible:false})); spHit.position.set(mx(5.45),0,mz(6.15)); spHit.userData.room = r;
    wallMount(spHit, 1.6, ceilGroup); pickables.push(spHit);
    // EAP225: rond, Ø ±18 cm, 4,5 cm dik, op de muur rechtsboven
    const ap = new THREE.Group();
    const disc = new THREE.Mesh(new THREE.CylinderGeometry(.09,.085,.045,40), new THREE.MeshStandardMaterial({color:0xf4f4f2, roughness:.3}));
    disc.rotation.z = Math.PI/2; disc.position.x = .0225;
    apLed = new THREE.MeshStandardMaterial({color:0x222, emissive:0x46d17a, emissiveIntensity:1.4});
    const ring = new THREE.Mesh(new THREE.TorusGeometry(.02,.004,8,24), apLed); ring.rotation.y = Math.PI/2; ring.position.x = .046;
    ap.add(disc, ring); ap.position.set(mx(5.35), 0, mz(5.05)); wallMount(ap, 2.45, ceilGroup); dev(ap, 'AP hal/woonkamer', 'netwerk'); OMADA.devices.find(d=>d.existing).led = apLed;
  }
  // Weheat stuurunit (op de gevel x 6,47) + 200 L-boiler in de hoek van de badkamer boven
  if(r.id==='bad-boven'){
    const u = HP.lp9;
    const boiler = new THREE.Mesh(new THREE.CylinderGeometry(.3,.3,1.45,32), new THREE.MeshStandardMaterial({color:0xf2f2ef, roughness:.35}));
    boiler.geometry.translate(0,.725,0); boiler.position.set(mx(6.05), 0, mz(1.75)); boiler.castShadow = true; upWalls.add(boiler); dev(boiler, 'Boiler 200 L', 'water');
    // (v33) boiler vullen zichtbaar: mantel half doorzichtig, warm water stijgt mee met de boilertemperatuur, golf loopt omhoog tijdens 'Warm water'
    boiler.material.transparent = true; boiler.material.opacity = 0.35; boiler.material.depthWrite = false; boiler.castShadow = false;
    u.waterMat = new THREE.MeshStandardMaterial({color:0x3a2250, emissive:0xc47bff, emissiveIntensity:.25, transparent:true, opacity:.85});
    const water = new THREE.Mesh(new THREE.CylinderGeometry(.27,.27,1.39,32), u.waterMat); water.geometry.translate(0,.695,0);
    water.position.set(mx(6.05), .03, mz(1.75)); upWalls.add(water); u.water = water;
    u.waveMat = new THREE.MeshBasicMaterial({color:0xe6c8ff, transparent:true, opacity:0, depthWrite:false});
    const wave = new THREE.Mesh(new THREE.TorusGeometry(.285,.018,8,40), u.waveMat); wave.rotation.x = Math.PI/2; wave.position.set(mx(6.05), .05, mz(1.75)); upWalls.add(wave); u.wave = wave;
    // (v46) warm water tappen: koud water stroomt onderin binnen (blauw), warm water gaat bovenuit naar de kranen (oranje druppels door de leiding)
    u.coldMat = new THREE.MeshBasicMaterial({color:0x3fa7ff, transparent:true, opacity:0, depthWrite:false});
    const cold = new THREE.Mesh(new THREE.CylinderGeometry(.272,.272,1,32), u.coldMat); cold.geometry.translate(0,.5,0); cold.position.set(mx(6.05), .03, mz(1.75)); cold.scale.y = 0.001; cold.renderOrder = 5; u.coldMat.depthTest = false; upWalls.add(cold); u.cold = cold;
    const pipeM = new THREE.MeshStandardMaterial({color:0xb87333, metalness:.7, roughness:.35});
    const L3 = (x,h,y)=> new THREE.Vector3(mx(x), h, mz(y));
    // (v57) opstelling tegen de muur x 6,47 (van links naar rechts, kijkend naar de muur): leidingen buitenunit (y 0,22) · collector warm water (y 0,35–0,75) · collector vloerverwarming (y 0,80–1,40) · binnenunit (y 1,28) · boiler (y 1,75)
    const WALLX = 6.29, COL_H = 0.10;   // (v58) binnenkant van de gevel ligt op x 6,33 (niet 6,47)
    u.tapCurve = ortho([L3(6.05,1.45,1.75), L3(6.05,1.55,1.75), L3(WALLX,1.55,1.75), L3(WALLX,1.55,1.05), L3(WALLX,0.32,1.05), L3(WALLX,0.32,0.55), L3(WALLX,COL_H+0.16,0.55)]);   // (v58) laag langs de muur, onder het schuine dak   // warm water uit de bovenkant van de boiler → collector WW
    upWalls.add(new THREE.Mesh(new THREE.TubeGeometry(u.tapCurve, 40, .012, 6, false), pipeM));
    const dropM = new THREE.MeshBasicMaterial({color:0xff9a4d, transparent:true, depthWrite:false});
    u.drops = Array.from({length:10}, ()=>{ const d = new THREE.Mesh(new THREE.SphereGeometry(.028,8,6), dropM); d.visible = false; upWalls.add(d); return d; });
    u.tapHist = []; u.tapUntil = 0;
    // (v57) binnenunit 30 × 30 cm direct links naast de boiler, lampje: blauw pulserend = opwarmen, groen = rust
    const su = new THREE.Group();
    const cab = new THREE.Mesh(new THREE.BoxGeometry(.12,.3,.3), new THREE.MeshStandardMaterial({color:0xf2f2ef, roughness:.4})); cab.position.x = .06; cab.castShadow = true;
    u.ledMat = new THREE.MeshStandardMaterial({color:0x222, emissive:0x46d17a, emissiveIntensity:1.2});
    const led = new THREE.Mesh(new THREE.SphereGeometry(.014,12,8), u.ledMat); led.position.set(.122,-.06,0);
    su.add(cab, led); su.rotation.y = Math.PI; su.position.set(mx(6.33), 0, mz(1.28)); wallMount(su, 1.25, upWalls); dev(su, 'Weheat binnenunit');   // (v58) tegen de binnenkant van de muur
    // collectoren op 10 cm van de vloer
    const brass = new THREE.MeshStandardMaterial({color:0xc9954f, metalness:.7, roughness:.35}), red = new THREE.MeshStandardMaterial({color:0xd9564a, roughness:.5}), blue = new THREE.MeshStandardMaterial({color:0x4f86d6, roughness:.5});
    const bar = (y0,y1,h,m)=>{ const b = new THREE.Mesh(new THREE.CylinderGeometry(.018,.018,y1-y0,10), m); b.rotation.x = Math.PI/2; b.position.set(mx(WALLX), h, mz((y0+y1)/2)); upWalls.add(b); };
    bar(0.35,0.75,COL_H+0.16,brass); for(let y=0.4;y<0.75;y+=0.08){ const t = new THREE.Mesh(new THREE.CylinderGeometry(.008,.008,.12,6), brass); t.position.set(mx(WALLX),COL_H+0.08,mz(y)); upWalls.add(t); }
    bar(0.80,1.40,COL_H+0.20,red); bar(0.80,1.40,COL_H+0.08,blue);
    for(let y=0.85;y<1.4;y+=0.08){ const t = new THREE.Mesh(new THREE.CylinderGeometry(.007,.007,.1,6), new THREE.MeshStandardMaterial({color:0x777})); t.position.set(mx(WALLX),COL_H+0.0,mz(y)); upWalls.add(t); }
    // stroming door de leidingen (dunne buis altijd zichtbaar, bolletjes als er iets stroomt)
    const flow = (curve, color, n=12, vis=true)=>{ const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 120, .011, 6, false), new THREE.MeshStandardMaterial({color, roughness:.5, transparent:!vis, opacity: vis ? 1 : .15}));
      upWalls.add(tube); const dm = new THREE.MeshBasicMaterial({color, depthTest:false, transparent:true});
      const dots = Array.from({length:n}, ()=>{ const d = new THREE.Mesh(new THREE.SphereGeometry(.024,8,6), dm); d.renderOrder = 6; d.visible = false; upWalls.add(d); return d; }); return {curve, dots, dm, t:0}; };
    u.hpFlows = {
      vvIn:  flow(ortho([L3(WALLX,1.10,1.22), L3(WALLX,COL_H+0.20,1.22), L3(WALLX,COL_H+0.20,1.15)]), 0xd9564a),          // aanvoer vloerverwarming
      vvOut: flow(ortho([L3(WALLX-0.05,COL_H+0.08,1.05), L3(WALLX-0.05,COL_H+0.08,1.32), L3(WALLX-0.05,1.10,1.32)]), 0x4f86d6),
      coil:  flow(ortho([L3(WALLX,1.10,1.36), L3(WALLX,0.12,1.36), L3(6.05,0.12,1.36), L3(6.05,0.12,1.45)]), 0x9b6fd6),     // onderzijde binnenunit → onderzijde boiler
      buiten:flow(ortho([L3(WALLX,COL_H+0.3,0.22), L3(WALLX,0.42,0.22), L3(WALLX,0.42,1.18), L3(WALLX,1.12,1.18)]), 0x888888, 10, false),   // (v58) laag langs de muur         // leidingen van de buitenunit (in de muur)
    };
    // vloerverwarming begane grond: warme gloed over de vloer tijdens verwarmen
    u.floorGlow = new THREE.MeshBasicMaterial({color:0xff7a3d, transparent:true, opacity:0, depthWrite:false, blending:THREE.AdditiveBlending});
    const fg = new THREE.Mesh(new THREE.PlaneGeometry(W_M-0.2, D_M-0.2), u.floorGlow); fg.rotation.x = -Math.PI/2; fg.position.set(0, 0.012, 0); house.add(fg);
    const hit = new THREE.Mesh(new THREE.BoxGeometry(.8,1.6,1.4), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(mx(6.05),.8,mz(1.5)); hit.userData.room = r; upWalls.add(hit); pickables.push(hit);
  }
  // Weheat-buitenunit(s) (bij de buitenruimte-lus eenmalig)
  if(r.id==='buiten'){
    Object.values(HP).filter(u=>u.pos).forEach(u=>{
      const g = new THREE.Group();
      const cab = new THREE.Mesh(new THREE.BoxGeometry(1.25,.70,.42), new THREE.MeshStandardMaterial({color:0x3a3d41, roughness:.6, metalness:.2}));
      cab.position.y = .35+.12; cab.castShadow = true;   // (v33) breder en minder hoog
      const feet = new THREE.Mesh(new THREE.BoxGeometry(1.15,.12,.36), new THREE.MeshStandardMaterial({color:0x222}));
      feet.position.y = .06;
      const grille = new THREE.Mesh(new THREE.CircleGeometry(.26,32), new THREE.MeshStandardMaterial({color:0x1b1d20, roughness:.8}));
      grille.position.set(-.25,.47,.212);
      const fan = new THREE.Group(); fan.position.set(-.25,.47,.215);
      for(let k=0;k<3;k++){ const bl = new THREE.Mesh(new THREE.BoxGeometry(.05,.26,.01), new THREE.MeshStandardMaterial({color:0x8a9096})); bl.position.y = .13; const arm = new THREE.Group(); arm.rotation.z = k*Math.PI*2/3; arm.add(bl); fan.add(arm); }
      u.ledMat2 = new THREE.MeshStandardMaterial({color:0x222, emissive:0xff8a3d, emissiveIntensity:0});
      const led = new THREE.Mesh(new THREE.BoxGeometry(.18,.02,.01), u.ledMat2); led.position.set(.38,.70,.213);
      g.add(feet, cab, grille, fan, led);
      g.position.set(mx(u.pos[0]), gradeAt(mx(u.pos[0]), mz(u.pos[1])), mz(u.pos[1])); if(u.face==='y-') g.rotation.y = Math.PI;
      g.userData.noMerge = true; scene.add(g); garden.push(g); u.fan = fan; u.group = g; dev(g, 'Weheat buitenunit');
      const hit = new THREE.Mesh(new THREE.BoxGeometry(1.35,.9,.6), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(0,.47,0); hit.userData.room = r; hit.userData.hp = u; g.add(hit); pickables.push(hit);
    });
  }
  // Hue bewegingssensor
  if(r.sensor && r.sensor.pos){
    const [sx,sy] = r.sensor.pos;
    const body = new THREE.Mesh(new THREE.BoxGeometry(.03,.055,.055), new THREE.MeshStandardMaterial({color:0xf2f2ef, roughness:.4}));
    const sh = r.sensor.h ?? 2.1, sg = r.sensor.grp==='walls' ? walls : ceilGroup;   // (v78) hoogte + groep instelbaar
    body.position.set(mx(sx), sh, mz(sy)); wallMount(body, sh, sg); dev(body, 'Hue-sensor '+r.name, 'sensor');
    r.sensor.ledMat = new THREE.MeshStandardMaterial({color:0x111111, emissive:0x46d17a, emissiveIntensity:0});
    const led = new THREE.Mesh(new THREE.SphereGeometry(.012,8,8), r.sensor.ledMat);
    led.position.set(mx(sx)-0.018, sh, mz(sy)); wallMount(led, sh, sg);
  }
});

