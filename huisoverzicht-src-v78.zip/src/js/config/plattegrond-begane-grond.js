/* ---------- Plattegrond (binnenmaten in meters; x = links→rechts, y = boven→onder op de schets) ---------- */
const W_M = 10.52, D_M = 6.7;                 // 1,7+2,1+1,5+1,17+4,05  ×  woonkamer 6,7
const mx = x => x - W_M/2, mz = y => y - D_M/2;
const H_WOON = 3.0, H_REST = 2.8;

// Dichte muren: [x1,y1,x2,y2, hoogte]
const SOLID = [
  // gevels
  [0,0,1.85,0,H_REST], [3.65,0,5.3,0,H_REST],             // boven (raam trap en voordeur ertussen)
  [0,6.7,5.3,6.7,H_REST],                                  // onder (tot aan de achterdeur)
  [0,0,0,2.9,H_REST], [0,5.7,0,6.7,H_REST],               // links (schuifpui ertussen)
  // binnenmuren
  [1.7,0,1.7,2.5,H_REST],                                  // dressing | trap
  [1.7,2.5,3.75,2.5,H_REST],                               // trap | slaapkamer + stukje badkamer
  [3.8,0,3.8,1.2,H_REST], [3.8,1.2,4.0,1.2,H_REST], [4.75,1.2,5.3,1.2,H_REST], [5.3,0,5.3,1.2,H_REST],   // WC 1,5 × 1,2 (deur 4,0–4,75)
  [4.6,2.5,4.7,2.5,H_REST],                                // stukje muur naast de slaapkamerdeur
  [4.7,2.0,4.7,4.7,H_REST],                                // badkamer | keuken 2,7
  [4.7,2.0,5.3,2.0,H_REST], [4.7,4.7,5.3,4.7,H_REST],     // sprongen 0,6
  [5.3,4.7,5.3,6.7,H_REST],                                // 1,91
  [4.2,3.2,4.7,3.2,H_REST],                                // wandje 0,5 in badkamer
  [6.47,0,6.47,2.3,H_REST],                                // hal | woonkamer 2,3
  [6.47,5.4,6.47,6.7,H_REST],                              // keuken | woonkamer 1,3
];

// Glas: van a naar b, kolombreedtes, rijhoogtes (van onder), muur erboven tot wallTo
const GLASS = [
  {a:[1.85,0], b:[3.65,0], cols:[1.8], rows:[0.5], sill:0.5, wallTo:H_REST, room:'trap'},   // raam trap: vanaf 0,5 m, 0,5 m hoog
  {a:[6.47,0], b:[10.52,0], cols:[2.025,2.025], rows:[2.5,0.5], wallTo:H_WOON, room:'woon'},     // korte zijde
  {a:[10.52,0], b:[10.52,6.7], cols:[2.5,2.5,1.7], rows:[2.5,0.5], wallTo:H_WOON, room:'woon'},  // lange zijde
  {a:[6.47,6.7], b:[10.52,6.7], cols:[2.025,2.025], rows:[2.5,0.5], wallTo:H_WOON, room:'woon'}, // korte zijde
  {a:[0,2.9], b:[0,5.7], cols:[1.4,1.4], rows:[2.5], wallTo:H_REST, room:'slaap', slide:true},   // schuifpui
  {a:[3.4,2.5], b:[3.4,6.7], cols:[4.2], rows:[2.5], wallTo:H_REST, room:'bad', frameless:true}, // glaswand zonder kozijn
];
// Deuren begane grond: [x1,y1,x2,y2, scharnier bij punt 1 (1) of 2 (2), draait naar kant +y/+x (1) of −y/−x (−1), openingshoek °]
const G_DOORS = [
  [3.8,2.5,4.6,2.5, 1,-1, 50],     // hal → slaapkamer (tekening Bas 25-09)
  [4.0,1.2,4.75,1.2, 2, 1, 50],    // hal → wc
];
// (v41) voordeur en achterdeur: centraal in de hal (tussen keuken en woonkamer, x 5,3–6,47), deur 100 × 260 cm in een meranti kader
const HAL_DOOR = {x0:5.3, x1:6.47, xc:(5.3+6.47)/2, w:1.0, h:2.6};
const WK_IN = 0.10;   // (v55) woonkamer (alu) aan voor- en achterkant 10 cm smaller dan het houten achterhuis: dakrand en sokkel springen 10 cm in
const POSTS = [[10.52,0,H_WOON],[10.52,6.7,H_WOON],[6.47,0,H_WOON],[6.47,6.7,H_WOON]];

// Ruimtes: rechthoeken [x1,y1,x2,y2] (eerste = plek van het label).
// t/h = Home Assistant-sensor temperatuur/luchtvochtigheid, clim = airco (current_temperature), motion = Hue-bewegingssensor.
// Lampen: [x, y, naam, aan, soort, HA-entity, status]  soort: spot | floor | pendant | tl | unplaced ; status 'nc' = nog niet aangesloten
const rooms = [
  {id:'woon',   name:'Woonkamer',  floor:0, ceil:H_WOON, rects:[[6.47,0,10.52,6.7]],
    t:'sensor.hue_motion_sensor_2_temperatuur', clim:'climate.airco_living', temp:21.4, target:21,
    sensor:{ha:'binary_sensor.hue_motion_sensor_2_beweging', luxHa:'sensor.hue_motion_sensor_2_licht', motion:false, lux:40},
    lamps:[[9.4,1.0,'Televisie',true,'floor','light.televisie'],[9.4,5.95,'Eettafel',true,'floor','light.eettafel']]},
  {id:'hal',    name:'Hal',        floor:0, ceil:H_REST, rects:[[5.3,0,6.47,6.7]],
    t:'sensor.hal_temperatuur', temp:18.7,
    sensor:{ha:'binary_sensor.hal_beweging', luxHa:'sensor.hal_licht', motion:false, lux:12},
    lamps:[[5.9,1.2,'Spot 1',false,'spot','light.lucas','broken'],[5.9,2.7,'Spot 2',true,'spot','light.keuken_2'],[5.9,4.2,'Spot 3',true,'spot','light.keuken_3'],[5.9,5.7,'Spot 4',true,'spot','light.keuken_4'],
]},
  {id:'hal-wc', name:'Hal',        floor:0, ceil:H_REST, rects:[[3.8,1.2,4.7,2.5],[4.7,1.2,5.3,2.0]], note:'Halletje bij wc, trap en slaapkamer',
    t:'sensor.hal_temperatuur', temp:18.7,
    lamps:[[4.65,2.25,'Wandlamp',false,'wall','light.hal_bg',null,'x-',1.8]]},
  {id:'keuken', name:'Keuken',     floor:0, ceil:H_REST, rects:[[4.7,2.0,5.3,4.7]], note:'3 IKEA-spots, samen één Hue-groep "Keuken 1"',
    lamps:[[5.0,2.45,'Spot 1',true,'spot','light.keuken_1_2'],[5.0,3.35,'Spot 2',true,'spot','light.keuken_1_2'],[5.0,4.25,'Spot 3',true,'spot','light.keuken_1_2']]},
  {id:'wc',     name:'WC',         floor:0, ceil:H_REST, rects:[[3.8,0,5.3,1.2]],
    t:'sensor.motion_toilet_temperatuur', temp:18.2,
    sensor:{ha:'binary_sensor.motion_toilet_beweging', luxHa:'sensor.motion_toilet_licht', motion:false, lux:14, pos:[3.9,0.2], h:2.7, auto:true},   // (v78) bovenaan in de hoek bij de noordmuur (x 3,8)
    lamps:[[4.55,0.6,'Spot',false,'spot','light.toilet_bg']]},
  {id:'bad',    name:'Badkamer',   floor:0, ceil:H_REST, rects:[[3.4,4.7,5.3,6.7],[3.4,2.5,4.7,4.7]],
    lamps:[[3.85,3.1,'Spot 2',true,'spot','light.badkamer_2'],[3.85,4.1,'Spot 1',true,'spot','light.badkamer_1'],   /* (v53) omgewisseld */[3.85,5.45,'Spot 3',false,'spot',null,'nc'],[4.85,5.45,'Spot 4',false,'spot',null,'nc']]},
  {id:'trap',   name:'Verdiepingstrap', floor:0, ceil:H_REST, rects:[[1.7,0,3.8,2.5]], hole:true, lamps:[]},
  {id:'dress',  name:'Dressing',   floor:0, ceil:H_REST, rects:[[0,0,1.7,2.5]],
    lamps:[[0.85,0.75,'Spot 2',false,'spot','light.dressing_2'],[0.85,1.75,'Spot 1',false,'spot','light.dressing_1']]   /* (v53) omgewisseld volgens Bas */},
  {id:'slaap',  name:'Slaapkamer Bas & Debbie', floor:0, ceil:H_REST, rects:[[0,2.5,3.4,6.7]],
    clim:'climate.airco_bas_en_debbie', temp:18.1, target:18,
    lamps:[[0.95,3.75,'Spot 2',false,'spot','light.slaapkamer_2'],[2.45,3.75,'Spot 4',false,'spot','light.slaapkamer_4'],[0.95,5.0,'Spot 1',false,'spot','light.slaapkamer_1'],[2.45,5.0,'Spot 3',false,'spot','light.slaapkamer_3']]   /* (v54) schets Bas: bij tv=_4, daaronder=_3, raamkant achter=_1, raamkant voor=_2 */},
  // Buiten: 4 grondspots in de hoeken van het terras (AANNAME), 2 Hue Appear-wandlampen links en rechts van het trapraam in de voorgevel
  {id:'buiten', name:'Tuin & terras', floor:0, outdoor:true, ceil:2.4, rects:[[6.47,-4.0,10.02,0]],
    // (v74) 4 terraslampen op twee paaltjes in de zwarte aarde naast de buitenrand van terras noord (kant klimop), gericht op het terras
    lamps:[[-4.55,4.53,'Terras LB',false,'post','light.terras_lb','broken','x+',0.8],[-4.55,4.67,'Terras RB',false,'post','light.terras_rb','broken','x+',0.8],
           [-4.55,1.13,'Terras LO',false,'post','light.terras_lo','broken','x+',0.8],[-4.55,1.27,'Terras RO',true,'post','light.terras_ro',null,'x+',0.8],
           [4.53,-0.17,'Appear links',true,'outwall','light.hue_appear_outdoor_wall_links',null,'y-',1.6],[0.63,-0.17,'Appear rechts',true,'outwall','light.hue_appear_outdoor_wall_rechts',null,'y-',1.6],
           [null,null,'Buitenlamp voordeur',false,'unplaced','light.buitenlamp_voordeur'],[null,null,'Tuin',false,'unplaced','light.tuin'],
           [null,null,'Buitenverlichting',false,'unplaced','light.buiten_verlichting'],[null,null,'Pomp (vijver)',false,'unplaced','light.pomp']]}
];

