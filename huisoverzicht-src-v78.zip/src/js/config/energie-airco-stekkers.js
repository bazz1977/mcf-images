const PV_KWP = 17*0.395;         // 17 panelen × 395 Wp
const energy = {pv:3.4, batt:76, battW:-900, house:850, grid:-1600, pvToday:11.2, impToday:2.4, expToday:5.1};
// Tekenconventies (controleren in HA): batterijvermogen positief = ontladen, P1-vermogen positief = afname van het net
const BATT_POS_IS_DISCHARGE = true, GRID_POS_IS_IMPORT = true;

// Airco's (LG): positie op de muur [x, y], richting de kamer in, hoogte
const CLIMATE = {
  woon:   {ent:'climate.airco_living',          kwh:'sensor.living_airco_living_energy_today',           pos:[6.53,6.05], face:'x+', h:2.35, cap:'5,0 kW'},
  slaap:  {ent:'climate.airco_bas_en_debbie',   kwh:'sensor.bas_debbie_airco_bas_en_debbie_energy_today', pos:[0.16,6.2],  face:'x+', h:2.3, cap:'3,5 kW'},
  jolie:  {ent:'climate.airco_jolie',           kwh:'sensor.jolie_airco_jolie_energy_today',             pos:[0.16,3.9],  face:'x+', h:2.1},
  lucas2: {ent:'climate.airco_lucas',           kwh:'sensor.lucas_airco_lucas_energy_today',             pos:[9.86,4.3],  face:'x-', h:2.0},   // kelder, rechtermuur Lucas 2
  amelie: {ent:'climate.airco_amelie',          kwh:'sensor.amelie_airco_amelie_energy_today',           pos:[0.16,5.0],  face:'x+', h:2.0},   // zijgevel kamer Amélie
};
const HVAC_NL = {off:'Uit', cool:'Koelen', heat:'Verwarmen', heat_cool:'Auto', auto:'Auto', dry:'Drogen', fan_only:'Ventilator'};
// Slimme stekkers per ruimte: [naam, schakelaar, vermogen]
const PLUGS = {
  woon:   [['Tv','switch.stekker_9','sensor.stekker_9_vermogen',[10.2,1.9,0,'floor']],['Pelletkachel','switch.aquarium_2','sensor.aquarium_vermogen',[10.2,2.2,0,'floor']],['Slimme stekker','switch.slimme_stekker','sensor.slimme_stekker_vermogen']],   // (v56) IKEA-stekker 'Pelletkachel' (was 'Aquarium'), vloerstopcontact naast de tv-stekker; entity_id blijft switch.aquarium_2 tenzij hernoemd in HA (anders gezocht op 'pellet')
  keuken: [['Oven','switch.inspelning_smart_plug_4','sensor.inspelning_smart_plug_vermogen_4',[4.76,4.05,0.3,'x+']],['Vaatwasser','switch.inspelning_smart_plug_5','sensor.inspelning_smart_plug_vermogen_5',[4.76,3.3,0.3,'x+']],['Koelkast','switch.inspelning_smart_plug_6','sensor.inspelning_smart_plug_vermogen_6',[4.76,2.2,0.3,'x+']]],
  'bad-boven': [['Wasmachine','switch.inspelning_smart_plug','sensor.inspelning_smart_plug_vermogen',[3.91,1.97,0.3,'x+']],['Droger','switch.inspelning_smart_plug_2','sensor.inspelning_smart_plug_vermogen_2',[3.91,1.84,0.3,'x+']]],   // (v65) badkamer boven, linksonder op de rechterzijmuur
  slaap:  [['Tv','switch.inspelning_smart_plug_7','sensor.inspelning_smart_plug_vermogen_7']],
  lucas:  [['Pc','switch.stekker_10','sensor.stekker_10_vermogen'],['Tv','switch.tv_lucas','sensor.tv_lucas_vermogen'],['Vijverpomp','switch.inspelning_smart_plug_11','sensor.inspelning_smart_plug_vermogen_11'],['Vijverpomp 2','switch.inspelning_smart_plug_8','sensor.inspelning_smart_plug_vermogen_8'],['Starlink',null,'sensor.starlink_vermogen']],
  'k-hal':  [['Regenwaterpomp (regenput)','switch.stekker_12','sensor.stekker_12_vermogen',[5.8,0.16,0.3,'y+']],
             ['Koelkast kelder','switch.inspelning_smart_plug_9','sensor.inspelning_smart_plug_vermogen_9',[5.8,2.54,0.3,'y-']]],   // tegenover de regenput
  buiten: [['Vijverpomp (waterbekken)', null, null], ['Zwembadpomp', null, null]],   // (v76) zwembadpomp op het buitenstopcontact (trapmuurtje): nog niet gekoppeld in HA → schakelaar + vermogen invullen   // (v75) pomp in de put bij de vijver; stopcontact nog niet gekoppeld in HA → schakelaar + vermogen hier invullen
  'k-tech':[['Patchkast','switch.inspelning_smart_plug_3','sensor.inspelning_smart_plug_vermogen_3',[1.66,0.16,0.25,'y+']]],   // (v65) rechtsonder op de voorgevelmuur
};
