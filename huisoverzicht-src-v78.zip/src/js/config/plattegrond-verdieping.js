// ---------- Verdieping (zelfde oriëntatie: boven op de schets = voorgevel) ----------
const F1 = 3.05;                 // vloer verdieping (plafond 2,8 + vloer)
const KNEE = 0.6;                // knieschot/goot boven vloer verdieping (aanname)
const RIDGE_Y = 2.5, RIDGE_H = 3.7, PITCH_W = 6.47, CEIL_UP = 2.6;
const roofH = y => y<=RIDGE_Y ? KNEE+(RIDGE_H-KNEE)*y/RIDGE_Y : KNEE+(RIDGE_H-KNEE)*(D_M-y)/(D_M-RIDGE_Y);
const STAIR = {x:2.75, y:1.1, r:1.0};
const UP_WALLS = [
  [1.7,0,1.7,2.1], [1.7,2.1,3.0,2.1],            // kamer Jolie | overloop
  [3.0,3.0,3.0,6.7], [3.0,3.0,3.85,3.0],         // kamer Jolie | kamer Lucas, gangetje
  [3.85,0,3.85,2.1], [3.85,2.1,4.7,2.1], [5.6,2.1,6.47,2.1],   // badkamer boven, deur vanuit kamer Lucas (4,7–5,6)
];
const STARLINK = [6.05, 6.3];                   // Starlink-router in de uiterste hoek van kamer Lucas (UTP naar Omada ER605 in de technische ruimte)
const STARLINK_DISH = [10.05, 6.2];   // (v37) binnen de dakrand              // schotel op het platte dak, achterhoek
const UP_HEADERS = [[3.85,2.1,3.85,3.0],[4.7,2.1,5.6,2.1]];   // lateien boven de deuren van kamer Lucas
rooms.push(
  {id:'overloop', name:'Overloop',    floor:1, rects:[[1.7,0,3.85,2.1],[3.0,2.1,3.85,3.0]], hole:true,
    sensor:{ha:null, luxHa:null, match:/overloop|trap|hal.?boven|boven/i, motion:false, lux:5, pos:[2.75,1.1], h:F1+0.93, grp:'walls'},   // (v78) Hue-sensor bovenop de spil van de trap; entity nog koppelen
    lamps:[[3.8,1.6,'Hal boven',false,'wall','light.hal_boven',null,'x-',2.1]]},
  {id:'jolie',    name:'Kamer Jolie', floor:1, rects:[[0,2.1,3.0,6.7],[0,0,1.7,2.1]],
    clim:'climate.airco_jolie', temp:18.6, target:18,
    lamps:[[1.65,1.05,'Verdieping Jolie',false,'wall','light.verdieping_jolie',null,'x-',1.5],[2.6,2.15,'Deur Jolie',false,'wall','light.deur_jolie',null,'y+',1.8]]},
  {id:'lucas',    name:'Kamer Lucas', floor:1, rects:[[3.0,3.0,6.47,6.7],[3.85,2.1,6.47,3.0]],
    starlink:true,
    lamps:[[3.92,2.55,'Boven de deur (IKEA)',false,'wall',null,null,'x+',2.25],[3.42,3.05,'Wandlamp (IKEA)',false,'wall',null,null,'y+',1.8],[null,null,'Hue-stekker',true,'unplaced','light.hue_smart_plug_1']]},
  {id:'bad-boven',name:'Badkamer boven', floor:1, rects:[[3.85,0,6.47,2.1]], lamps:[]},
);
