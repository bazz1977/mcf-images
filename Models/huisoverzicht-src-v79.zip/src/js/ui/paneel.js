/* ---------- Paneel ---------- */
const $ = id=>document.getElementById(id);
function sparkSVG(h){
  const W=300,H=64,P=4;
  const min=Math.min(...h)-0.3, max=Math.max(...h)+0.3;
  const x=i=>P+i*(W-2*P)/(h.length-1), y=v=>H-P-(v-min)/(max-min)*(H-2*P);
  const pts=h.map((v,i)=>`${x(i).toFixed(1)},${y(v).toFixed(1)}`);
  const last=h.length-1;
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Temperatuurverloop laatste 24 uur">
    <line x1="${P}" x2="${W-P}" y1="${H/2}" y2="${H/2}" stroke="#26323c" stroke-dasharray="3 4"/>
    <path d="M${pts[0]} L${pts.join(' L')} L${x(last)},${H} L${x(0)},${H} Z" fill="rgba(255,196,107,.12)"/>
    <polyline points="${pts.join(' ')}" fill="none" stroke="#ffc46b" stroke-width="2" stroke-linejoin="round"/>
    <circle cx="${x(last)}" cy="${y(h[last])}" r="3.5" fill="#ffc46b"/>
  </svg>`;
}
function renderPanel(){
  const tR = rooms.filter(r=>r.temp!=null), hR = rooms.filter(r=>r.hum!=null);
  const avgT = tR.length ? tR.reduce((s,r)=>s+r.temp,0)/tR.length : null;
  const avgH = hR.length ? hR.reduce((s,r)=>s+r.hum,0)/hR.length : null;
  const live = lampList.filter(l=>!l.nc), on = live.filter(l=>l.on).length;
  $('stats').innerHTML = `
    <div class="stat"><small>Gem. binnen</small><strong>${fmt(avgT)}</strong><em> °C</em></div>
    <div class="stat"><small>Buiten${(()=>{ const o = outsideNow(); return o.fc ? ' · '+String(Math.floor(sky.simMin/60)).padStart(2,'0')+':'+String(sky.simMin%60).padStart(2,'0') : ''; })()}</small><strong>${fmt(outsideNow().temp)}</strong><em> °C · ${(()=>{ const o = outsideNow(); return o.wind==null ? '–' : bft(o.wind)+' Bft '+windDir(o.bearing); })()}</em></div>
    <div class="stat"><small>Luchtvochtigheid</small><strong>${rnd(avgH)}</strong><em> % RV</em></div>
    <div class="stat"><small>Lampen aan</small><strong>${on}</strong><em> / ${live.length}</em></div>
    <div class="stat"><small>Zonnepanelen</small><strong>${fmt(energy.pv)}</strong><em> kW</em></div>
    <div class="stat"><small>Thuisbatterij</small><strong>${rnd(energy.batt)}</strong><em> %</em></div>
    <div class="stat"><small>Starlink</small><strong style="color:${starlink.ok?'var(--ok)':'var(--warn)'}">${starlink.ok?rnd(starlink.ping):'–'}</strong><em> ${starlink.ok?'ms':'offline'}</em></div>
    <div class="stat"><small>Download</small><strong>${rnd(starlink.down)}</strong><em> Mbit/s</em></div>`;

  const r = selected, h = r.hist;
  $('detail').innerHTML = `
    <p class="eyebrow">Geselecteerde ruimte</p>
    <h2>${r.name}</h2>
    <div class="sub">${FLOOR_NAME[r.floor]} · ${fmt(r.area,1)} m² · ${r.floor===1?"onder schuin dak":r.floor===-1?"hoogte "+fmt(K_H,1)+" m":"plafond "+fmt(r.ceil,1)+" m"}</div>
    <div class="readings">
      <div><small>Temperatuur</small>${r.temp!=null?`<strong>${fmt(r.temp)}</strong> °C`:'<strong style="color:var(--faint)">–</strong>'}</div>
      <div><small>Luchtvochtigheid</small>${r.hum!=null?`<strong style="color:${r.hum>=65?'var(--warn)':'var(--hum)'}">${Math.round(r.hum)}</strong> %`:'<strong style="color:var(--faint)">–</strong>'}</div>
    </div>
    ${!r.hasT && !r.hasH ? '<div class="sub">Geen temperatuur- of vochtsensor in deze ruimte.</div>' : ''}
    ${r.clim ? `<div class="setpoint">
      <span>Airco${r.climState?' · '+(CLIM_NL[r.climState]||r.climState):''} · doel</span>
      <div class="ctl">
        <button id="sp-down" aria-label="Doeltemperatuur lager">−</button>
        <b>${fmt(r.target)} °C</b>
        <button id="sp-up" aria-label="Doeltemperatuur hoger">+</button>
      </div>
    </div>` : ''}
    ${r.ac ? `<div class="modes" role="group" aria-label="Airco-stand">${(r.acModes||[]).filter(m=>HVAC_NL[m]).map(m=>`<button class="mini" data-hvac="${m}" aria-pressed="${r.climState===m}">${HVAC_NL[m]}</button>`).join('')}</div>
      <div class="sub" style="margin-top:6px">LG airco${r.ac.cap?' '+r.ac.cap:''} · vandaag ${r.ac.kwh!=null?fmt(r.ac.kwh,2)+' kWh':'–'}</div>` : ''}
    ${lockHTML(r)}
    ${regenHTML(r)}
    ${mediaHTML(r)}
    ${r.plugs.length ? `<div class="plughead"><p class="eyebrow">Stekkers · ${fmtW(roomW(r))}</p>${r.plugs.some(p=>p.sw&&p.on&&!p.pool)?'<button class="mini" id="plugs-off">Alles uit</button>':''}</div>
      ${r.plugs.map((p,i)=>`<div class="plug"><span>${p.name}${p.pool?`<span class="lock" title="Veiligheidspool: ${p.pool==='nooit-uit'?'kan niet uit':'alleen na bevestiging'}">🔒 ${p.pool==='nooit-uit'?'nooit uit':'pool'}</span>`:''}${!p.sw && !p.pw ? ' <span style="color:var(--faint)">· nog niet gekoppeld in HA</span>' : p.pos?'':' <span style="color:var(--faint)">· niet ingetekend</span>'}</span><span class="v">${fmtW(p.w)}</span>${p.sw?`<button class="sw${p.pool==='nooit-uit'&&p.on?' locked':''}" data-plug="${i}" aria-pressed="${p.on}" aria-label="${p.name} aan/uit"></button>`:'<span></span>'}</div>`).join('')}` : ''}
    ${r.lampKwhEnt ? `<div class="sub" style="margin-top:8px">Lampverbruik (Modbus): ${fmt(r.lampKwh,1)} kWh totaal</div>` : ''}
    ${r.tech ? `<div class="setpoint"><span>GoodWe omvormer</span><div class="ctl"><b>${fmt(energy.pv)} kW</b></div></div>
    <div class="setpoint"><span>BYD HVS thuisbatterij</span><div class="ctl"><b>${rnd(energy.batt)} %</b></div></div>
    <div class="sub" style="margin-top:6px">Patchkast: Omada ER605-router, Hue Bridge, Home Assistant · Starlink komt binnen via UTP vanaf de router in kamer Lucas</div>` : ''}
    ${r.starlink ? `<div class="setpoint"><span>Starlink</span><div class="ctl"><b style="color:${starlink.ok?'var(--ok)':'var(--warn)'}">${starlink.ok?'Verbonden':'Offline'}</b> · ${rnd(starlink.ping)} ms · ${rnd(starlink.down)}/${rnd(starlink.up)} Mbit/s</div></div>` : ''}
    <p class="eyebrow" style="margin:14px 0 0">Verlichting · Philips Hue${r.lampObjs.length?' · '+r.lampObjs.length+' lamp'+(r.lampObjs.length>1?'en':''):''}</p>
    ${r.note ? `<div class="sub" style="margin-top:4px">${r.note}</div>` : ''}
    ${r.lampObjs.length ? `<div class="lamps">${r.lampObjs.map(l=>`<button class="lampbtn" data-lamp="${l.i}" aria-pressed="${l.on}" ${l.nc?`disabled title="${STATUS_NL[l.status]||''}" style="opacity:.45;cursor:not-allowed"`:''} ${!l.placed?'title="Nog niet ingetekend in het model"':''}><i ${l.on&&!l.nc?`style="background:rgb(${lampRGB(l)});box-shadow:0 0 8px rgb(${lampRGB(l)})"`:''}></i>${l.name}${l.nc?' · '+(STATUS_NL[l.status]||''):''}${!l.placed?' ·&nbsp;niet ingetekend':''}</button>`).join('')}</div>` : `<div class="sub" style="margin-top:6px">Geen lampen in deze ruimte.</div>`}
    ${lampCtlHTML(r)}
    ${r.sensor ? `<div class="setpoint"><span>Hue-sensor</span><div class="ctl"><b style="color:${r.sensor.motion?'var(--ok)':'var(--muted)'}">${r.sensor.motion?'Beweging':'Geen beweging'}</b> · ${rnd(r.sensor.lux)} lux</div></div>` : ''}
    ${h ? `<div class="spark">
      <div class="cap"><span>Laatste 24 uur</span><span>${fmt(Math.min(...h))} – ${fmt(Math.max(...h))} °C</span></div>
      ${sparkSVG(h)}
      <div class="cap"><span>−24 u</span><span>nu</span></div>
    </div>` : ''}`;
  if(r.clim){ const setT = d=>{ r.target = Math.min(30, Math.max(16, (r.target??21)+d)); renderPanel();
      if(LIVE && ha) ha.call('climate','set_temperature',{entity_id:r.clim, temperature:r.target}).catch(()=>{}); };
    $('sp-down').onclick = ()=>setT(-0.5); $('sp-up').onclick = ()=>setT(0.5); }
  if($('lockbtn')) $('lockbtn').onclick = lockAction;
  $('detail').querySelectorAll('[data-media]').forEach(b=>b.onclick=()=>mediaAction(b.dataset.media, b.dataset.act, b.dataset.val));
  $('detail').querySelectorAll('[data-src]').forEach(sel=>sel.onchange=()=>mediaAction(sel.dataset.src, 'source', sel.value));
  $('detail').querySelectorAll('[data-vol]').forEach(inp=>inp.onchange=()=>mediaAction(inp.dataset.vol, 'volume', +inp.value/100));
  $('detail').querySelectorAll('[data-hvac]').forEach(b=>b.onclick=()=>{ const m = b.dataset.hvac; r.climState = m; applyAC(); renderPanel();
    if(LIVE && ha) ha.call('climate','set_hvac_mode',{entity_id:r.clim, hvac_mode:m}).catch(()=>{}); });
  $('detail').querySelectorAll('[data-plug]').forEach(b=>b.onclick=async()=>{ const p = r.plugs[+b.dataset.plug], want = !p.on;
    if(p.pool==='nooit-uit' && !want){ await askConfirm(`${p.name} kan niet uit`, `${p.name} (${r.name}) staat in de veiligheidspool als ‘nooit uit’. Uitzetten kan alleen in Home Assistant zelf.`, null); return; }
    if(p.pool && !await askConfirm(`${p.name} ${want?'aanzetten':'uitzetten'}?`, `${p.name} (${r.name}) zit in de veiligheidspool.${want?'':' Uitzetten betekent dat het apparaat geen stroom meer krijgt.'}`, want?'Aanzetten':'Uitzetten')) return;
    setPlug(p, want); });
  const po = $('plugs-off'); if(po) po.onclick = async()=>{ const off = r.plugs.filter(p=>p.sw && p.on && !p.pool), kept = r.plugs.filter(p=>p.sw && p.on && p.pool);
    if(!await askConfirm(`Alle stekkers in ${r.name} uit?`, `Gaat uit: ${off.map(p=>p.name).join(', ')}.${kept.length?` Blijft aan (veiligheidspool): ${kept.map(p=>p.name).join(', ')}.`:''}`, 'Alles uit')) return;
    off.forEach(p=>setPlug(p, false)); };
  renderEnergy(); applyPlugs();
  $('detail').querySelectorAll('[data-lamp]').forEach(b=>b.onclick=()=>{ const l = r.lampObjs[+b.dataset.lamp]; if(!l.nc) lampSel[r.id] = l.ha || 'i'+l.i; toggleLamp(l); });
  if($('lc-sel')) $('lc-sel').onchange = e=>{ lampSel[r.id] = e.target.value; renderPanel(); };
  bindCtl($('detail')); renderGroups();

  renderAlerts(); renderHP(); renderNet(); applyNet();

  $('list').innerHTML = [0,1,-1].map(f=>`<div class="floorhead">${FLOOR_NAME[f]}</div>` + rooms.filter(x=>x.floor===f).map(x=>{
    const any = x.lampObjs.some(l=>l.on);
    const sw = x.lampObjs.some(l=>!l.nc);
    return `<div class="row ${x===selected?'sel':''}" data-room="${x.id}">
      <span class="n">${x.name}</span>
      <span class="v">${x.temp!=null?fmt(x.temp)+' °C':'–'}</span>
      <span class="v h ${x.hum!=null&&x.hum>=65?'warn':''}">${x.hum!=null?Math.round(x.hum)+'%':'–'}</span>
      ${sw ? `<button class="sw" data-sw="${x.id}" aria-pressed="${any}" aria-label="Licht ${x.name}"></button>` : '<span></span>'}
    </div>`;
  }).join('')).join('');
  $('list').querySelectorAll('.row').forEach(el=>el.onclick=e=>{
    if(e.target.closest('.sw')) return;
    select(byId[el.dataset.room]);
  });
  $('list').querySelectorAll('.sw').forEach(b=>b.onclick=()=>{
    const x = byId[b.dataset.sw];
    setRoomLamps(x, !x.lampObjs.some(l=>l.on));
  });
}
const LOCK_NL = {locked:'Op slot', unlocked:'Niet op slot', open:'Open', opening:'Wordt geopend…', unlocking:'Wordt geopend…', locking:'Wordt vergrendeld…', jammed:'Geblokkeerd!', unavailable:'Niet bereikbaar'};
function lockHTML(r){
  if(ANON || r.id!==LOCK.room) return '';
  const st = LOCK.state, locked = st==='locked', col = locked ? 'var(--ok)' : st==='jammed' ? 'var(--warn)' : st ? 'var(--lamp)' : 'var(--muted)';
  return `<div class="setpoint"><span>🔒 ${LOCK.name}</span><div class="ctl"><b style="color:${col}">${LOCK_NL[st]||st||'–'}</b>
    ${LOCK.ent||!LIVE ? `<button class="mini" id="lockbtn" style="width:auto;height:auto">${locked?'Openen':'Op slot'}</button>` : ''}</div></div>
    ${LIVE && !LOCK.ent ? '<div class="sub">Slot nog niet gevonden in Home Assistant (zoekt lock.* met “bold”/“voordeur”).</div>' : ''}`;
}
async function lockAction(){
  const locked = LOCK.state==='locked';
  if(locked && !await askConfirm('Voordeur openen?', 'De Bold smart lock op de voordeur wordt ontgrendeld.', 'Openen')) return;
  LOCK.state = locked ? 'unlocked' : 'locked'; applyPlugs(); renderPanel();
  if(LIVE && ha && LOCK.ent) ha.call('lock', locked ? 'unlock' : 'lock', {entity_id:LOCK.ent}).catch(()=>{});
  if(!LIVE && locked) setTimeout(()=>{ LOCK.state = 'locked'; applyPlugs(); renderPanel(); }, 8000);   // demo: Bold valt vanzelf terug in het slot
}
function mediaOn(m){ return !['off','standby','unavailable','unknown',null,undefined].includes(m.state); }
function mediaHTML(r){
  const items = Object.entries(MEDIA).filter(([,m])=>m.room===r.id);
  if(!items.length) return '';
  return items.map(([k,m])=>{
    const a = m.a||{}, on = mediaOn(m);
    const vol = a.volume_level!=null ? Math.round(a.volume_level*100) : null;
    const what = (k==='tv'||m.simple) ? (a.media_title || APP_NL[a.app_id] || a.app_name || a.app_id || a.source || '') : [a.media_artist, a.media_title].filter(Boolean).join(' – ');
    const btn = (act, label, pressed) => `<button class="mini" data-media="${k}" data-act="${act}" ${pressed!=null?`aria-pressed="${pressed}"`:''}>${label}</button>`;
    let ctl = '';
    if(k==='tv'){
      ctl = btn('power', on ? 'Uitzetten' : 'Aanzetten') + (on ? btn('voldown','Vol −') + btn('volup','Vol +') + btn('mute', 'Stil', !!a.is_volume_muted) + btn('playpause','⏯') : '');
      if(on) ctl += `</div><div class="modes">` + TV_APPS.map(([n,id])=>`<button class="mini" data-media="tv" data-act="app" data-val="${id}" aria-pressed="${a.app_id===id}">${n}</button>`).join('');
      if(on && (m.remote || !LIVE)) ctl += `</div><div class="tvpad" role="group" aria-label="Afstandsbediening">` +
        [['','',''],['DPAD_UP','▲',''],['','',''],['DPAD_LEFT','◀',''],['DPAD_CENTER','OK',''],['DPAD_RIGHT','▶',''],['BACK','Terug',''],['DPAD_DOWN','▼',''],['HOME','Home','']]
          .map(([c,l])=> c ? `<button class="mini" data-media="tv" data-act="key" data-val="${c}">${l}</button>` : '<span></span>').join('');
      if(on && Array.isArray(a.source_list) && a.source_list.length) ctl += `<select class="mini" data-src="${k}" aria-label="Bron">${a.source_list.map(x=>`<option ${x===a.source?'selected':''}>${x}</option>`).join('')}</select>`;
    } else if(m.simple){
      ctl = btn('power', on ? 'Uitzetten' : 'Aanzetten') + (on ? btn('playpause', m.state==='playing' ? '⏸ Pauze' : '▶ Afspelen') : '');
    } else {
      ctl = btn('prev','⏮') + btn('playpause', m.state==='playing' ? '⏸ Pauze' : '▶ Afspelen') + btn('next','⏭');
    }
    return `<p class="eyebrow" style="margin:14px 0 4px">${m.name} · ${MEDIA_STATE_NL[m.state]||m.state||'–'}</p>
      ${what ? `<div class="sub">${what}</div>` : ''}
      <div class="modes">${ctl}</div>
      ${vol!=null && !m.simple && (on || k==='sonos') ? `<label class="sub" style="display:flex;align-items:center;gap:8px;margin-top:6px">Volume <input type="range" min="0" max="100" value="${vol}" data-vol="${k}" style="flex:1;accent-color:var(--lamp)"> ${vol}%</label>` : ''}
      ${LIVE && !m.ent ? '<div class="sub">Nog niet gevonden in Home Assistant.</div>' : ''}
      ${LIVE && m.ent ? `<div class="sub" style="font-family:var(--mono);font-size:11px;color:var(--faint)">${m.ent} · ${m.state||'–'}</div>` : ''}`;
  }).join('');
}
function mediaAction(k, act, val){
  const m = MEDIA[k]; const a = m.a = m.a||{};
  const svc = {power: mediaOn(m) ? 'turn_off' : 'turn_on', volup:'volume_up', voldown:'volume_down', mute:'volume_mute', playpause:'media_play_pause', next:'media_next_track', prev:'media_previous_track', source:'select_source', volume:'volume_set'}[act];
  const data = {};
  if(act==='mute') data.is_volume_muted = !a.is_volume_muted;
  if(act==='source') data.source = val;
  if(act==='volume') data.volume_level = val;
  // direct tonen, Home Assistant bevestigt daarna
  if(act==='power') m.state = mediaOn(m) ? (k==='tv'||m.simple?'off':'idle') : 'on';
  if(act==='playpause') m.state = m.state==='playing' ? 'paused' : 'playing';
  if(act==='mute') a.is_volume_muted = data.is_volume_muted;
  if(act==='source') a.source = val;
  if(act==='volume') a.volume_level = val;
  if(act==='app'){ a.app_id = val; a.app_name = APP_NL[val]; }
  if(act==='volup') a.volume_level = Math.min(1, (a.volume_level||0)+.02);
  if(act==='voldown') a.volume_level = Math.max(0, (a.volume_level||0)-.02);
  applyPlugs(); renderPanel();
  if(!LIVE || !ha) return;
  if(act==='key'){ if(m.remote) ha.call('remote','send_command',{entity_id:m.remote, command:val}).catch(()=>{}); return; }
  if(act==='app'){ if(m.ent) ha.call('media_player','play_media',{entity_id:m.ent, media_content_type:'app', media_content_id:val}).catch(()=>{}); return; }
  if(act==='power' && k==='tv' && m.remote && !m.ent){ ha.call('remote', svc, {entity_id:m.remote}).catch(()=>{}); return; }
  if(m.ent) ha.call('media_player', svc, {entity_id:m.ent, ...data}).catch(()=>{});
  if(act==='power' && k==='tv' && m.remote) ha.call('remote', svc, {entity_id:m.remote}).catch(()=>{});
}
