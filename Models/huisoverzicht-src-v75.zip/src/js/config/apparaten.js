// (v75) apparaten die met '◎ Apparaten' door muren/dak/grond heen zichtbaar worden: dev(object, naam, soort)
const DEVICES = [];
const dev = (obj, name, cat='energie')=>{ if(obj) DEVICES.push({obj, name, cat}); return obj; };
const HEK = {};   // (v75) hekfunctie van de tuin, zodat latere onderdelen hetzelfde hek kunnen zetten
const PLUG_DEMO = {Tv:[1,120],Aquarium:[1,45],Koelkast:[1,70],'Slimme stekker':[0,0],Oven:[0,0],Vaatwasser:[0,0],'Regenwaterpomp (regenput)':[1,0],'Koelkast kelder':[1,70],Wasmachine:[1,0],Droger:[0,0],Pc:[1,140],Vijverpomp:[1,38],'Vijverpomp 2':[0,0],Starlink:[1,52],Patchkast:[1,64],Pelletkachel:[1,45]};
// Pelletkachel RED Primula 9 kW (H 110 × B 60 × D 50 cm, ruit 40 × 30 cm halverwege) bij de middelste paal; brandt = stekker trekt > 10 W
const STOVE = {x:9.55, y:3.9, h:1.10, w:0.60, d:0.50, gw:0.30, gh:0.40};
// Media: Sony Bravia (tv) en IKEA Symfonisk / Sonos (keuken). ent = null → wordt in HA automatisch gezocht.
const MEDIA = {
  // Sony KD-65XD8599 via 'Android TV Remote' (media_player + remote), Symfonisk boekenplank via Sonos (heet 'Woonkamer' in HA)
  tv:    {ent:null, remote:null, room:'woon', name:'Sony Bravia 65" (KD-65XD8599)', match:/kd[_ -]?65|xd8599|bravia|sony/i,
          state:'on', a:{app_id:'com.netflix.ninja', app_name:'Netflix', volume_level:.22, is_volume_muted:false}},
  sonos: {ent:null, prefer:['media_player.woonkamer'], room:'hal', name:'Symfonisk boekenplank (Sonos)', match:/sonos|symfonisk|boekenplank|bookshelf/i,
          state:'playing', a:{media_artist:'Novastar', media_title:'Never Back Down', volume_level:.3}},
  // Eenvoudige spelers (aan/uit + afspelen/pauze). ent leeg = automatisch zoeken op naam; vul het entity_id in als het niet gevonden wordt.
  atvWoon:  {ent:null, prefer:['media_player.living'], room:'woon',  simple:true, name:'Apple TV (woonkamer)',  match:/apple.*(woon|living)|(woon|living).*apple|^media_player\.living(_\d+)?$/i,
             state:'off', a:{}},
  ps5:      {ent:null, room:'woon',  simple:true, name:'PlayStation 5 Slim',     match:/ps5|playstation/i, state:'off', a:{}},
  tvSlaap:  {ent:null, prefer:['media_player.tv_in_slaapkamer'], room:'slaap', simple:true, name:'Philips 55" tv',         match:/^(?!.*apple)(?=.*(philips|tv.*slaap|slaap.*tv))/i, state:'on', a:{}},
  atvSlaap: {ent:null, prefer:['media_player.slaapkamer'], room:'slaap', simple:true, name:'Apple TV (slaapkamer)', match:/apple.*slaap|slaap.*apple|^media_player\.slaapkamer(_\d+)?$/i, state:'playing', a:{app_name:'NLZIET'}},
};
// Bold smart lock op de voordeur (+ Bold Connect-bridge achter de tv). ent leeg = automatisch zoeken (lock.* met bold/voordeur, anders de enige lock).
const LOCK = {ent:null, match:/bold|voordeur|front/i, name:'Bold smart lock · voordeur', room:'hal', pos:[6.3,0], state:'locked'};
const TV_APPS = [['Netflix','com.netflix.ninja'],['YouTube','com.google.android.youtube.tv'],['Prime Video','com.amazon.amazonvideo.livingroom'],['Disney+','com.disney.disneyplus'],['VRT MAX','be.vrt.vrtnu']];
const APP_NL = {'com.google.android.leanbacklauncher':'Startscherm','com.google.android.tvlauncher':'Startscherm'};
TV_APPS.forEach(([n,id])=>APP_NL[id]=n);
const MEDIA_STATE_NL = {on:'Aan', off:'Uit', standby:'Stand-by', idle:'Stil', playing:'Speelt', paused:'Gepauzeerd', buffering:'Laden…', unavailable:'Niet bereikbaar'};
// Weheat Flint (LP9): buitenunit rechts van de voordeur; stuurunit + 200 L-boiler in de badkamer boven.
// (Flint P40 in HA is van de buren → bewust NIET in het overzicht.)
const HP = {
  lp9:{name:'Weheat Flint · boiler 200 L', pos:[4.6,-0.62], face:'y-', status:'sensor.sn_0y95_422y', pin:'sensor.flint_lp9_vermogen_in', pout:'sensor.flint_lp9_vermogen_uit',
       cop:'sensor.flint_lp9_cop', tin:'sensor.sn_0y95_422y_watertemperatuur_in', tout:'sensor.sn_0y95_422y_watertemperatuur_uit',
       comp:'sensor.sn_0y95_422y_compressorgebruik', sww:'sensor.sn_0y95_422y_sww_temperatuur_boventemperatuur', swwLow:'sensor.sn_0y95_422y_sww_temperatuur_onder', indoor:true,
       v:{status:'standby', pin:12, pout:0, cop:null, tin:29.0, tout:29.3, comp:0, sww:51.4, swwLow:44.8}},
};
const HP_MODE = st => { const x = String(st||'').toLowerCase();
  if(/defrost|ontdooi/.test(x)) return ['defrost','Ontdooien',0xdfe8ff];
  if(/dhw|sww|tap|warm water|boiler/.test(x)) return ['dhw','Warm water',0xc47bff];
  if(/cool|koel/.test(x)) return ['cool','Koelen',0x3fa7ff];
  if(/heat|verwarm/.test(x)) return ['heat','Verwarmen',0xff8a3d];
  if(/standby|idle|off|uit|stand-by|rust/.test(x) || !x) return ['idle','Stand-by',0x000000];
  return ['run', st, 0xffc46b]; };
// Meldingen: waterlek, batterijen van sensoren
const LEAK = {ent:'binary_sensor.sensor_1_water_lekkage', name:'Meterput', on:false};
const BATTS = {'Motion toilet':64, 'Motion hal':81, 'Motion woonkamer':55, 'Dimmer Amélie':9, 'Meterput watersensor':72};
// Lampverbruik via Modbus (totaal kWh)
const LAMP_KWH = {keuken:'sensor.energie_keuken', bad:'sensor.energie_badkamer', slaap:'sensor.energie_slaapkamer_dressing'};
const starlink = {ok:true, ping:34, down:180, up:14};
const outside = {temp:13.8, hum:81};
rooms.forEach(r=>{
  if(CLIMATE[r.id]){ r.ac = {...CLIMATE[r.id], kwh:null, kwhEnt:CLIMATE[r.id].kwh}; r.climState = r.id==='woon' ? 'cool' : 'off'; r.acModes = ['off','cool','heat','dry','fan_only','auto']; r.ac.kwh = +(Math.random()*2).toFixed(2); }
  r.plugs = (PLUGS[r.id]||[]).map(([name,sw,pw,pos])=>{ const d = PLUG_DEMO[name]||[0,0]; return {name, sw, pw, pos, on: !!d[0], w: d[0] ? d[1] : 0, base: d[1], pool: (sw && VEILIGHEIDSPOOL[sw]) || null}; });
  r.lampKwhEnt = LAMP_KWH[r.id] || null; r.lampKwh = r.lampKwhEnt ? +(40+Math.random()*80).toFixed(1) : null;
  const [a,b,c,d] = r.rects[0];
  r.cx = mx((a+c)/2); r.cz = mz((b+d)/2);
  r.area = r.rects.reduce((s,[a,b,c,d])=>s+(c-a)*(d-b),0);
  r.hasT = !!(r.t || r.clim); r.hasH = !!r.h;
  if(!r.hasT) r.temp = null;
  if(!r.hasH) r.hum = null;
  r.hist = r.hasT ? Array.from({length:24},(_,i)=>+(r.temp-0.9+Math.sin((i-6)/24*Math.PI*2)*0.8+(Math.random()-.5)*0.3).toFixed(2)) : null;
  if(r.hist) r.hist[23]=r.temp;
  if(r.target==null) r.target = r.temp ?? 18;
});
const byId = Object.fromEntries(rooms.map(r=>[r.id,r]));
let selected = byId.woon, mode = 0, night = true, colorMode = 'temp', wire = false;

const fmt = (v,d=1)=> (v==null || !isFinite(v)) ? '–' : v.toFixed(d).replace('.',',');
const fmtW = w => w==null||!isFinite(w) ? '–' : Math.abs(w)>=1000 ? fmt(w/1000,1)+' kW' : Math.round(w)+' W';
const roomW = r => r.plugs && r.plugs.length ? r.plugs.reduce((s,p)=>s+(p.w||0),0) : null;
const rnd = v => (v==null || !isFinite(v)) ? '–' : Math.round(v);
const LIVE = location.pathname.includes('/local/') || /[?&]live\b/.test(location.search);
const STATUS_NL = {nc:'niet aangesloten', broken:'defect', unavail:'niet bereikbaar', nolink:'niet gekoppeld'};

