/* ---------- Verdieping: vloer, knieschotten, puntgevels, binnenmuren ---------- */
const floorBand = new THREE.MeshStandardMaterial({color:0x4a4640, roughness:1});
{
  const cx = mx(PITCH_W/2);
  const plate = new THREE.Mesh(new THREE.BoxGeometry(PITCH_W-0.1, 0.1, D_M-0.1), floorBand);   // (v28) binnen de gevels
  plate.position.set(cx,-0.22,0); upper.add(plate);
  // baksteenband tussen plafond begane grond (2,8) en vloer verdieping
  const bh = F1-H_REST;
  upper.add(box(PITCH_W+0.3, bh, 0.3, brickMat, cx, -bh, mz(0)));
  upper.add(box(PITCH_W+0.3, bh, 0.3, brickMat, cx, -bh, mz(D_M)));
  upper.add(box(0.3, bh, D_M+0.3, brickMat, mx(0), -bh, 0));
  upper.add(box(0.3, bh, D_M+0.3, brickMat, mx(PITCH_W), -bh, 0));
  // knieschotten voor- en achtergevel
  [0, D_M].forEach(y=>{
    const m = Array(6).fill(wallMat); m[y===0?5:4] = brickMat; m[0] = m[1] = brickMat;   // (v60) kopse kanten knieschot in ceder (waren grijze stroken)
    upWalls.add(box(PITCH_W+0.3, KNEE, 0.3, m, cx, 0, mz(y)));
  });
  // puntgevels (asymmetrisch): binnenkant stuc, buitenkant baksteen
  const prof = [[0,0],[0,KNEE],[RIDGE_Y,RIDGE_H],[D_M,KNEE],[D_M,0]];
  const shape = new THREE.Shape(prof.map(([y,h])=>new THREE.Vector2(y-D_M/2,h)));
  const gGeo = new THREE.ExtrudeGeometry(shape,{depth:0.28, bevelEnabled:false});
  gGeo.rotateY(-Math.PI/2);   // shape-x → Z, extrusie → -X
  [[0,-1],[PITCH_W,1]].forEach(([x,side])=>{
    const g = new THREE.Mesh(gGeo, [wallMat, brickMat]); g.castShadow = true; g.receiveShadow = true;   // (v60) randen puntgevel in ceder
    g.position.set(mx(x)+0.14, 0, 0); upWalls.add(g);
    const skin = new THREE.Mesh(new THREE.ShapeGeometry(shape), brickMat);
    skin.rotation.y = -Math.PI/2; skin.position.set(mx(x)+side*0.151, 0, 0);
    skin.material = brickMat.clone(); skin.material.side = THREE.DoubleSide; WIRE_MATS.add(skin.material);
    upWalls.add(skin);
  });
  // lateien boven deuren (2,05 m tot plafond)
  UP_HEADERS.forEach(([x1,y1,x2,y2])=>{ const h0 = 2.05, top = Math.min(CEIL_UP, roofH((y1+y2)/2))-0.02;
    upWalls.add(y1===y2 ? box(Math.abs(x2-x1), top-h0, 0.1, wallMat, mx((x1+x2)/2), h0, mz(y1)) : box(0.1, top-h0, Math.abs(y2-y1), wallMat, mx(x1), h0, mz((y1+y2)/2))); });
  // binnenmuren: hoogte volgt het dak (max. plafond 2,6)
  UP_WALLS.forEach(([x1,y1,x2,y2])=>{
    if(y1===y2){
      const h = Math.min(CEIL_UP, roofH(y1))-0.02;
      upWalls.add(box(Math.abs(x2-x1)+0.1, h, 0.1, wallMat, mx((x1+x2)/2), 0, mz(y1)));
    } else {
      // profiel van de muur volgt het dak: polygoon (y, hoogte), 0,1 m dik
      const ya=Math.min(y1,y2), yb=Math.max(y1,y2), pts=[new THREE.Vector2(ya-D_M/2,0)];
      for(let y=ya; y<=yb+1e-6; y+=0.05) pts.push(new THREE.Vector2(Math.min(y,yb)-D_M/2, Math.min(CEIL_UP, roofH(Math.min(y,yb)))-0.02));
      const last=pts[pts.length-1]; if(Math.abs(last.x-(yb-D_M/2))>1e-4) pts.push(new THREE.Vector2(yb-D_M/2, Math.min(CEIL_UP, roofH(yb))-0.02));
      pts.push(new THREE.Vector2(yb-D_M/2,0));
      const g = new THREE.ExtrudeGeometry(new THREE.Shape(pts),{depth:0.1, bevelEnabled:false});
      g.rotateY(-Math.PI/2);
      const m = new THREE.Mesh(g, wallMat); m.castShadow = true; m.receiveShadow = true;
      m.position.set(mx(x1)+0.05, 0, 0); upWalls.add(m);
    }
  });
}

// Starlink-router (Gen 3, staand) in de hoek van kamer Lucas
{
  const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(.09,.26,.16), new THREE.MeshStandardMaterial({color:0xf1f1ef, roughness:.4}));
  body.position.y = .13; body.castShadow = true;
  starLed = new THREE.Mesh(new THREE.SphereGeometry(.012,8,8), new THREE.MeshStandardMaterial({color:0x111, emissive:0x46d17a, emissiveIntensity:1.5}));
  starLed.position.set(.046,.22,0);
  g.add(body, starLed); g.position.set(mx(STARLINK[0]),0,mz(STARLINK[1])); g.rotation.y = Math.PI*0.75; upper.add(g); dev(g, 'Starlink-router', 'netwerk');
}
