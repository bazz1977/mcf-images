let terraceRoof, battBar, goodweLed, starLed, tvScreen, sonosLed, sonosWaves = [], apLed;
const cellar = new THREE.Group(); cellar.position.y = Y_K; scene.add(cellar);
const cellarWalls = new THREE.Group(); cellar.add(cellarWalls);
let cellarScale = 1;
const concrete = new THREE.MeshStandardMaterial({color:0x8e8b86, roughness:1});
const cellarIn = new THREE.MeshStandardMaterial({color:0xcfccc6, roughness:.95});
{
  const kh = -Y_K - 0.25;                     // tot onderkant vloer begane grond
  K_OUTER.forEach((p,i)=>{
    const q = K_OUTER[(i+1)%K_OUTER.length];
    if(q[0]===0 && q[1]===D_M) return;         // achtergevel kelder: apart, met ramen en insprong
    const horiz = p[1]===q[1], len = Math.hypot(q[0]-p[0], q[1]-p[1]) + 0.3;
    walls_k(horiz?[len,kh,0.3]:[0.3,kh,len], concrete, (p[0]+q[0])/2, (p[1]+q[1])/2);
  });
  // (v28) achtergevel kelder: ±1 m boven het maaiveld, twee ramen 2,75 × 0,8 m (Amélie en Lucas 2), bovenkant net onder het plafond
  {
    // achterhuis: gevellijn y = 6,7 tot x 6,62; onder de woonkamer: 30 cm naar binnen (y = 6,4) met een terugkeer op x 6,47
    const yAt = x => x < 6.47 ? D_M : D_M-K_REC;
    const piece = (a,b,y0,y1)=>{ if(b-a<=0.001 || y1-y0<=0.001) return;
      const segs = (a<6.47+0.15 && b>6.47+0.15) ? [[a,6.62],[6.62,b]] : [[a,b]];
      segs.forEach(([c,d])=>{ const yl = (c+d)/2 < 6.62 ? D_M : D_M-K_REC; const c2 = yl<D_M && c<6.63 ? 6.32 : c;
        cellarWalls.add(box(d-c2, y1-y0, 0.3, concrete, mx((c2+d)/2), y0, mz(yl))); }); };
    cellarWalls.add(box(0.3, kh, K_REC+0.3, concrete, mx(6.47), 0, mz(D_M-K_REC/2)));      // terugkeer bij de insprong
    let cur = -0.15; const end = K_X1+0.15;
    K_WIN.forEach(([a,b,room])=>{
      piece(cur, a, 0, kh); piece(a, b, 0, KW_B); piece(a, b, KW_T, kh); cur = b;
      const w = b-a, h = KW_T-KW_B, mid = mx((a+b)/2), z = mz(yAt((a+b)/2));
      const gm = new THREE.MeshStandardMaterial({color:0x8fb4cc, transparent:true, opacity:.26, roughness:.05, metalness:.1});
      byId[room].glass.push(gm);
      const pane = box(w-0.1, h-0.1, 0.03, gm, mid, KW_B+0.05, z); pane.castShadow = false; cellarWalls.add(pane);
      [a+0.03, b-0.03].forEach(x=>cellarWalls.add(box(0.06, h, 0.12, frameMat, mx(x), KW_B, z)));
      [KW_B, KW_T-0.06].forEach(y=>cellarWalls.add(box(w, 0.06, 0.12, frameMat, mid, y, z)));
    });
    piece(cur, end, 0, kh);
  }
  K_WALLS.forEach(([x1,y1,x2,y2])=>{
    const horiz = y1===y2, len = Math.hypot(x2-x1,y2-y1)+0.1;
    walls_k(horiz?[len,K_H,0.1]:[0.1,K_H,len], cellarIn, (x1+x2)/2, (y1+y2)/2);
  });
  K_DOORS.forEach(([x1,y1,x2,y2])=>{
    const horiz = y1===y2, len = Math.hypot(x2-x1,y2-y1), cx = (x1+x2)/2, cy = (y1+y2)/2, DH = 2.1;
    const lintel = box(horiz?len:0.1, K_H-DH, horiz?0.1:len, cellarIn, mx(cx), DH, mz(cy)); cellarWalls.add(lintel);
    const frameM = doorFrameM;
    [-1,1].forEach(sg=>{ const off = sg*(len/2-0.03); cellarWalls.add(box(horiz?0.06:0.12, DH, horiz?0.12:0.06, frameM, mx(cx+(horiz?off:0)), 0, mz(cy+(horiz?0:off)))); });
    cellarWalls.add(box(horiz?len:0.12, 0.05, horiz?0.12:len, frameM, mx(cx), DH-0.05, mz(cy)));
  });
  // dak kelderuitbouw = terrasvloer
  terraceRoof = box(K_X1-6.47+0.3, 0.2, TERR_D+0.15, concrete, mx((6.47+K_X1)/2), kh-0.2, mz(-TERR_D/2)); cellar.add(terraceRoof);
  // de spiltrap loopt door naar de kelder
  const stairMat2 = new THREE.MeshStandardMaterial({color:0x6b6660, roughness:.9});
  const NK = 14, ANG = (330/NK)*Math.PI/180;
  for(let i=0;i<NK;i++){
    const geo = new THREE.CylinderGeometry(0.98,0.98,0.05,8,1,false, i*ANG, ANG*1.05); geo.translate(0,0.025,0);
    const st = new THREE.Mesh(geo, stairMat2); st.position.set(mx(STAIR.x), (i+1)*(-Y_K/NK)-0.05, mz(STAIR.y));
    st.castShadow = true; cellarWalls.add(st);
  }
  cellarWalls.add(box(0.1, -Y_K, 0.1, frameMat, mx(STAIR.x), 0, mz(STAIR.y)));

  // technische ruimte: BYD-batterij, GoodWe-omvormer, meterkast, patchkast
  const white = new THREE.MeshStandardMaterial({color:0xe9e9e6, roughness:.5});
  const dark  = new THREE.MeshStandardMaterial({color:0x2b2f33, roughness:.5, metalness:.3});
  const byd = box(0.298, 1.178, 0.585, dark, mx(0.30), 0, mz(0.74)); cellarWalls.add(byd); dev(byd, 'BYD thuisbatterij');      // (v61) BYD B-Box Premium HVS 5.1: B 58,5 × D 29,8 × H 117,8 cm, tegen de rechterzijgevel
  battBar = box(0.02, 1.08, 0.06, new THREE.MeshStandardMaterial({color:0x111, emissive:0x46d17a, emissiveIntensity:1.2}), mx(0.455), 0.05, mz(0.74));
  cellarWalls.add(battBar);
  cellarWalls.add(dev(box(0.2, 0.55, 0.46, white, mx(0.25), 1.35, mz(0.74)), 'GoodWe omvormer'));   // (v62) boven de batterij                       // (v60) GoodWe omvormer tegen de rechterzijgevel
  goodweLed = new THREE.Mesh(new THREE.BoxGeometry(0.12,0.05,0.01), new THREE.MeshStandardMaterial({color:0x111, emissive:0x3fa7ff, emissiveIntensity:0}));
  goodweLed.geometry.translate(0,0.025,0); goodweLed.rotation.y = Math.PI/2; goodweLed.position.set(mx(0.36), 1.75, mz(0.74)); cellarWalls.add(goodweLed);
  cellarWalls.add(dev(box(0.4, 0.7, 0.18, white, mx(0.6), 1.0, mz(0.24)), 'Meterkast'));                         // (v60) meterkast, los van de patchkast
  cellarWalls.add(dev(box(0.55, 1.9, 0.5, dark, mx(1.38), 0, mz(0.4)), 'Patchkast', 'netwerk'));                             // patchkast: Omada TL-R605, OC200, TL-SG2428P, Hue Bridge, Home Assistant
  // (v43) TL-SG2428P in de patchkast: 24 poortlampjes, amber = PoE actief, groen = link
  cellarWalls.add(box(0.46, 0.045, 0.02, new THREE.MeshStandardMaterial({color:0x3a3f45, roughness:.5}), mx(1.38), 1.2, mz(0.655)));
  OMADA.portLeds = Array.from({length:24}, (_,i)=>{ const m = new THREE.MeshStandardMaterial({color:0x111, emissive:0x46d17a, emissiveIntensity:0});
    const led = new THREE.Mesh(new THREE.BoxGeometry(.012,.008,.004), m); led.position.set(mx(1.18 + (i%12)*0.036), 1.212 + (i<12 ? 0.016 : 0), mz(0.667)); cellarWalls.add(led); return m; });
  [[1.2,1.5,0x46d17a],[1.35,1.5,0x3fa7ff],[1.5,1.5,0xffc46b]].forEach(([x,h,c])=>{
    const led = new THREE.Mesh(new THREE.SphereGeometry(.018,8,8), new THREE.MeshStandardMaterial({color:0x111, emissive:c, emissiveIntensity:1.5}));
    led.position.set(mx(x), h, mz(0.66)); cellarWalls.add(led); });
}
function walls_k(d, mat, x, y){ cellarWalls.add(box(...d, mat, mx(x), 0, mz(y))); }
