// (v43) extra EAP245's en de EAP211-Bridge point-to-point
{
  const white = new THREE.MeshStandardMaterial({color:0xf4f4f2, roughness:.3});
  OMADA.devices.filter(d=>d.pos && !d.existing).forEach(d=>{
    const [px,py,h,fl,face] = d.pos, g = new THREE.Group();
    d.led = new THREE.MeshStandardMaterial({color:0x222, emissive:0x46d17a, emissiveIntensity:1.4});
    if(d.kind==='ap'){
      const disc = new THREE.Mesh(new THREE.CylinderGeometry(.11,.105,.04,40), white); disc.rotation.z = Math.PI/2; disc.position.x = .02;
      const ring = new THREE.Mesh(new THREE.TorusGeometry(.024,.004,8,24), d.led); ring.rotation.y = Math.PI/2; ring.position.x = .042; g.add(disc, ring);
    } else {
      const body = new THREE.Mesh(new THREE.BoxGeometry(.06,.26,.12), white); body.position.x = .06; body.castShadow = true;
      const arm = new THREE.Mesh(new THREE.CylinderGeometry(.015,.015,.12,8), new THREE.MeshStandardMaterial({color:0x888})); arm.rotation.z = Math.PI/2; arm.position.x = .0;
      const led = new THREE.Mesh(new THREE.SphereGeometry(.01,8,8), d.led); led.position.set(.092,.1,0); g.add(body, arm, led);
    }
    g.rotation.y = {'x+':0, 'x-':Math.PI, 'y+':-Math.PI/2, 'y-':Math.PI/2}[face];
    const hit = new THREE.Mesh(new THREE.SphereGeometry(.3,8,8), new THREE.MeshBasicMaterial({visible:false})); hit.userData.room = byId[d.room] || byId.buiten;
    if(fl==='out'){
      if(d.name.endsWith('Slave')){ const base = gradeAt(mx(px), mz(py)); const pole = box(0.08, h, 0.08, new THREE.MeshStandardMaterial({color:0x6f757b, metalness:.5, roughness:.4}), mx(px), base, mz(py)); scene.add(pole); garden.push(pole);
        g.position.set(mx(px), base+h, mz(py)); hit.position.copy(g.position); g.userData.noMerge = true; scene.add(g, hit); garden.push(g); }
      else { g.position.set(mx(px), h, mz(py)); hit.position.copy(g.position); upper.parent.add(g, hit); }
      d.obj = g; dev(g, d.name, 'netwerk');
    } else { const grp = fl===-1 ? cellarWalls : walls; g.position.set(mx(px), 0, mz(py)); hit.position.set(mx(px), 0, mz(py)); wallMount(g, h, grp); dev(g, d.name, 'netwerk'); wallMount(hit, h, grp); }
    pickables.push(hit);
  });
  // straalverbinding tussen master en slave (stippellijn, knippert bij verkeer)
  const m = OMADA.devices.find(d=>d.name==='Point2Point_Master'), sl = OMADA.devices.find(d=>d.name==='Point2Point_Slave');
  if(m && sl && m.obj && sl.obj){ const geo = new THREE.BufferGeometry().setFromPoints([m.obj.position.clone(), sl.obj.position.clone()]);
    OMADA.linkMat = new THREE.LineDashedMaterial({color:0x7fd0ff, dashSize:.35, gapSize:.25, transparent:true, opacity:.7});
    OMADA.link = new THREE.Line(geo, OMADA.linkMat); OMADA.link.computeLineDistances(); scene.add(OMADA.link); garden.push(OMADA.link); }
}
