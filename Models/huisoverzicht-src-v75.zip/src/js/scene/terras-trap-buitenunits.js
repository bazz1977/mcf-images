// (v31) achterzijde terras rechtergevel: trapje (1 m breed) naar de achtertuin met stenen muurtje, LG-buitenunits op de keerwand, klimop op de perceelgrens
{
  const stepMat = new THREE.MeshStandardMaterial({color:0x9a958d, roughness:.9}), wallStone = new THREE.MeshStandardMaterial({color:0x7d776f, roughness:.95});
  // (v36) trapje achter het terras: 4 treden omlaag evenwijdig aan de rechtergevel, bordes 1 × 1 m, 1 trede haaks langs de keerwand naar de lage tuin
  const TOP = -0.14, LOW = -0.2 - GRADE_DROP, rise = (TOP-LOW)/7, run = (STAIR_YL-STAIR_Y0)/4;
  const step = (x0,x1,y0,y1,top)=> sideTerrace.add(box(x1-x0, top-LOW+0.05, y1-y0, stepMat, mx((x0+x1)/2), LOW-0.05, mz((y0+y1)/2)));
  for(let i=0;i<4;i++) step(STAIR_X0, TR_X0, STAIR_Y0+i*run, STAIR_Y0+(i+1)*run, TOP-rise*(i+1));
  step(STAIR_X0, TR_X0, STAIR_YL, STAIR_YL+1.0, TOP-rise*5);                     // bordes
  step(TR_X0, TR_X0+0.3, STAIR_YL, STAIR_YL+1.0, TOP-rise*6);                   // 1 trede haaks, langs de keerwand
  // muurtje rondom, zo hoog als het terras: buitenkant (kant klimop) en achter het bordes
  sideTerrace.add(box(0.15, TOP-LOW+0.03, STAIR_YL+1.15-STAIR_Y0, wallStone, mx(STAIR_X0-0.075), LOW-0.05, mz((STAIR_Y0+STAIR_YL+1.15)/2)));
  sideTerrace.add(box(TR_X0-STAIR_X0+0.15, TOP-LOW+0.03, 0.15, wallStone, mx((STAIR_X0-0.15+TR_X0)/2), LOW-0.05, mz(STAIR_YL+1.075)));
  // LG-buitenunits: [ruimte, x, midden-hoogte, breedte, hoogte, (optioneel) y op de linker keldermuur]
  //  keerwand terras achterzijde: slaapkamer B&D, Jolie, Amélie · linker keldermuur onder de woonkamer: woonkamer 5,0 kW, Lucas 2 3,5 kW
  const AC_OUT = [['slaap',-1.67,-0.46,0.80,0.55],['jolie',-0.75,-0.43,0.72,0.48],['amelie',-0.75,-0.97,0.72,0.48],
                  ['woon',null,-0.74,0.87,0.65,5.85],['lucas2',null,-0.68,0.77,0.55,4.6]];
  const acOutMat = new THREE.MeshStandardMaterial({color:0xe9e9e4, roughness:.45}), grilleMat = new THREE.MeshStandardMaterial({color:0x2a2d31, roughness:.8}), bladeMat = new THREE.MeshStandardMaterial({color:0x6f757b, roughness:.5});
  AC_OUT.forEach(([id,x,yc,w,h,ly])=>{
    const r = byId[id]; if(!r || !r.ac) return;
    const d = 0.27, g = new THREE.Group(), R = h*0.38, fx = -w*0.15;
    const cab = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), acOutMat); cab.castShadow = true; cab.receiveShadow = true;
    const grille = new THREE.Mesh(new THREE.CircleGeometry(R,32), grilleMat); grille.position.set(fx, 0, d/2+0.002);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(R,0.012,8,40), acOutMat); ring.position.set(fx, 0, d/2+0.01);
    const fan = new THREE.Group(); fan.position.set(fx, 0, d/2+0.006);
    for(let k=0;k<3;k++){ const bl = new THREE.Mesh(new THREE.BoxGeometry(0.07, R*0.9, 0.006), bladeMat); bl.position.y = R*0.45; bl.rotation.y = 0.35; const arm = new THREE.Group(); arm.rotation.z = k*Math.PI*2/3; arm.add(bl); fan.add(arm); }
    for(let k=0;k<5;k++){ const v = new THREE.Mesh(new THREE.BoxGeometry(w*0.22, 0.012, 0.01), grilleMat); v.position.set(w*0.3, h*0.3 - k*h*0.14, d/2+0.003); g.add(v); }
    [-1,1].forEach(sg=>{ const br = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.04, 0.08), frameMat); br.position.set(sg*w*0.38, -h/2+0.03, -d/2-0.03); g.add(br); });
    g.add(cab, grille, ring, fan);
    if(ly==null) g.position.set(mx(x), yc, mz(D_M+0.15) + d/2 + 0.07);
    else { g.rotation.y = Math.PI/2; g.position.set(mx(K_X1+0.15) + d/2 + 0.07, yc, mz(ly)); }   // tegen de linker keldermuur, fan naar buiten
    sideTerrace.add(g); dev(g, 'Airco buitenunit '+r.name);
    r.ac.outFan = fan;
    const hit = new THREE.Mesh(new THREE.BoxGeometry(w+0.1,h+0.1,d+0.1), new THREE.MeshBasicMaterial({visible:false})); hit.userData.room = r; g.add(hit); pickables.push(hit);
  });
  // perceelgrens rechts: klimop 2 m hoog, volgt het maaiveld
  const hedge = new THREE.Group(), ivy = [0x2c4a26, 0x33562c, 0x274221, 0x3a5f30].map(c=>new THREE.MeshStandardMaterial({color:c, roughness:1, flatShading:true}));
  let seed = 5; const rn = ()=>{ seed = (seed*16807) % 2147483647; return seed/2147483647; };
  for(let y=PLOT.y0; y<PLOT.y1; y+=0.5){
    const gi = gradeAt(mx(HEDGE_X+0.3), mz(y+0.25)), go = gradeAt(mx(HEDGE_X-0.3), mz(y+0.25)), base = Math.min(gi, go), hh = (-0.2 + 2.0) - base;   // (v36) bovenkant in één rechte lijn (2 m boven nulpas)
    const seg = new THREE.Mesh(new THREE.BoxGeometry(0.32, hh, 0.52), ivy[Math.floor(rn()*4)]); seg.geometry.translate(0,hh/2,0);
    seg.position.set(mx(HEDGE_X), base-0.05, mz(y+0.25)); seg.castShadow = seg.receiveShadow = true; hedge.add(seg);
    for(let k=0;k<3;k++){ const b = new THREE.Mesh(new THREE.IcosahedronGeometry(0.14+rn()*0.12,0), ivy[Math.floor(rn()*4)]);
      b.position.set(mx(HEDGE_X)+(rn()<.5?-1:1)*0.16, gi+0.2+rn()*1.7, mz(y+rn()*0.5)); b.castShadow = true; hedge.add(b); }
  }
  scene.add(hedge); garden.push(hedge);
  // (v34) onverharde wegen: hoofdweg langs de voorzijde, weg van de buren langs de rechtergrens (volgen het maaiveld)
  const roadMat = new THREE.MeshStandardMaterial({color:0xa89478, roughness:1});
  const road = (x0,x1,y0,y1)=>{ const w = x1-x0, d = y1-y0, g = new THREE.PlaneGeometry(w, d, Math.ceil(w/0.5), Math.ceil(d/0.5)); g.rotateX(-Math.PI/2);
    g.translate(mx((x0+x1)/2), 0, mz((y0+y1)/2)); const P = g.attributes.position; for(let i=0;i<P.count;i++) P.setY(i, gradeAt(P.getX(i), P.getZ(i))+0.03); g.computeVertexNormals();
    const m = new THREE.Mesh(g, roadMat); m.receiveShadow = true; scene.add(m); garden.push(m); };
  road(PLOT.x0-ROAD_W-2, PLOT.x1+8, PLOT.y0-ROAD_W-0.3, PLOT.y0-0.3);               // hoofdweg, 9 m voor de voorgevel
  road(PLOT.x0-ROAD_W, PLOT.x0-0.25, PLOT.y0-0.3, PLOT.y1+6);                        // weg van de buren, 5,5 m naast het huis
  // hekken: voorzijde 2,0 m, links en achter 1,5 m (antraciet paneelhek met palen om de 2,5 m), poortje bij het pad
  const postMat = new THREE.MeshStandardMaterial({color:0x2b2f33, roughness:.5, metalness:.4});
  const meshMat = new THREE.MeshStandardMaterial({color:0x2b2f33, roughness:.6, metalness:.3, transparent:true, opacity:.35, depthWrite:false, side:THREE.DoubleSide});
  const fence = HEK.fence = (ax,ay,bx,by,H,gaps=[])=>{ const horiz = ay===by, len = horiz ? bx-ax : by-ay, n = Math.ceil(len/2.5), st = len/n;
    for(let i=0;i<n;i++){ const a = (horiz?ax:ay) + i*st, b = a+st, m = (a+b)/2;
      const px = horiz ? m : ax, py = horiz ? ay : m, base = gradeAt(mx(px), mz(py));
      if(!gaps.some(([g0,g1])=> m>g0 && m<g1)){
        const pn = new THREE.Mesh(new THREE.BoxGeometry(horiz?st-0.06:0.02, H-0.08, horiz?0.02:st-0.06), meshMat); pn.position.set(mx(px), base+0.04+(H-0.08)/2, mz(py)); scene.add(pn); garden.push(pn);
        const rail = box(horiz?st:0.05, 0.05, horiz?0.05:st, postMat, mx(px), base+H-0.05, mz(py)); scene.add(rail); garden.push(rail); }
      const qx = horiz ? a : ax, qy = horiz ? ay : a, pb = gradeAt(mx(qx), mz(qy));
      const post = box(0.07, H+0.02, 0.07, postMat, mx(qx), pb-0.1, mz(qy)); post.castShadow = true; scene.add(post); garden.push(post); }
    const qx = horiz ? bx : ax, qy = horiz ? ay : by; const post = box(0.07, H+0.02, 0.07, postMat, mx(qx), gradeAt(mx(qx), mz(qy))-0.1, mz(qy)); scene.add(post); garden.push(post); };
  fence(TUINPAD.x1, PLOT.y0, PLOT.x1, PLOT.y0, 2.0);   // (v74) straatzijde 2,0 m: loopt door tot de linkerkant van het tuinpad; rechts van het pad geen hek
  fence(PLOT.x1, PLOT.y0, PLOT.x1, PLOT.y1, 1.5);                  // links
  fence(PLOT.x0, PLOT.y1, PLOT.x1, PLOT.y1, 1.5);                  // achter
  fence(TERRAS_HEK_X, PLOT.y0, TERRAS_HEK_X, TUINPAD.y1, 2.0);     // hek 2,0 m langs het klinkerterras (kant tuinpad)
}
