/* ---------- zijbalk in-/uitklappen en kaarten minimaliseren ---------- */
const store = { get(k,d){ try{ const v = localStorage.getItem(k); return v==null ? d : JSON.parse(v); }catch(_){ return d; } }, set(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){} } };
function setSide(open){
  document.querySelector('.app').classList.toggle('side-closed', !open);
  $('sidetab').textContent = open ? '›' : '‹'; $('sidetab').title = open ? 'Zijbalk inklappen' : 'Zijbalk uitklappen';
  $('sidetab').setAttribute('aria-expanded', String(open)); store.set('huis-zijbalk', open);
}
$('sidetab').onclick = ()=> setSide(document.querySelector('.app').classList.contains('side-closed'));
setSide(store.get('huis-zijbalk', true));
const minCards = new Set(store.get('huis-kaarten-min', []));
function markCards(){ document.querySelectorAll('#panel > .card').forEach(c=>{
  c.classList.toggle('min', minCards.has(c.id));
  const h = c.firstElementChild; if(h && h.classList.contains('eyebrow')){ h.setAttribute('role','button'); h.tabIndex = 0; h.setAttribute('aria-expanded', String(!minCards.has(c.id))); } }); }
function toggleCard(h){ const c = h.parentElement; if(!c.id) return; minCards.has(c.id) ? minCards.delete(c.id) : minCards.add(c.id); store.set('huis-kaarten-min', [...minCards]); markCards(); }
$('panel').addEventListener('click', e=>{ const h = e.target.closest('.card > .eyebrow:first-child'); if(h && !e.target.closest('button,select,input,a')) toggleCard(h); });
$('panel').addEventListener('keydown', e=>{ const h = e.target.closest('.card > .eyebrow:first-child'); if(h && (e.key==='Enter' || e.key===' ')){ e.preventDefault(); toggleCard(h); } });
new MutationObserver(markCards).observe($('panel'), {childList:true, subtree:true});
markCards();

