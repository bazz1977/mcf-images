// ===== (v63) STROMEN: stroom · netwerk · water, per onderdeel aan/uit (meerdere tegelijk) =====
const FLOW_MENU = [
  ['stroom','Stroom', [['zon','Zonnepanelen → omvormer',['pv1','pv2'],['pv']], ['batt','Thuisbatterij',['batt'],['batt']], ['huis','Huisverbruik',['house'],['house']], ['wp','Warmtepomp',['hp'],['hp']], ['net','Net (straat)',['grid'],['grid']]]],
  ['netwerk','Netwerk', [['inet','Internet: Starlink → router → switch',['wan','utp','sw'],['wan','sw']], ['ap','Accesspoints (UTP)',['apHal','apTrap','apTech','apKel'],['apHal','apTrap','apTech','apKel']], ['straal','Straalverbinding buren',['p2p','air'],['air']], ['vast','Vaste UTP (woonkamer, Lucas)',['woon','lucas'],['woon','lucas']]]],
  ['water','Water', [['buiten','Warmtepomp buiten ↔ binnen'], ['boiler','Warmtepomp → boiler'], ['kraan','Warm water naar de kranen'], ['vloer','Vloerverwarming'], ['regen','Regenwater: put → pomp → wc begane grond'], ['lucht','Beluchting minizuivering (nog niet aangesloten)']]],
];
const FLOWSEL_KEY = 'huis-stromen-v1';
const flowSel = {stroom:{}, netwerk:{}, water:{buiten:true, boiler:true, kraan:true, vloer:true, regen:true, lucht:true}, labels:true};
try{ const sv = JSON.parse(localStorage.getItem(FLOWSEL_KEY)||'null'); if(sv){ ['stroom','netwerk','water'].forEach(g=>Object.assign(flowSel[g], sv[g]||{})); if(sv.labels===false) flowSel.labels = false; } }catch(_){}
const W = flowSel.water;
function applyFlowSel(){
  const [, , st] = FLOW_MENU[0], [, , nt] = FLOW_MENU[1];
  st.forEach(([k,,fl])=>fl.forEach(f=>{ if(FLOWS[f]) FLOWS[f].sel = !!flowSel.stroom[k]; }));
  nt.forEach(([k,,fl])=>fl.forEach(f=>{ if(NETF[f]) NETF[f].sel = !!flowSel.netwerk[k]; }));
  Object.values(FLOWS).forEach(f=>{ f.line.visible = !!f.sel; if(!f.sel) f.dots.forEach(d=>d.visible = false); });
  Object.values(NETF).forEach(f=>{ f.line.visible = !!f.sel; if(!f.sel){ f.dots.forEach(d=>d.visible = false); f.upDots.forEach(d=>d.visible = false); } });
  showEnergy = Object.values(flowSel.stroom).some(Boolean); flowGroup.visible = showEnergy; gridMast.visible = !!flowSel.stroom.net;
  showNet = Object.values(flowSel.netwerk).some(Boolean); netGroup.visible = showNet;
  const any = showEnergy || showNet || Object.values(W).some(Boolean);
  $('flowbtn').setAttribute('aria-pressed', String(any));
  try{ localStorage.setItem(FLOWSEL_KEY, JSON.stringify(flowSel)); }catch(_){}
  renderEnergy(); if(showNet) renderNetFlows();
}
const eLabelOn = k => { if(!flowSel.labels) return false; const it = FLOW_MENU[0][2].find(([, , , labs])=>labs.includes(k)); return !!(it && flowSel.stroom[it[0]]); };
const nLabelOn = k => { if(!flowSel.labels) return false; const it = FLOW_MENU[1][2].find(([, , , labs])=>labs.includes(k)); return !!(it && flowSel.netwerk[it[0]]); };
function renderFlowPanel(){
  const el = $('flowpanel'), all = FLOW_MENU.every(([g,,items])=>items.every(([k])=>flowSel[g][k]));
  const cb = (key, on, txt, cls='') => `<label class="${cls}"><input type="checkbox" data-f="${key}" ${on?'checked':''}> ${txt}</label>`;
  el.innerHTML = `<div class="grp master-grp">${cb('*', all, 'Alles tonen', 'master')}${cb('labels', flowSel.labels, 'Labels met waarden tonen')}</div>` + FLOW_MENU.map(([g,name,items])=>{
    const gAll = items.every(([k])=>flowSel[g][k]);
    return `<div class="grp"><h3>${name}</h3>${cb(g, gAll, 'Alle '+name.toLowerCase())}${items.map(([k,txt])=>cb(g+':'+k, !!flowSel[g][k], txt, 'sub')).join('')}</div>`; }).join('');
}
$('flowbtn').onclick = ()=>{ const p = $('flowpanel'); p.hidden = !p.hidden; $('flowbtn').setAttribute('aria-expanded', String(!p.hidden)); if(!p.hidden){ $('lblpanel').hidden = true; $('detpanel').hidden = true; renderFlowPanel(); } };
$('flowpanel').addEventListener('change', e=>{ const k = e.target.dataset.f; if(!k) return; const v = e.target.checked;
  if(k==='labels'){ flowSel.labels = v; renderFlowPanel(); applyFlowSel(); updateLabels(); return; }
  if(k==='*') FLOW_MENU.forEach(([g,,items])=>items.forEach(([i])=>flowSel[g][i] = v));
  else if(!k.includes(':')){ const grp = FLOW_MENU.find(([g])=>g===k); grp[2].forEach(([i])=>flowSel[k][i] = v); }
  else { const [g,i] = k.split(':'); flowSel[g][i] = v; }
  renderFlowPanel(); applyFlowSel(); });
$('lblbtn').onclick = ()=>{ const p=$('lblpanel'); p.hidden = !p.hidden; if(!p.hidden){ $('flowpanel').hidden = true; $('detpanel').hidden = true; } $('lblbtn').setAttribute('aria-expanded', String(!p.hidden)); if(!p.hidden) renderLblPanel(); };
$('lblpanel').addEventListener('change', onLblChange);
$('lblpanel').addEventListener('click', e=>{ const b=e.target.closest('[data-bulk]'); if(!b) return; const v=b.dataset.bulk==='1';
  rooms.forEach(r=>lbl.rooms[r.id]=v); Object.keys(lbl.floors).forEach(f=>lbl.floors[f]=v); if(v) lbl.all=true; saveLbl(); renderLblPanel(); updateLabels(); });
$('lblbtn').setAttribute('aria-pressed', String(lbl.all));
document.addEventListener('keydown', e=>{ if(e.key==='l' && !e.target.closest('input,select,textarea')){ lbl.all=!lbl.all; saveLbl(); renderLblPanel(); } });
$('reset').onclick = ()=>{ camera.position.copy(HOME_POS); controls.target.set(0,targetY,0); controls.autoRotate=true; syncRotateBtn(); };

