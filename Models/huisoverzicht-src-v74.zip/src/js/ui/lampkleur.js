/* ---------- Acties ---------- */
// ---------- lampkleur en helderheid ----------
const kToRgb = k=>{ const t = k/100; let r,g,b; if(t<=66){ r = 255; g = 99.47*Math.log(t)-161.12; b = t<=19 ? 0 : 138.52*Math.log(t-10)-305.04; } else { r = 329.7*Math.pow(t-60,-0.1332); g = 288.12*Math.pow(t-60,-0.0755); b = 255; }
  return [r,g,b].map(v=>Math.round(Math.min(255,Math.max(0,v)))); };
const COLOR_MODES = ['hs','xy','rgb','rgbw','rgbww'];
const lampCanColor = l=> (l.modes||[]).some(m=>COLOR_MODES.includes(m));
const lampCanTemp  = l=> (l.modes||[]).includes('color_temp');
const lampCanDim   = l=> (l.modes||[]).some(m=>m!=='onoff');
function lampRGB(l){ return (l.cmode && COLOR_MODES.includes(l.cmode) && l.rgb) ? l.rgb : kToRgb(l.kelvin||2700); }
const K_PRESETS = [['Warm',2200],['Warmwit',2700],['Neutraal',4000],['Daglicht',6500]];
const C_PRESETS = [['Rood',[255,40,30]],['Oranje',[255,130,20]],['Geel',[255,210,60]],['Groen',[60,220,90]],['Blauw',[40,110,255]],['Paars',[150,60,255]],['Roze',[255,80,170]]];
const lampSel = {};
const lampGroups = r=>{ const g = new Map(); r.lampObjs.filter(l=>!l.nc).forEach(l=>{ const k = l.ha || 'i'+l.i; if(!g.has(k)) g.set(k, []); g.get(k).push(l); }); return [...g.entries()]; };
