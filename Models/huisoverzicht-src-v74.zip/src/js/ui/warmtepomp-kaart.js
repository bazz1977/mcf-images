// ---------- warmtepompkaart ----------
function renderNet(){
  const el = $('netcard'); if(!el) return;
  const devs = OMADA.devices, off = devs.filter(d=>!d.online), upd = devs.filter(d=>d.update);
  const poe = OMADA.ports.filter(p=>p.w!=null && p.w>0.1), tot = poe.reduce((a,p)=>a+p.w,0);
  el.innerHTML = `<p class="eyebrow">Netwerk · Omada</p>
    <div class="stats" style="grid-template-columns:1fr 1fr 1fr"><div class="stat"><small>Apparaten</small><strong>${devs.length-off.length}</strong><em> / ${devs.length} online</em></div>
      <div class="stat"><small>Clients</small><strong>${OMADA.clients ?? '–'}</strong></div>
      <div class="stat"><small>PoE totaal</small><strong>${fmt(tot,1)}</strong><em> W</em></div></div>
    ${devs.map(d=>`<div class="plug"><span>${d.name}<span style="color:var(--faint)"> · ${d.model}${d.guess?' · plek?':''}</span>${d.update?'<span class="lock" title="Firmware-update beschikbaar">update</span>':''}</span><span class="v">${d.clients!=null?d.clients+' clients':''}</span><span style="width:10px;height:10px;border-radius:50%;justify-self:center;background:${d.online?'var(--ok)':'var(--warn)'}" title="${d.online?'online':'offline'}"></span></div>`).join('')}
    <p class="eyebrow" style="margin:12px 0 6px">PoE per poort (TL-SG2428P)</p>
    <div style="display:grid;grid-template-columns:repeat(12,1fr);gap:3px">${OMADA.ports.map(p=>`<div title="Poort ${p.n}${p.w!=null?': '+fmt(p.w,1)+' W':''}" style="font-family:var(--mono);font-size:9px;text-align:center;padding:3px 0;border-radius:4px;background:${p.w>0.1?'rgba(255,196,107,.22)':p.link?'rgba(143,209,122,.14)':'var(--panel2)'};color:${p.w>0.1?'var(--lamp)':'var(--muted)'}">${p.n}<br>${p.w>0.1?Math.round(p.w):'·'}</div>`).join('')}</div>`;
}
function applyNet(){
  OMADA.devices.forEach(d=>{ if(d.led){ d.led.emissive.setHex(d.online ? (d.update ? 0x3fa7ff : 0x46d17a) : 0xf08a5d); d.led.emissiveIntensity = 1.4; } });
  if(OMADA.portLeds) OMADA.portLeds.forEach((m,i)=>{ const p = OMADA.ports[i]; m.emissive.setHex(p.w>0.1 ? 0xffb347 : 0x46d17a); m.emissiveIntensity = (p.w>0.1 || p.link) ? 1.6 : 0; });
  const m = OMADA.devices.find(d=>d.kind==='bridge' && d.name.endsWith('Master')), sl = OMADA.devices.find(d=>d.kind==='bridge' && d.name.endsWith('Slave'));
  if(OMADA.linkMat) OMADA.linkMat.color.setHex(m && sl && m.online && sl.online ? 0x7fd0ff : 0xf08a5d);
}
// (v46) tappen herkennen: de onderste boilertemperatuur zakt snel (koud water komt binnen) terwijl de warmtepomp niet aan het opwarmen is
function checkTap(){
  const u = HP.lp9, v = u.v.swwLow ?? u.v.sww; if(v==null) return;
  const t = Date.now(); u.tapHist.push([t, v]); u.tapHist = u.tapHist.filter(([a])=>t-a < 180000);
  const old = u.tapHist.find(([a])=>t-a > 45000) || u.tapHist[0];
  const rate = old && t-old[0] > 20000 ? (old[1]-v) / ((t-old[0])/60000) : 0;    // °C per minuut daling
  if(rate > 0.6 && HP_MODE(u.v.status)[0]!=='dhw') u.tapUntil = t + 60000;
  u.tapping = t < u.tapUntil;
}
function renderHP(){
  const el = $('hpcard'); if(!el) return;
  el.innerHTML = `<p class="eyebrow">Warmtepomp · Weheat</p>` + Object.values(HP).map(u=>{
    const v = u.v, [m, label] = HP_MODE(v.status);
    const col = {heat:'#ff8a3d', dhw:'#c47bff', cool:'#3fa7ff', defrost:'#dfe8ff', run:'#ffc46b'}[m] || 'var(--muted)';
    return `<div class="hph"><b>${u.name}</b><span class="pill" style="color:${col};border-color:${col}">${label||'–'}</span></div>
      <div class="hpu">
        <div><small>Stroom in</small><b>${fmtW(v.pin)}</b></div>
        <div><small>Warmte uit</small><b>${fmtW(v.pout)}</b></div>
        <div><small>COP</small><b>${v.cop!=null&&v.pin>50?fmt(v.cop,1):'–'}</b></div>
        <div><small>Water in/uit</small><b>${fmt(v.tin,0)}/${fmt(v.tout,0)}°</b></div>
        <div><small>Compressor</small><b>${rnd(v.comp)}%</b></div>
        ${u.sww ? `<div><small>Boiler boven/onder${u.tapping?' · <span style="color:var(--lamp)">water tappen</span>':''}</small><b>${fmt(v.sww,0)}/${fmt(v.swwLow,0)}°</b></div>` : `<div><small>Doel water</small><b>${fmt(v.target,0)}°</b></div>`}
      </div>`; }).join('');
}
function hpBuitenPipe(){                                          // (v64) twee leidingen buitenunit ↔ binnenunit, in de gevel maar altijd zichtbaar (door de muur heen)
  const u = HP.lp9; if(u.outPipe) return; const L3 = (x,h,y)=> new THREE.Vector3(mx(x), h, mz(y));
  const mk = (dx, color)=>{ const x = 4.6+dx, xi = 6.29, yi = 0.22+dx;
    const curve = ortho([L3(x,0.35,-0.45), L3(x,0.35,-0.08), L3(x,F1+COLH_OUT+dx,-0.08), L3(xi,F1+COLH_OUT+dx,-0.08), L3(xi,F1+COLH_OUT+dx,yi)]);
    const tm = new THREE.MeshBasicMaterial({color, transparent:true, opacity:.45, depthTest:false, depthWrite:false});
    const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 200, .02, 6, false), tm); tube.renderOrder = 5; scene.add(tube);
    const dm = new THREE.MeshBasicMaterial({color:0xff8a3d, depthTest:false, transparent:true});
    return {curve, dm, tm, tube, t:0, dots:Array.from({length:22}, ()=>{ const d = new THREE.Mesh(new THREE.SphereGeometry(.05,10,8), dm); d.renderOrder = 7; d.visible = false; scene.add(d); return d; })}; };
  u.outPipes = [mk(-0.06, 0xd9564a), mk(0.06, 0x4f86d6)];     // aanvoer (warm) en retour (koud)
  u.outPipe = u.outPipes[0];
}
const COLH_OUT = 0.40;
function applyHP(){
  Object.values(HP).forEach(u=>{ const [m,,col] = HP_MODE(u.v.status);
    [u.ledMat2].forEach(lm=>{ if(!lm) return; lm.emissive.setHex(col); lm.emissiveIntensity = m==='idle' ? 0 : 2; }); });
}
