// ===== WAT SPEELT ER OP DE TV — app-naam in huiskleur (geen officiële logo's). Toevoegen = één regel. =====
const TV_APP_LOOK = [
  // [weergavenaam, herkenning (app_id / app_name / bron), achtergrond, tekstkleur]
  ['NETFLIX',      /netflix/i,                        '#000000', '#e50914'],
  ['NLZIET',       /nlziet/i,                         '#101820', '#ff7a00'],
  ['HBO Max',      /hbo|com\.wbd|^max$|\bmax app\b/i,  '#0a0f3c', '#ffffff'],   // (v52) niet meer op elk los woord 'Max' (VRT MAX, Max Verstappen …)
  ['Disney+',      /disney/i,                         '#0b1a4b', '#ffffff'],
  ['prime video',  /prime|amazon/i,                   '#0f171e', '#1fa5e0'],
  ['YouTube',      /youtube/i,                        '#ffffff', '#ff0000'],
  ['Videoland',    /videoland/i,                      '#1a0a14', '#ff2d55'],
  ['NPO Start',    /\bnpo\b|npo ?start|nl\.npo/i,     '#ff6d00', '#ffffff'],
  ['VRT MAX',      /vrt/i,                            '#111111', '#ffffff'],
  ['VTM GO',       /vtm/i,                            '#ffffff', '#d4001e'],
  ['Streamz',      /streamz/i,                        '#16092f', '#ffffff'],
  ['GoPlay',       /goplay/i,                         '#000000', '#ffffff'],
  ['Viaplay',      /viaplay/i,                        '#1c0f30', '#ff2a6d'],
  ['SkyShowtime',  /skyshowtime/i,                    '#000000', '#ffffff'],
  ['Spotify',      /spotify/i,                        '#121212', '#1ed760'],
  ['Plex',         /plex/i,                           '#1f1f1f', '#e5a00d'],
  ['Kodi',         /kodi/i,                           '#17212b', '#35b2e5'],
  ['Twitch',       /twitch/i,                         '#9146ff', '#ffffff'],
  ['F1 TV',        /f1 ?tv|formula ?1|com\.formula1|\bf1\b/i,  '#15151e', '#e10600'],
  ['Apple TV+',    /com\.apple\.tv|apple ?tv\+/i,     '#000000', '#ffffff'],
  ['PlayStation',  /ps5|playstation/i,                '#00439c', '#ffffff'],
  ['HDMI',         /com\.sony\.dtv\.tvx|tvx|hdmi/i,    '#16324f', '#ffffff'],   // Sony-tv staat op een ingang (Apple TV / PS5)
];
// 'nl.nlziet.androidtv' → 'Nlziet' (nooit een ruwe pakketnaam op het scherm)
function prettyApp(n){ if(!/^[a-z0-9_]+(\.[a-z0-9_]+)+$/i.test(n)) return n;
  const skip = /^(com|nl|be|org|net|tv|app|android|androidtv|atv|mobile|player|ninja|livingroom|leanback|google|sony|dtv|apps)$/i;
  const part = n.split('.').find(p=>!skip.test(p)) || n.split('.').pop(); return part.charAt(0).toUpperCase()+part.slice(1); }
function tvLook(m){ if(!m || !mediaOn(m)) return null; const a = m.a||{};
  if(m.state==='idle' && (m===MEDIA.atvWoon || m===MEDIA.atvSlaap || m===extraATV)) return {name:'Apple TV', bg:'#111418', fg:'#ffffff', title:'startscherm', pic:null};   // (v51) idle = startscherm; oude app-info (bv. HBO Max) negeren
  const key = [a.app_id, a.app_name, a.source, a.media_channel].filter(Boolean).join(' ');   // (v52) app/bron/kanaal; de titel telt niet meer mee
  const hit = TV_APP_LOOK.find(([,re])=>[a.app_id, a.app_name, a.source, a.media_channel].filter(Boolean).some(v=>re.test(String(v))));   // per veld, zodat ^…$ werkt
  const title = [a.media_series_title, a.media_title].filter(Boolean).join(' · ') || a.media_artist || (['paused','buffering'].includes(m.state) ? MEDIA_STATE_NL[m.state] : '');   // (v47) 'Stil' niet meer als titel
  const pic = (m.a||{}).entity_picture || null;          // hoes/poster/speelbeeld van wat er speelt (via HA)
  if(hit) return {name:hit[0], bg:hit[2], fg:hit[3], title, pic};
  return {name:prettyApp(a.app_name || a.source || a.app_id || ''), bg:'#16324f', fg:'#ffffff', title, pic};
}
// wat staat er op de Sony (woonkamer) / Philips (slaapkamer)?
const withName = (look, def)=> look ? (look.name ? look : {...look, name:def, bg:'#111418', fg:'#ffffff'}) : null;
function tvShows(where){
  if(where==='woon'){
    if(mediaOn(MEDIA.atvWoon)) return withName(tvLook(MEDIA.atvWoon), 'Apple TV');
    if(mediaOn(MEDIA.ps5)){ const game = (MEDIA.ps5.a||{}).media_title || ''; return {name: game || 'PlayStation', bg:'#00439c', fg:'#fff', title: game ? 'PlayStation 5' : '', pic:(MEDIA.ps5.a||{}).entity_picture||null}; }   // PSN-integratie: spelnaam groot
    const own = tvLook(MEDIA.tv);
    if(own && own.name==='HDMI' && extraATV && mediaOn(extraATV)) return withName(tvLook(extraATV), 'Apple TV');
    return own;
  }
  const aS = MEDIA.atvSlaap.a||{}, atvBusy = mediaOn(MEDIA.atvSlaap) && !(MEDIA.atvSlaap.state==='idle' && !aS.app_id && !aS.app_name && !aS.media_title);   // (v48) 'idle' zonder app = Apple TV staat niet echt op
  if(atvBusy) return withName(tvLook(MEDIA.atvSlaap), 'Apple TV');
  // (v50) Philips staat op een ingang (HDMI / 'TV') terwijl de Apple TV aan staat maar niets meldt: toon Apple TV i.p.v. het ingang-icoon
  const pl = tvLook(MEDIA.tvSlaap), pa = MEDIA.tvSlaap.a||{};
  if(pl && mediaOn(MEDIA.atvSlaap) && /hdmi|^tv$|watch ?tv|live ?tv|tv-?kanalen/i.test(String(pa.source || pa.app_name || pl.name || '')))
    return {name:'Apple TV', bg:'#111418', fg:'#ffffff', title:'via HDMI · app wordt niet doorgegeven', pic:null};
  return withName(pl, 'Philips');
}
const tvCanvas = {}, tvPics = {};
function tvPic(url){ if(!url) return null; let p = tvPics[url];
  if(!p){ p = tvPics[url] = {img:new Image(), ok:false}; p.img.crossOrigin = 'anonymous';
    p.img.onload = ()=>{ p.ok = true; Object.values(tvCanvas).forEach(t=>t.key=''); applyPlugs(); };
    p.img.src = url; }
  return p.ok ? p.img : null; }
function tvTexture(id, look){
  let t = tvCanvas[id];
  if(!t){ const c = document.createElement('canvas'); c.width = 640; c.height = 360; const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; t = tvCanvas[id] = {c, tex, key:''}; }
  const img = look ? tvPic(look.pic) : null;
  const key = look ? [look.name, look.bg, look.fg, look.title, img ? look.pic : ''].join('|') : '';
  if(key===t.key) return t.tex; t.key = key;
  const g = t.c.getContext('2d'), W = 640, H = 360;
  const bg = look ? look.bg : '#16324f';
  const gr = g.createLinearGradient(0,0,W,H); gr.addColorStop(0, bg); gr.addColorStop(1, shade(bg,-0.35)); g.fillStyle = gr; g.fillRect(0,0,W,H);
  if(img){                                                   // afbeelding vullend, app-naam + titel eronder
    const r = Math.max(W/img.width, H/img.height), w = img.width*r, h = img.height*r;
    try{ g.drawImage(img, (W-w)/2, (H-h)/2, w, h); }catch(_){}
    const sh = g.createLinearGradient(0,H*0.55,0,H); sh.addColorStop(0,'rgba(0,0,0,0)'); sh.addColorStop(1,'rgba(0,0,0,.8)'); g.fillStyle = sh; g.fillRect(0,0,W,H);
    g.textAlign = 'left'; g.textBaseline = 'alphabetic';
    g.font = '800 30px Sora, system-ui, sans-serif'; g.fillStyle = look.fg==='#ffffff' || look.bg==='#ffffff' ? '#ffffff' : look.fg; g.fillText(look.name, 24, H-58);
    if(look.title){ g.font = '500 24px Sora, system-ui, sans-serif'; g.fillStyle = 'rgba(255,255,255,.9)'; let tt = look.title; while(g.measureText(tt).width > W-48 && tt.length>4) tt = tt.slice(0,-2); if(tt!==look.title) tt += '…'; g.fillText(tt, 24, H-24); }
  } else if(look && look.name){
    let size = 118; g.font = `800 ${size}px Sora, system-ui, sans-serif`;
    while(g.measureText(look.name).width > W*0.82 && size > 40){ size -= 6; g.font = `800 ${size}px Sora, system-ui, sans-serif`; }
    g.fillStyle = look.fg; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(look.name, W/2, look.title ? H*0.44 : H/2);
    if(look.title){ g.font = '500 30px Sora, system-ui, sans-serif'; g.fillStyle = 'rgba(255,255,255,.85)'; let tt = look.title; while(g.measureText(tt).width > W*0.86 && tt.length>4) tt = tt.slice(0,-2); if(tt!==look.title) tt += '…'; g.fillText(tt, W/2, H*0.74); }
  }
  t.tex.needsUpdate = true; return t.tex;
}
function shade(hex, f){ const c = new THREE.Color(hex); return '#'+c.lerp(new THREE.Color(f<0?0x000000:0xffffff), Math.abs(f)).getHexString(); }
function paintTV(mat, id, on, look){
  if(!mat) return;
  if(on){ const tex = tvTexture(id, look); if(mat.emissiveMap!==tex){ mat.emissiveMap = tex; mat.needsUpdate = true; } mat.emissive.set(0xffffff); mat.emissiveIntensity = 0.9; }
  else mat.emissiveIntensity = 0;
}
function applyPlugs(){
  rooms.forEach(r=>r.plugs.forEach(p=>{ if(!p.ledMat) return; p.ledMat.emissive.setHex((p.w||0) > 5 ? 0xffc46b : 0x46d17a); p.ledMat.emissiveIntensity = p.on ? 1.8 : 0; }));
  const tvPlug = byId.woon.plugs.find(p=>p.name==='Tv');
  const tvOn = MEDIA.tv.ent || !LIVE ? mediaOn(MEDIA.tv) : (tvPlug && tvPlug.on && (tvPlug.w||0) > 30);
  paintTV(tvScreen, 'woon', tvOn, tvShows('woon'));
  if(sonosLed) sonosLed.emissiveIntensity = mediaOn(MEDIA.sonos) ? 1.5 : 0;
  Object.values(MEDIA).forEach(m=>{ if(m.led) m.led.emissiveIntensity = mediaOn(m) ? 1.6 : 0.15; });
  // Philips zit niet in HA: aan = Apple TV aan, of de tv-stekker trekt stroom (> 30 W)
  const sTv = byId.slaap.plugs.find(p=>/^tv$/i.test(p.name)), sPlugOn = !!(sTv && sTv.on && (sTv.w||0) > 30);
  paintTV(MEDIA.tvSlaap.screen, 'slaap', mediaOn(MEDIA.tvSlaap) || mediaOn(MEDIA.atvSlaap) || sPlugOn, tvShows('slaap') || (sPlugOn ? {name:'Philips', bg:'#16324f', fg:'#ffffff', title:'tv staat aan · app onbekend'} : null));
  if(MEDIA.tvSlaap.glowMat){ const on = (LIVE ? AMBI.on : true) && (mediaOn(MEDIA.tvSlaap) || mediaOn(MEDIA.atvSlaap) || sPlugOn);
    MEDIA.tvSlaap.glowMat.color.setRGB(...AMBI.rgb.map(v=>v/255), THREE.SRGBColorSpace); MEDIA.tvSlaap.glowMat.opacity = on ? (night ? 0.7 : 0.45) : 0; }
  if(LOCK.ledMat){ LOCK.ledMat.emissive.setHex(LOCK.state==='locked' ? 0x46d17a : LOCK.state==='jammed' ? 0xf08a5d : 0xffc46b); LOCK.ledMat.emissiveIntensity = LOCK.state ? 1.6 : 0; }
}
