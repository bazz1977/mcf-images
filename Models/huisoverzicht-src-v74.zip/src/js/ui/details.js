// ===== (v65) DETAILS: tuin samenvoegen (veel minder tekenopdrachten) + menu om onderdelen uit te zetten =====
const treeGroup = new THREE.Group(), gardenGroup = new THREE.Group(); scene.add(treeGroup, gardenGroup);
{ const buckets = new Map(), pick = new Set(pickables), keep = [];
  scene.updateMatrixWorld(true);
  garden.forEach(root=>{ const isTree = !!root.userData.tree; let simple = true;
    if(root.userData.noMerge){ keep.push([root, false]); return; }
    root.traverse(o=>{ if(!o.isMesh) return;
      const ok = !o.isInstancedMesh && !Array.isArray(o.material) && !o.material.transparent && !pick.has(o) && o.geometry.attributes.position && o.geometry.attributes.normal;
      if(!ok){ simple = false; return; }
      const key = (isTree?'t':'g')+o.material.uuid+(o.castShadow?1:0)+(o.receiveShadow?1:0);
      if(!buckets.has(key)) buckets.set(key, {mat:o.material, tree:isTree, cast:o.castShadow, recv:o.receiveShadow, geos:[]});
      let g = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone();
      Object.keys(g.attributes).forEach(n=>{ if(!['position','normal','uv'].includes(n)) g.deleteAttribute(n); });
      if(!g.attributes.uv) g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(g.attributes.position.count*2), 2));
      g.applyMatrix4(o.matrixWorld); buckets.get(key).geos.push(g); o.userData.merged = true; });
    keep.push([root, isTree]); });
  buckets.forEach(b=>{ const geo = mergeGeometries(b.geos, false); if(!geo) return; const m = new THREE.Mesh(geo, b.mat); m.castShadow = b.cast; m.receiveShadow = b.recv; (b.tree ? treeGroup : gardenGroup).add(m); });
  // originelen: samengevoegde meshes weg, de rest (transparant, instanced, klikbaar) verhuist naar de juiste groep
  keep.forEach(([root, isTree])=>{ const rm = []; root.traverse(o=>{ if(o.isMesh && o.userData.merged) rm.push(o); }); rm.forEach(o=>o.parent && o.parent.remove(o));
    let left = false; root.traverse(o=>{ if(o!==root && (o.isMesh || o.isLine || o.isPoints)) left = true; }); if(root.isMesh || root.isLine) left = !root.userData.merged;
    if(left){ const tgt = isTree ? treeGroup : gardenGroup; tgt.attach(root); } else if(root.parent) root.parent.remove(root); });
}
function applyDetail(){
  const k = mode===-1;
  const klein = DET.grond!=='alles';   // zonder volledig grasveld: bomen en tuin zweven, dus ook weg
  treeGroup.visible = !k && DET.bomen && !klein; gardenGroup.visible = !k && DET.tuin && !klein;
  ground.visible = !k && DET.grond==='alles'; ground4.visible = !k && DET.grond==='rondom';
  sun.castShadow = !!DET.schaduw; sun.shadow.needsUpdate = true;
  renderer.setPixelRatio(DET.scherp ? Math.min(devicePixelRatio,2) : 1); resize();
  try{ localStorage.setItem('huis-details-v1', JSON.stringify(DET)); }catch(_){}
}
const DET_ITEMS = [['bomen','Bomen'],['tuin','Tuin: hekken, hagen, zwembad, vijver, wegen'],['schaduw','Schaduwen'],['wolken','Wolken'],['scherp','Scherp beeld (hoge resolutie)'],['zuinig','Zuinig: max. 30 beelden/s']];
function renderDetPanel(){
  const klein = DET.grond!=='alles';
  $('detpanel').innerHTML = `<div class="grp"><h3>Grasveld</h3>${[['alles','Heel het perceel'],['rondom','4 m rondom het huis (snel)'],['uit','Geen gras']].map(([v,t])=>`<label class="sub"><input type="radio" name="grond" data-g="${v}" ${DET.grond===v?'checked':''}> ${t}</label>`).join('')}</div>
    <div class="grp"><h3>Details</h3>${DET_ITEMS.map(([k,t])=>{ const off = klein && (k==='bomen' || k==='tuin'); return `<label class="sub"${off?' style="opacity:.45" title="Alleen met het hele perceel"':''}><input type="checkbox" data-d="${k}" ${DET[k]?'checked':''} ${off?'disabled':''}> ${t}</label>`; }).join('')}</div>
    <div class="grp" style="font-size:12px;color:var(--muted)"><span>Snelheid nu: <b id="fps" style="font-family:var(--mono);color:var(--text)">${fpsNow||'…'} beelden/s</b></span><span>Tip: schaduwen en scherp beeld kosten het meest.</span></div>`; }
$('detbtn').onclick = ()=>{ const p = $('detpanel'); p.hidden = !p.hidden; $('detbtn').setAttribute('aria-expanded', String(!p.hidden)); if(!p.hidden){ $('lblpanel').hidden = true; $('flowpanel').hidden = true; renderDetPanel(); } };
$('detpanel').addEventListener('change', e=>{ const g = e.target.dataset.g; if(g){ DET.grond = g; applyDetail(); renderDetPanel(); return; }
  const k = e.target.dataset.d; if(!k) return; DET[k] = e.target.checked; applyDetail(); });
applyMode(); applyNight(); applyAC(); applyHP(); applyColors(); updateLabels(); renderPanel(); applyFlowSel();
walls.scale.y = wallScale; upWalls.scale.y = upScale; cellarWalls.scale.y = cellarScale;
$('loading').remove();
loop();
