/* ---------- Interactie in 3D ---------- */
const ray = new THREE.Raycaster(), ptr = new THREE.Vector2();
function setPtr(e){
  const rect = canvas.getBoundingClientRect();
  ptr.set(((e.clientX-rect.left)/rect.width)*2-1, -((e.clientY-rect.top)/rect.height)*2+1);
  ray.setFromCamera(ptr, camera);
}
function isShown(o){ const f = o.userData.room?.floor ?? o.userData.lamp?.room.floor; if(f===-1 && mode!==-1) return false; while(o){ if(!o.visible && !o.userData.lamp) return false; o=o.parent; } return true; }
let downAt = null;
canvas.addEventListener('pointerdown', e=>{ downAt = [e.clientX,e.clientY]; });
canvas.addEventListener('pointerup', e=>{
  if(!downAt || Math.hypot(e.clientX-downAt[0], e.clientY-downAt[1])>5) return;
  setPtr(e);
  const hits = ray.intersectObjects(pickables.filter(isShown), false);
  if(!hits.length) return;
  const u = hits[0].object.userData;
  if(u.lamp){ toggleLamp(u.lamp); select(u.lamp.room); }
  else if(u.room){ select(u.room); }
});
canvas.addEventListener('pointermove', e=>{
  setPtr(e);
  const hit = ray.intersectObjects(pickables.filter(isShown), false)[0];
  canvas.style.cursor = hit ? 'pointer' : '';
});
controls.addEventListener('start', ()=>{ if(controls.autoRotate){ controls.autoRotate=false; syncRotateBtn(); } });

