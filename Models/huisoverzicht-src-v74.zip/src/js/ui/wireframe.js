/* ---------- Wireframe-weergave van muren, dak en deuren ---------- */
const wireLineMat = new THREE.LineBasicMaterial({color:0x7fd0ff, transparent:true, opacity:.8});
const wireGhost = new THREE.MeshBasicMaterial({color:0x7fd0ff, transparent:true, opacity:.035, depthWrite:false, side:THREE.DoubleSide});
let wireParts = null;
function buildWire(){
  wireParts = [];
  const STRUCT = new Set([wallMat, brickMat, cellarIn, concrete, roofMat, frameMat, aluMat, roofingMat, roofShingleMat, ...WIRE_MATS]);
  [walls, upWalls, cellarWalls, roofGroup, flatRoof].forEach(g=>g.traverse(o=>{
    if(!o.isMesh || !o.material) return;
    const list = Array.isArray(o.material) ? o.material : [o.material];
    if(!list.every(m=>STRUCT.has(m))) return;
    const pos = o.geometry.attributes.position; if(!pos || pos.count > 8000) return;
    const line = new THREE.LineSegments(new THREE.EdgesGeometry(o.geometry, 25), wireLineMat); line.raycast = ()=>{}; line.visible = false; o.add(line);
    wireParts.push({o, mat:o.material, cast:o.castShadow, line});
  }));
}
function setWire(on){
  wire = on; if(on && !wireParts) buildWire();
  (wireParts||[]).forEach(p=>{ p.o.material = on ? wireGhost : p.mat; p.o.castShadow = on ? false : p.cast; p.line.visible = on; });
  wireColor(); applyMode(); $('wallmode').value = on ? 'wire' : 'solid';
}
function wireColor(){ const c = night ? 0x7fd0ff : 0x24303c; wireLineMat.color.setHex(c); wireLineMat.opacity = night ? .8 : .65; wireGhost.color.setHex(c); }
try{ if(localStorage.getItem('huis-muren')==='wire') setWire(true); }catch(_){}

