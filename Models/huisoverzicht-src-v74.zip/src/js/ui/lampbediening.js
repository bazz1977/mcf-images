const groupAll = g => g.rooms.flatMap(id => byId[id] ? byId[id].lampObjs : []);
const usable = ls => ls.filter(l=>!l.nc);
// lampen achter een keuze-sleutel: '*' = hele ruimte, anders entity of 'i<n>'
function lampsFor(r, key){
  if(key==='*') return usable(r.lampObjs);
  const g = lampGroups(r).find(([k])=>k===key); return g ? g[1] : [];
}
// bedieningsblok voor een verzameling lampen; tgt = 'r:<ruimte>' of 'g:<index>'
function ctlHTML(ls, tgt){
  if(!ls.length) return '<small>Geen bereikbare lampen.</small>';
  const dim = ls.some(lampCanDim), tmp = ls.some(lampCanTemp), col = ls.some(lampCanColor), l = ls.find(x=>x.on) || ls[0];
  const bri = Math.round((l.bri ?? 255)/2.55), rgb = lampRGB(l), hex = '#'+rgb.map(v=>v.toString(16).padStart(2,'0')).join('');
  const isC = l.cmode && COLOR_MODES.includes(l.cmode);
  return `${dim ? `<label class="bri">☀ <input type="range" data-bri="${tgt}" min="1" max="100" value="${bri}" aria-label="Helderheid"> <b>${bri}%</b></label>` : '<small>Alleen aan/uit.</small>'}
    ${tmp ? `<div class="sw8" role="group" aria-label="Kleurtemperatuur">${K_PRESETS.map(([n,k])=>{ const c = kToRgb(k); return `<button data-k="${k}" data-t="${tgt}" title="${n} (${k} K)" aria-label="${n}" aria-pressed="${!isC && Math.abs((l.kelvin||0)-k)<150}" style="background:rgb(${c})"></button>`; }).join('')}</div>` : ''}
    ${col ? `<div class="sw8" role="group" aria-label="Kleur">${C_PRESETS.map(([n,c])=>`<button data-rgb="${c}" data-t="${tgt}" title="${n}" aria-label="${n}" aria-pressed="${isC && l.rgb && l.rgb.every((v,i)=>Math.abs(v-c[i])<25)}" style="background:rgb(${c})"></button>`).join('')}<input type="color" data-col="${tgt}" value="${hex}" aria-label="Eigen kleur"></div>` : ''}`;
}
function lampCtlHTML(r){
  const groups = lampGroups(r); if(!groups.length) return '';
  let key = lampSel[r.id]; if(key!=='*' && !groups.some(([k])=>k===key)) key = groups.length>1 ? '*' : groups[0][0];
  lampSel[r.id] = key;
  const opts = (groups.length>1 ? [['*','Alle lampen in deze ruimte']] : []).concat(groups.map(([k,g])=>[k,[...new Set(g.map(x=>x.name))].join(' + ')]));
  return `<div class="lampctl">
    <div class="hd"><span>Instellen</span>${opts.length>1 ? `<select id="lc-sel" aria-label="Kies lamp">${opts.map(([k,n])=>`<option value="${k}" ${k===key?'selected':''}>${n}</option>`).join('')}</select>` : `<span>${opts[0][1]}</span>`}</div>
    ${ctlHTML(lampsFor(r,key), 'r:'+r.id)}</div>`;
}
const targetLamps = tgt => { const [t,id] = tgt.split(':'); return t==='g' ? usable(groupAll(LAMP_GROUPS[+id])) : lampsFor(byId[id], lampSel[id]); };
// kleur/helderheid toepassen; per lamp alleen wat die lamp kan
function applyLook(ls, patch){
  const ents = {bri:new Set(), k:new Set(), rgb:new Set(), on:new Set()};
  ls.forEach(x=>{
    const p = {};
    if(patch.bri!=null && lampCanDim(x)){ p.bri = patch.bri; if(x.ha) ents.bri.add(x.ha); }
    if(patch.cmode==='color_temp' && lampCanTemp(x)){ p.cmode = 'color_temp'; p.kelvin = patch.kelvin; if(x.ha) ents.k.add(x.ha); }
    if(patch.cmode==='rgb' && lampCanColor(x)){ p.cmode = 'rgb'; p.rgb = patch.rgb; if(x.ha) ents.rgb.add(x.ha); }
    Object.assign(x, p); x.on = true; if(x.ha) ents.on.add(x.ha);
  });
  applyLamps(); renderPanel();
  if(!(LIVE && ha)) return;
  const call = (set, data)=>{ if(set.size) ha.call('light','turn_on',{entity_id:[...set], ...data}).catch(()=>{}); };
  if(patch.bri!=null) call(ents.bri, {brightness_pct: Math.max(1, Math.round(patch.bri/2.55))});
  if(patch.cmode==='color_temp') call(ents.k, {color_temp_kelvin: patch.kelvin});
  if(patch.cmode==='rgb') call(ents.rgb, {rgb_color: patch.rgb});
  const rest = [...ents.on].filter(e=>!ents.bri.has(e) && !ents.k.has(e) && !ents.rgb.has(e)); if(rest.length) call(new Set(rest), {});
}
function setGroupPower(ls, on){
  ls.forEach(x=>x.on = on); applyLamps(); renderPanel();
  const e = [...new Set(ls.map(x=>x.ha).filter(Boolean))];
  if(LIVE && ha && e.length) ha.call('light', on?'turn_on':'turn_off', {entity_id:e}).catch(()=>{});
}
let openGroup = -1;
function renderGroups(){
  const el = $('groupcard'); if(!el) return;
  el.innerHTML = `<p class="eyebrow">Lichtgroepen</p>` + LAMP_GROUPS.map((g,i)=>{
    const all = groupAll(g), ls = usable(all), n = ls.filter(l=>l.on).length, broken = all.length - ls.length;
    return `<div class="grp"><button class="grp-n" data-gopen="${i}" aria-expanded="${openGroup===i}">${openGroup===i?'▾':'▸'} ${g.name}</button>
      <span class="v">${n}/${ls.length} aan${broken?` · ${broken} buiten gebruik`:''}</span>
      ${ls.length ? `<button class="sw" data-gsw="${i}" aria-pressed="${n>0}" aria-label="${g.name} aan/uit"></button>` : '<span></span>'}</div>
      ${openGroup===i ? `<div class="lampctl" style="margin:4px 0 8px">${ctlHTML(ls,'g:'+i)}
        <div class="lamps" style="margin-top:2px">${all.map(l=>`<button class="lampbtn" data-glamp="${l.room.id}:${l.i}" aria-pressed="${l.on}" ${l.nc?'disabled style="opacity:.45;cursor:not-allowed"':''}><i ${l.on&&!l.nc?`style="background:rgb(${lampRGB(l)});box-shadow:0 0 8px rgb(${lampRGB(l)})"`:''}></i>${l.room.name.replace(/^Kamer /,'')} · ${l.name}${l.nc?' · '+(STATUS_NL[l.status]||''):''}</button>`).join('')}</div></div>` : ''}`;
  }).join('');
  el.querySelectorAll('[data-gopen]').forEach(b=>b.onclick=()=>{ const i = +b.dataset.gopen; openGroup = openGroup===i ? -1 : i; renderGroups(); });
  el.querySelectorAll('[data-gsw]').forEach(b=>b.onclick=()=>{ const ls = usable(groupAll(LAMP_GROUPS[+b.dataset.gsw])); setGroupPower(ls, !ls.some(l=>l.on)); });
  el.querySelectorAll('[data-glamp]').forEach(b=>b.onclick=()=>{ const [rid,i] = b.dataset.glamp.split(':'); toggleLamp(byId[rid].lampObjs[+i]); });
  bindCtl(el);
}
function bindCtl(root){
  root.querySelectorAll('[data-bri]').forEach(inp=>{ inp.oninput = e=>{ e.target.nextElementSibling.textContent = e.target.value+'%'; }; inp.onchange = e=>applyLook(targetLamps(e.target.dataset.bri), {bri: Math.round(+e.target.value*2.55)}); });
  root.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>applyLook(targetLamps(b.dataset.t), {cmode:'color_temp', kelvin:+b.dataset.k}));
  root.querySelectorAll('[data-rgb]').forEach(b=>b.onclick=()=>applyLook(targetLamps(b.dataset.t), {cmode:'rgb', rgb:b.dataset.rgb.split(',').map(Number)}));
  root.querySelectorAll('[data-col]').forEach(inp=>inp.onchange = e=>{ const h = e.target.value; applyLook(targetLamps(e.target.dataset.col), {cmode:'rgb', rgb:[1,3,5].map(i=>parseInt(h.slice(i,i+2),16))}); });
}
function toggleLamp(l){ if(l.nc) return; const v = !l.on; (l.ha ? lampList.filter(x=>x.ha===l.ha && !x.nc) : [l]).forEach(x=>x.on=v); applyLamps(); renderPanel();
  if(LIVE && ha && l.ha) ha.call('light', v?'turn_on':'turn_off', {entity_id:l.ha}).catch(()=>{}); }
function setPlug(p, on){ p.on = on; if(!LIVE) p.w = on ? p.base : 0; renderPanel(); updateLabels();
  if(LIVE && ha && p.sw) ha.call('switch', on?'turn_on':'turn_off', {entity_id:p.sw}).catch(()=>{}); }
// Eigen bevestigingsmelding (browser-confirm werkt niet overal). okLabel null = alleen melding.
function askConfirm(title, text, okLabel){ return new Promise(res=>{
  const m = $('confirm'); m.querySelector('h3').textContent = title; m.querySelector('p').textContent = text;
  const ok = m.querySelector('.ok'), no = m.querySelector('.no');
  ok.hidden = !okLabel; ok.textContent = okLabel || ''; no.textContent = okLabel ? 'Annuleren' : 'Sluiten';
  const done = v=>{ m.hidden = true; document.removeEventListener('keydown', key); res(v); };
  const key = e=>{ if(e.key==='Escape') done(false); };
  ok.onclick = ()=>done(true); no.onclick = ()=>done(false); m.onclick = e=>{ if(e.target===m) done(false); };
  document.addEventListener('keydown', key); m.hidden = false; no.focus();
}); }
function setRoomLamps(r,on){ const ids = new Set(); r.lampObjs.forEach(l=>{ if(!l.nc){ l.on=on; if(l.ha) ids.add(l.ha); } });
  lampList.forEach(l=>{ if(l.ha && ids.has(l.ha) && !l.nc) l.on=on; }); applyLamps(); renderPanel();
  if(LIVE && ha && ids.size) ha.call('light', on?'turn_on':'turn_off', {entity_id:[...ids]}).catch(()=>{}); }
function select(r){ selected = r; if(mode!==2 && r.floor!==mode){ mode=r.floor; applyMode(); } applyColors(); updateLabels(); renderPanel(); if(LIVE) loadHistory(r); }

