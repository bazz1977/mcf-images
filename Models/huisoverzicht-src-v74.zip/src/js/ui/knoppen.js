/* ---------- Knoppen ---------- */
document.querySelectorAll('.seg button').forEach(b=>b.onclick=()=>{ mode=+b.dataset.mode; applyMode(); });
function syncRotateBtn(){ $('rotate').setAttribute('aria-pressed', String(controls.autoRotate)); }
$('rotate').onclick = ()=>{ controls.autoRotate=!controls.autoRotate; syncRotateBtn(); };
function syncNightBtn(){ const b = $('night'); if(!b) return; b.setAttribute('aria-pressed', String(sky.mode==='auto')); b.textContent = sky.mode==='auto' ? '☼ Auto' + (sky.cur && sky.cur.elev!=null ? ' · zon ' + Math.round(sky.cur.elev) + '°' : '') : sky.mode==='day' ? '☀ Dag' : '☾ Avond'; }
$('night').onclick = ()=>{ sky.mode = {auto:'day', day:'night', night:'auto'}[sky.mode]; updateSky(true); };
$('simtime').oninput = e=>{ sky.simMin = +e.target.value; const h = Math.floor(sky.simMin/60), m = sky.simMin%60; $('simlbl').textContent = String(h).padStart(2,'0')+':'+String(m).padStart(2,'0'); if(sky.mode!=='auto') sky.mode = 'auto'; updateSky(); updateLabels(); renderPanel(); };
$('simlbl').title = 'Klik om terug te gaan naar nu'; $('simlbl').style.cursor = 'pointer';
$('simlbl').onclick = e=>{ e.preventDefault(); sky.simMin = null; updateSky(); updateLabels(); renderPanel(); };
$('cloud').oninput = e=>{ sky.cloud = +e.target.value/100; $('cloudlbl').textContent = e.target.value+'%'; updateSky(); };
setInterval(()=>updateSky(), 30000);
$('colormode').onchange = e=>{ colorMode=e.target.value; applyColors(); };
$('wallmode').onchange = e=>{ setWire(e.target.value==='wire'); try{ localStorage.setItem('huis-muren', e.target.value); }catch(_){} };
