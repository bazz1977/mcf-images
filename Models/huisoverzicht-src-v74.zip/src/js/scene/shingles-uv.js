// (v28) shingles: UV's in meters op alle bekledingsvlakken
{ const SH = new Set([brickMat, roofShingleMat]);
  [house, upper, roofGroup].forEach(g=>g.traverse(o=>{
    if(!o.isMesh || !o.geometry || o.geometry.type!=='BoxGeometry') return;
    const ms = Array.isArray(o.material) ? o.material : [o.material]; if(!ms.some(m=>SH.has(m))) return;
    boxUV(o, !!(o.rotation.x || o.rotation.y || o.rotation.z)); })); }
