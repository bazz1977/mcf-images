
// spiltrap 2 × 2 m
const stairMat = new THREE.MeshStandardMaterial({color:0x7a5a3e, roughness:.8});
const SC = [mx(STAIR.x), mz(STAIR.y)], STEPS = 15, STEP_ANG = (330/STEPS)*Math.PI/180;
for(let i=0;i<STEPS;i++){
  const geo = new THREE.CylinderGeometry(0.98,0.98,0.05,8,1,false, i*STEP_ANG, STEP_ANG*1.05);
  geo.translate(0,0.025,0);
  const st = new THREE.Mesh(geo, stairMat);
  st.position.set(SC[0], (i+1)*(F1/STEPS)-0.05, SC[1]);
  st.castShadow = true; st.receiveShadow = true; walls.add(st);
}
walls.add(box(0.1, F1+0.9, 0.1, frameMat, SC[0], 0, SC[1]));

const spotRing = new THREE.MeshStandardMaterial({color:0xd9dcdf, roughness:.35, metalness:.6});
// Wandobjecten (tv, airco, speaker, access point, wandlampen, stekkers) schuiven mee omlaag met de muren,
// maar worden niet platgedrukt: ze houden hun echte verhoudingen.
const wallMounts = [];
function wallMount(obj, h, g){ obj.position.y = h; g.parent.add(obj); wallMounts.push({obj, h, g}); return obj; }
const beamMat = new THREE.MeshBasicMaterial({color:0xffc46b, transparent:true, opacity:.07, depthWrite:false, side:THREE.DoubleSide, blending:THREE.AdditiveBlending});
// verdieping-groepen (worden hieronder gevuld)
const upper = new THREE.Group(); upper.position.y = F1; scene.add(upper);
const upWalls = new THREE.Group(); upper.add(upWalls);
let upScale = 1;

// vloerplaat met optioneel gat voor de spiltrap
function slabGeo(a,b,c,d,hole){
  const sh = new THREE.Shape();
  sh.moveTo(mx(a),-mz(b)); sh.lineTo(mx(c),-mz(b)); sh.lineTo(mx(c),-mz(d)); sh.lineTo(mx(a),-mz(d)); sh.lineTo(mx(a),-mz(b));
  if(hole){ const h = new THREE.Path(); h.absarc(mx(STAIR.x), -mz(STAIR.y), STAIR.r-0.02, 0, Math.PI*2, true); sh.holes.push(h); }
  const g = new THREE.ExtrudeGeometry(sh,{depth:0.15, bevelEnabled:false, curveSegments:32});
  g.rotateX(-Math.PI/2); g.translate(0,-0.15,0);
  return g;
}

// kamers: vloer + lampen
