// ===== VOORTUIN (v72, bijgewerkt v73 volgens Bas 27-09) =====
//  · alle paden en het nieuwe terras: stenen klinkers 15 × 15 cm
//  · natuursteen 100 × 100 cm: terras noord (langs de rechtergevel), terras woonkamer en het pad in het verlengde van de hal
//  · pad langs de gevel loopt door tot de buitenrand van het terras noord (x -3,2) en sluit aan op het pad van de voordeur
//  · (v74) tuinpad 1,5 m breed (1,5 m opgeschoven richting klimop) van de hoofdweg tot een dichte tweedelige houten poort (2,0 m);
//    links en rechts van de poort een dicht houten hek 2,0 m tot de klimop en tot het klinkerterras; naast het pad zwarte aarde
//  · (v74) terras noord 4 × 7 m (4 volle tegels van de gevel af), noordertuin = zwarte aarde met struiken, 2 paaltjes met de terraslampen
//  · rondom het terras een border van 50 cm met verschillende bloemen; doorgang naar het pad langs de gevel (x 1,6–2,9)
//  · minizuivering en regenwaterput (±5 m³) liggen onder het terras: alleen de vierkante deksels zijn zichtbaar
//  · terras noord: 4 grote bloembakken (±80 × 80) op 10 cm van de achterrand (west)
const VOORTUIN = {
  padHuis:  {x0:TR_X0, x1:5.385, y0:-2.75, y1:-0.15},
  tuinpad:  {x0:TUINPAD.x0, x1:TUINPAD.x1, y0:-9.3, y1:TUINPAD.y1},
  terras:   {x0:0.0, x1:4.75, y0:-8.5, y1:-3.25},
  doorgang: {x0:1.6, x1:2.9, y0:-3.25, y1:-2.75},
  borders:  [{x0:-0.45, x1:0.0, y0:-9.0, y1:-2.75},                                   // kant tuinpad (tegen het hek)
             {x0:0.0, x1:1.6, y0:-3.25, y1:-2.75}, {x0:2.9, x1:5.25, y0:-3.25, y1:-2.75},   // kant pad langs de gevel, met doorgang
             {x0:4.75, x1:5.25, y0:-9.0, y1:-3.25},                                   // kant pad van de voordeur
             {x0:0.0, x1:4.75, y0:-9.0, y1:-8.5}],                                    // kant voorhek
};
const PUTTEN = {
  zuivering:{x:2.05, y:-4.8,  lid:0.6, name:'Minizuivering'},
  regen:    {x:3.95, y:-6.25, lid:0.6, name:'Regenwaterput'},
};
const BAKKEN = {n:4, w:0.80, d:0.80, h:0.60, rand:0.10};   // (v74) terras noord 4 m breed: 4 bakken van 80 × 80
// ===== REGENWATER — makkelijk aan te passen =====
//  plug  = naam van de stekker in PLUGS (hal kelder); de pomp draait zodra die meer dan minW watt trekt
//  wcs   = wc's met een inbouwreservoir (Geberit) op regenwater. (v73) toilet kelder is nog in aanbouw → later 'k-toilet' toevoegen (backlog)
//  WC_POS = plek van het hangtoilet: beide wc's hangen op de muur naar het zuiden (x 5,3, kant hal), gezicht naar x−
//  fillS = seconden om een reservoir te vullen (animatie), maxS = melding als de pomp langer draait
const REGEN = {plug:'Regenwaterpomp (regenput)', minW:20, fillS:22, maxS:45, wcs:['wc'],
  pump:[5.6, 0.45], level:{}, res:{}, run:false, since:0, lastRun:null, demoUntil:0, demoFirst:null, branches:[]};
const WC_POS = {wc:{x:5.25, y:0.6}, 'k-toilet':{x:5.25, y:0.6}};
// ==========================================================================
function makePaverTex(){
  const S = 512, c = document.createElement('canvas'); c.width = S; c.height = S; const g = c.getContext('2d');
  let sd = 7; const rn = ()=>{ sd = (sd*16807) % 2147483647; return sd/2147483647; };
  const tones = ['#9d9992','#a6a29b','#95918a','#aba79f','#8e8a83','#a09c95'];
  g.fillStyle = '#5c5852'; g.fillRect(0,0,S,S);
  const n = 6, w = S/n, J = 4;                                                   // 6 × 15 cm = 0,90 m per tegel
  for(let i=0;i<n;i++) for(let k=0;k<n;k++){ const x = i*w, y = k*w;
    g.fillStyle = tones[Math.floor(rn()*tones.length)]; g.fillRect(x+J/2, y+J/2, w-J, w-J);
    g.fillStyle = 'rgba(255,255,255,.05)'; g.fillRect(x+J/2, y+J/2, w-J, 3); g.fillStyle = 'rgba(0,0,0,.08)'; g.fillRect(x+J/2, y+w-J/2-3, w-J, 3); }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = renderer.capabilities.getMaxAnisotropy();
  t.repeat.set(1/0.9, 1/0.9); return t;
}
function makeStoneTex(){                                                           // natuursteen 100 × 100 cm: textuur = 2 × 2 tegels (2 m)
  const S = 512, c = document.createElement('canvas'); c.width = S; c.height = S; const g = c.getContext('2d');
  let sd = 19; const rn = ()=>{ sd = (sd*16807) % 2147483647; return sd/2147483647; };
  const tones = ['#b3ada2','#aba59a','#bab4a9','#a7a196'];
  g.fillStyle = '#6f6a62'; g.fillRect(0,0,S,S);
  const w = S/2, J = 3;
  for(let i=0;i<2;i++) for(let k=0;k<2;k++){ const x = i*w, y = k*w; g.fillStyle = tones[i*2+k]; g.fillRect(x+J/2, y+J/2, w-J, w-J);
    for(let q=0;q<900;q++){ g.fillStyle = rn()<.5 ? 'rgba(0,0,0,.05)' : 'rgba(255,255,255,.05)'; g.fillRect(x+2+rn()*(w-4), y+2+rn()*(w-4), 1+rn()*3, 1+rn()*3); } }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = renderer.capabilities.getMaxAnisotropy();
  t.repeat.set(0.5, 0.5); return t;
}
{
  // (v73) natuursteen op terras noord, terras woonkamer en het pad van de voordeur (zelfde materiaal, UV's in meters)
  stoneMat.map = makeStoneTex(); stoneMat.color.set(0xffffff); stoneMat.roughness = .85; stoneMat.needsUpdate = true;
  // tegels van 1 m vanaf een vast beginpunt (plan-x, plan-y): woonkamerterras vanaf de voordeur (ingekorte tegels aan de zuidkant),
  // pad voordeur precies onder de deur, terras noord vanaf de gevel (4 volle tegels)
  const planUV = (m, ox, oy)=>{ boxUV(m); const p = m.geometry.attributes.position, n = m.geometry.attributes.normal, uv = m.geometry.attributes.uv;
    for(let i=0;i<p.count;i++) if(Math.abs(n.getY(i)) > 0.9) uv.setXY(i, p.getX(i)+m.position.x - mx(ox), p.getZ(i)+m.position.z - mz(oy)); uv.needsUpdate = true; };
  planUV(terrace, HAL_DOOR.xc+HAL_DOOR.w/2, 0); planUV(path, HAL_DOOR.xc-HAL_DOOR.w/2, 0);
  sideTerrace.children.filter(o=>o.material===stoneMat).forEach(m=>planUV(m, -0.15, -0.15));
  const klinker = new THREE.MeshStandardMaterial({color:0xffffff, map:makePaverTex(), roughness:.95});
  const pave = a=>{ const m = box(a.x1-a.x0, 0.06, a.y1-a.y0, klinker, mx((a.x0+a.x1)/2), -0.18, mz((a.y0+a.y1)/2));   // bovenkant -0,12 = gelijk met het natuursteen
    m.castShadow = false; m.receiveShadow = true; boxUV(m); scene.add(m); garden.push(m); };
  ['padHuis','tuinpad','terras','doorgang'].forEach(k=>pave(VOORTUIN[k]));
  // borders van 50 cm met verschillende bloemen
  const soil = new THREE.MeshStandardMaterial({color:0x3a2d22, roughness:1});
  const leaf = [0x2f5b33,0x3b6a35,0x4c7a3a,0x2a4f2c,0x5a7d45].map(c=>new THREE.MeshStandardMaterial({color:c, roughness:1, flatShading:true}));
  const bloom = [0x9b6fd6,0xd98cb3,0xf2ede0,0xe8b845,0xc9503f,0x7f9fe0,0xf08a3c,0xe04f8a,0xffffff].map(c=>new THREE.MeshStandardMaterial({color:c, roughness:.8, flatShading:true}));
  let sd = 31; const rn = ()=>{ sd = (sd*16807) % 2147483647; return sd/2147483647; };
  const flowers = (x, y, base, spread)=>{ const r = 0.07+rn()*0.1, hgt = 0.6+rn()*1.0, add = m=>{ scene.add(m); garden.push(m); };
    const p = new THREE.Mesh(new THREE.IcosahedronGeometry(r,0), leaf[Math.floor(rn()*leaf.length)]); p.scale.y = hgt; p.position.set(mx(x), base+r*hgt*0.8, mz(y)); p.castShadow = true; add(p);
    const col = bloom[Math.floor(rn()*bloom.length)], nb = 1 + Math.floor(rn()*3);
    for(let k=0;k<nb;k++){ const f = new THREE.Mesh(new THREE.IcosahedronGeometry(0.03+rn()*0.03,0), col); f.position.set(mx(x)+(rn()-.5)*r*1.4, base+r*hgt*(1.3+rn()*0.5), mz(y)+(rn()-.5)*r*1.4); add(f); } };
  VOORTUIN.borders.forEach(b=>{
    const w = b.x1-b.x0, d = b.y1-b.y0, s = box(w, 0.07, d, soil, mx((b.x0+b.x1)/2), -0.2, mz((b.y0+b.y1)/2)); s.castShadow = false; s.receiveShadow = true; scene.add(s); garden.push(s);
    const n = Math.round(w*d/0.035);
    for(let k=0;k<n;k++) flowers(b.x0+0.05+rn()*(w-0.1), b.y0+0.05+rn()*(d-0.1), -0.13);
  });
  // (v74) dichte tweedelige houten poort (2,0 m) over het tuinpad, links en rechts een dicht houten hek van 2,0 m tot de klimop en tot het klinkerterras
  { const Y = TUINPAD.y1, H = 2.0, B = -0.2, add = m=>{ scene.add(m); garden.push(m); };
    const woods = [0x8a6446,0x81593d,0x93704f,0x7c5639].map(c=>new THREE.MeshStandardMaterial({color:c, roughness:.85})), postM = new THREE.MeshStandardMaterial({color:0x6e4d33, roughness:.9});
    let wsd = 5; const wr = ()=>{ wsd = (wsd*16807) % 2147483647; return wsd/2147483647; };
    const boards = (x0, x1, h, dz=0)=>{ const bw = 0.14, n = Math.max(1, Math.round((x1-x0)/bw)), st = (x1-x0)/n;
      for(let k=0;k<n;k++) add(box(st-0.01, h, 0.025, woods[Math.floor(wr()*woods.length)], mx(x0+st*(k+0.5)), B+0.04, mz(Y)+dz)); };
    const post = x=> add(box(0.1, H+0.08, 0.1, postM, mx(x), B-0.05, mz(Y)));
    // poort: twee vleugels, planken + regels aan de binnenkant + klink
    const W2 = (TUINPAD.x1-TUINPAD.x0)/2;
    [TUINPAD.x0-0.05, TUINPAD.x1+0.05].forEach(post);
    [0,1].forEach(i=>{ const x0 = TUINPAD.x0+i*W2+0.01, x1 = x0+W2-0.02, cx = (x0+x1)/2;
      boards(x0, x1, H-0.08);
      [0.25, H-0.35].forEach(h=>add(box(x1-x0-0.04, 0.1, 0.025, postM, mx(cx), B+h, mz(Y)+0.025)));
      add(box(0.03, 0.03, 0.12, new THREE.MeshStandardMaterial({color:0x2b2f33, metalness:.5, roughness:.4}), mx(i ? x0+0.08 : x1-0.08), B+1.05, mz(Y))); });
    // hek links en rechts van de poort: dichte planken, palen om de ±1,8 m
    [[HEDGE_X+0.2, TUINPAD.x0-0.1], [TUINPAD.x1+0.1, TERRAS_HEK_X]].forEach(([a,b])=>{ boards(a, b, H-0.06);
      const n = Math.max(1, Math.round((b-a)/1.8)); for(let k=0;k<=n;k++) post(a + (b-a)*k/n);
      add(box(b-a, 0.04, 0.12, postM, mx((a+b)/2), B+H-0.02, mz(Y))); });
  }
  // (v74) zwarte aarde met wat struiken: noordertuin (naast terras noord) en links/rechts van het tuinpad
  { const aarde = new THREE.MeshStandardMaterial({color:0x221a14, roughness:1}), shrubM = [0x24452a,0x2d5530,0x355f34,0x1f3d25].map(c=>new THREE.MeshStandardMaterial({color:c, roughness:1, flatShading:true}));
    const ZONES = [{x0:HEDGE_X+0.18, x1:TR_X0, y0:TUINPAD.y1, y1:STAIR_Y0-0.15, n:6}, {x0:HEDGE_X+0.18, x1:TUINPAD.x0, y0:PLOT.y0, y1:TUINPAD.y1, n:5}, {x0:TUINPAD.x1, x1:TERRAS_HEK_X, y0:PLOT.y0, y1:TUINPAD.y1, n:3}];
    let ss = 77; const r2 = ()=>{ ss = (ss*16807) % 2147483647; return ss/2147483647; };
    ZONES.forEach(z=>{ const m = box(z.x1-z.x0, 0.03, z.y1-z.y0, aarde, mx((z.x0+z.x1)/2), -0.215, mz((z.y0+z.y1)/2)); m.castShadow = false; m.receiveShadow = true; scene.add(m); garden.push(m);
      for(let k=0;k<z.n;k++){ const x = z.x0+0.4+r2()*Math.max(0.01, z.x1-z.x0-0.8), y = z.y0+0.5+(k+r2()*0.6)*(z.y1-z.y0-1)/z.n;
        for(let q=0;q<3;q++){ const r = 0.22+r2()*0.22, b = new THREE.Mesh(new THREE.IcosahedronGeometry(r,1), shrubM[Math.floor(r2()*shrubM.length)]); b.scale.y = 0.8+r2()*0.4;
          b.position.set(mx(x+(r2()-.5)*0.4), -0.18+r*0.8+q*0.12, mz(y+(r2()-.5)*0.4)); b.castShadow = true; scene.add(b); garden.push(b); } } });
    // twee paaltjes voor de terraslampen (de lampen zelf zitten in de ruimte 'Tuin & terras')
    const pm = new THREE.MeshStandardMaterial({color:0x2b2f33, roughness:.5, metalness:.4});
    [1.2, 4.6].forEach(y=>{ const p = box(0.07, 0.84, 0.07, pm, mx(-4.62), -0.2, mz(y)); scene.add(p); garden.push(p); });
  }
  // (v74) organisch pad van aarde en steentjes langs de straatzijde (oost), van het pad van de voordeur tot 3 m voor het linkerhek
  { const S = 256, c = document.createElement('canvas'); c.width = c.height = S; const g = c.getContext('2d'); let ps = 3; const pr = ()=>{ ps = (ps*16807) % 2147483647; return ps/2147483647; };
    g.fillStyle = '#6b5a45'; g.fillRect(0,0,S,S);
    for(let k=0;k<1400;k++){ const x = pr()*S, y = pr()*S, r = 1+pr()*3.2; g.fillStyle = ['#b9b1a3','#9d958a','#c9c2b6','#857d72','#a89880'][Math.floor(pr()*5)]; g.beginPath(); g.ellipse(x, y, r, r*(0.6+pr()*0.4), pr()*3, 0, Math.PI*2); g.fill(); }
    const tex = new THREE.CanvasTexture(c); tex.wrapS = tex.wrapT = THREE.RepeatWrapping; tex.colorSpace = THREE.SRGBColorSpace; tex.repeat.set(1/1.2, 1/1.2);
    const X0 = HAL_DOOR.x1-0.05, X1 = PLOT.x1-3.0, pos = [], uv = [], idx = [];
    const yc = x=> -6.75 + 0.42*Math.sin(x*0.29+0.4) + 0.18*Math.sin(x*0.83+1.0), hw = x=>{ const t = Math.min(1, (x-X0)/1.2, (X1-x)/1.5); return (0.55 + 0.14*Math.sin(x*0.57+1.1)) * Math.max(0.15, t); };
    let n = 0; for(let x=X0; x<=X1+1e-6; x+=0.25, n++){ [-1,1].forEach(sd=>{ const y = yc(x)+sd*hw(x), X = mx(x), Z = mz(y); pos.push(X, gradeAt(X,Z)+0.025, Z); uv.push(x, y); }); }
    for(let i=0;i<n-1;i++){ const a = i*2; idx.push(a, a+1, a+2, a+1, a+3, a+2); }
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pos,3)); geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv,2)); geo.setIndex(idx); geo.computeVertexNormals();
    if(geo.attributes.normal.getY(0) < 0){ idx.reverse(); geo.setIndex(idx); geo.computeVertexNormals(); }
    const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({color:0xffffff, map:tex, roughness:1})); m.receiveShadow = true; scene.add(m); garden.push(m);
  }
  // (v73) terras noord: 4 grote bloembakken op 10 cm van de achterrand (west), gelijk verdeeld over de breedte
  { const B = BAKKEN, x0 = TR_X0, x1 = -0.15, gap = ((x1-x0) - B.n*B.w)/(B.n+1), yc = D_M+0.15 - B.rand - B.d/2, top = -0.12;
    const bakM = new THREE.MeshStandardMaterial({color:0x3a3d41, roughness:.7, metalness:.2}), aarde = new THREE.MeshStandardMaterial({color:0x33271d, roughness:1});
    for(let i=0;i<B.n;i++){ const xc = x0 + gap + B.w/2 + i*(B.w+gap);
      const bak = box(B.w, B.h, B.d, bakM, mx(xc), top, mz(yc)); bak.castShadow = true; bak.receiveShadow = true; sideTerrace.add(bak);
      const a = box(B.w-0.06, 0.02, B.d-0.06, aarde, mx(xc), top+B.h-0.05, mz(yc)); sideTerrace.add(a);
      const g = new THREE.Group(); const base = top+B.h-0.03;
      for(let k=0;k<14;k++){ const x = xc+(rn()-.5)*(B.w-0.16), y = yc+(rn()-.5)*(B.d-0.16), r = 0.08+rn()*0.1, hgt = 0.8+rn()*1.2;
        const p = new THREE.Mesh(new THREE.IcosahedronGeometry(r,0), leaf[Math.floor(rn()*leaf.length)]); p.scale.y = hgt; p.position.set(mx(x), base+r*hgt*0.8, mz(y)); p.castShadow = true; g.add(p);
        const col = bloom[Math.floor(rn()*bloom.length)]; for(let q=0;q<2;q++){ const f = new THREE.Mesh(new THREE.IcosahedronGeometry(0.035+rn()*0.03,0), col); f.position.set(mx(x)+(rn()-.5)*r*1.4, base+r*hgt*(1.3+rn()*0.5), mz(y)+(rn()-.5)*r*1.4); g.add(f); } }
      sideTerrace.add(g); }
  }
}
// ---------- de putten liggen onder het terras: alleen de vierkante deksels zijn zichtbaar ----------
const putGroup = new THREE.Group(); scene.add(putGroup);
{
  const frameM = new THREE.MeshStandardMaterial({color:0x8d8a84, roughness:.8, metalness:.2});
  Object.entries(PUTTEN).forEach(([k,P])=>{
    const X = mx(P.x), Z = mz(P.y), L = P.lid;
    const frame = box(L+0.08, 0.02, L+0.08, frameM, X, -0.125, Z); frame.receiveShadow = true; frame.castShadow = false;   // rand van het deksel
    const cover = box(L-0.02, 0.022, L-0.02, new THREE.MeshStandardMaterial({color:k==='regen' ? 0x565c62 : 0x6a655d, roughness:.7, metalness:.3}), X, -0.124, Z); cover.castShadow = false;
    const grip = [-0.16,0.16].map(o=>{ const m = new THREE.Mesh(new THREE.BoxGeometry(0.1,0.006,0.025), new THREE.MeshStandardMaterial({color:0x222})); m.position.set(X+o, -0.1, Z); return m; });
    putGroup.add(frame, cover, ...grip);
    const hit = new THREE.Mesh(new THREE.BoxGeometry(L+0.2, 0.4, L+0.2), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(X, 0.05, Z); hit.userData.room = byId.buiten; putGroup.add(hit); pickables.push(hit);
    P.lblPos = V(P.x, 0.95, P.y);
  });
}
// ---------- leidingen: regenwater (put → pomp in de hal kelder → wc-reservoir) en beluchting minizuivering ----------
function regenPipe(curve, color, op, n){
  const tm = new THREE.MeshBasicMaterial({color, transparent:true, opacity:op, depthTest:false, depthWrite:false});
  const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 220, .028, 8, false), tm); tube.renderOrder = 5; scene.add(tube);
  const dm = new THREE.MeshBasicMaterial({color:0x7cc4ff, depthTest:false, transparent:true});
  const dots = Array.from({length:n}, ()=>{ const d = new THREE.Mesh(new THREE.SphereGeometry(.05,10,8), dm); d.renderOrder = 7; d.visible = false; scene.add(d); return d; });
  return {curve, len:curve.getLength(), tube, tm, dots, t:0};
}
{
  const R = PUTTEN.regen, Zp = PUTTEN.zuivering, [px, py] = REGEN.pump, KH = -0.6, SUP = -0.55;
  // aanzuig onderin de put (±1,7 m diep) → vorstvrij onder het pad van de voordeur → door de voorgevel de hal kelder in → pomp bij het stopcontact
  REGEN.main = regenPipe(ortho([V(R.x,-1.7,R.y), V(R.x,KH,R.y), V(5.66,KH,R.y), V(5.66,KH,py), V(5.66,Y_K+0.26,py)]), 0x3f8fd6, .28, 16);
  // pomp → langs het kelderplafond → omhoog in de muur x 5,3 (zuidmuur wc) → inbouwreservoir
  REGEN.wcs.forEach(id=>{ const r = byId[id], w = WC_POS[id]; if(!r || !w) return; const h = (r.floor===-1 ? Y_K : 0) + 0.84, xw = w.x - 0.03;
    REGEN.branches.push(regenPipe(ortho([V(px-0.06,Y_K+0.26,py), V(px-0.06,SUP,py), V(xw,SUP,py), V(xw,SUP,w.y), V(xw,h,w.y)]), 0x3f8fd6, .28, 8)); });
  // beluchting minizuivering: nog niet aangesloten (backlog) — leiding ligt er, eindigt open in de hal kelder
  REGEN.lucht = regenPipe(ortho([V(Zp.x,-1.72,Zp.y), V(Zp.x,-0.5,Zp.y), V(5.42,-0.5,Zp.y), V(5.42,-0.5,0.3)]), 0xa7b0b8, .5, 0);
  // pomp (op de keldervloer, naast het stopcontact van de regenput)
  const g = new THREE.Group(), body = new THREE.Mesh(new THREE.BoxGeometry(0.22,0.24,0.32), new THREE.MeshStandardMaterial({color:0x2f6fa8, roughness:.45, metalness:.3}));
  body.position.y = 0.12; body.castShadow = true;
  const motor = new THREE.Mesh(new THREE.CylinderGeometry(0.075,0.075,0.2,20), new THREE.MeshStandardMaterial({color:0x3a3f45, roughness:.5, metalness:.5})); motor.rotation.x = Math.PI/2; motor.position.set(0, 0.13, 0.25);
  REGEN.pumpLed = new THREE.MeshStandardMaterial({color:0x111, emissive:0x3fa7ff, emissiveIntensity:0.25});
  const led = new THREE.Mesh(new THREE.SphereGeometry(0.014,8,8), REGEN.pumpLed); led.position.set(0.112, 0.2, 0);
  g.add(body, motor, led); g.position.set(mx(px), 0, mz(py)); cellar.add(g);
  const hit = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.5,0.6), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(mx(px), 0.25, mz(py)); hit.userData.room = byId['k-hal']; cellar.add(hit); pickables.push(hit);
  // hangtoilet + inbouwreservoir (Geberit, doorsnede: je ziet het water stijgen) op de zuidmuur; lokaal: +z = de ruimte in
  const ceramic = new THREE.MeshStandardMaterial({color:0xf6f6f3, roughness:.25});
  REGEN.wcs.forEach(id=>{ const r = byId[id], w = WC_POS[id]; if(!r || !w) return; const parent = r.floor===-1 ? cellar : house, t = new THREE.Group();
    const shell = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.36, 0.1), new THREE.MeshStandardMaterial({color:0xe9ecef, transparent:true, opacity:.35, depthWrite:false})); shell.position.set(0, 0.18, 0);
    const wm = new THREE.MeshStandardMaterial({color:0x3f9be0, emissive:0x1d5c96, emissiveIntensity:.3, transparent:true, opacity:.7, depthWrite:false});
    const water = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.32, 0.08), wm); water.geometry.translate(0, 0.16, 0); water.position.set(0, 0.02, 0); water.renderOrder = 3;
    const res = new THREE.Group(); res.add(shell, water); res.position.set(0, 0.82, 0.06); t.add(res);
    const plate = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.16, 0.012), new THREE.MeshStandardMaterial({color:0xdadde0, roughness:.3, metalness:.4})); plate.position.set(0, 1.0, 0.13); t.add(plate);
    const bowl = new THREE.Mesh(new THREE.SphereGeometry(1, 22, 14), ceramic); bowl.scale.set(0.18, 0.16, 0.27); bowl.position.set(0, 0.33, 0.37); bowl.castShadow = true;
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.025, 0.46), ceramic); seat.position.set(0, 0.42, 0.37);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.2, 0.08), ceramic); back.position.set(0, 0.36, 0.13);
    t.add(bowl, seat, back); t.rotation.y = -Math.PI/2; t.position.set(mx(w.x), 0, mz(w.y)); parent.add(t);   // gezicht naar x−
    REGEN.res[id] = {water, wm}; REGEN.level[id] = 1; });
  REGEN.lbl = document.createElement('div'); REGEN.lbl.className = 'label elabel'; REGEN.lbl.onclick = ()=>select(byId.buiten); labelsEl.appendChild(REGEN.lbl);
  REGEN.lblZ = document.createElement('div'); REGEN.lblZ.className = 'label elabel'; REGEN.lblZ.innerHTML = '<b>Minizuivering · 5 m³</b><span>beluchting nog niet aangesloten</span>'; REGEN.lblZ.onclick = ()=>select(byId.buiten); labelsEl.appendChild(REGEN.lblZ);
}
const TUINLBL = (()=>{ const el = document.createElement('div'); el.className = 'label gevel'; el.textContent = 'Noordertuin'; labelsEl.appendChild(el); return {el, pos:V(HEDGE_X+0.7, 0.25, 1.9)}; })();   // (v74)
function regenPlug(){ const r = byId['k-hal']; return r ? r.plugs.find(p=>p.name===REGEN.plug) : null; }
function regenState(){ const p = regenPlug(), w = p && p.on ? (p.w||0) : 0; return {p, w, run:REGEN.run, s: REGEN.run ? Math.round((Date.now()-REGEN.since)/1000) : null}; }
function regenTick(now, dt){
  if(!REGEN.main) return;
  const st = regenState(), run = st.w > REGEN.minW, vis = !!W.regen;
  if(run && !REGEN.run){ REGEN.since = Date.now(); REGEN.wcs.forEach(id=>REGEN.level[id] = 0.12); }   // doorgespoeld: reservoir bijna leeg
  if(!run && REGEN.run) REGEN.lastRun = {at:Date.now(), s:(Date.now()-REGEN.since)/1000};
  REGEN.run = run;
  REGEN.wcs.forEach(id=>{ const o = REGEN.res[id]; if(!o) return; let L = REGEN.level[id] ?? 1;
    L = run ? Math.min(1, L + dt/REGEN.fillS) : L + (1-L)*Math.min(1, dt*1.5); REGEN.level[id] = L;
    o.water.scale.y = Math.max(0.03, L); o.wm.emissiveIntensity = run ? 0.5 + 0.25*Math.sin(now/200) : 0.3; });
  [REGEN.main, ...REGEN.branches].forEach(f=>{ f.tube.visible = vis; f.tm.opacity = run ? .6 : .28;
    if(run && vis){ f.t = (f.t + dt*1.6/f.len) % 1; f.dots.forEach((d,i)=>{ d.visible = true; d.position.copy(f.curve.getPointAt((f.t + i/f.dots.length) % 1)); }); }
    else f.dots.forEach(d=>d.visible = false); });
  if(REGEN.lucht) REGEN.lucht.tube.visible = !!W.lucht;
  if(REGEN.pumpLed) REGEN.pumpLed.emissiveIntensity = run ? 1.3 + 0.7*Math.sin(now/110) : 0.25;
}
function regenText(){ const st = regenState();
  return `<b>Regenwaterput · 5 m³</b><span class="t">${!st.p ? 'geen pomp gevonden' : !st.p.on ? 'pomp uit (stekker)' : st.run ? 'pompt '+st.s+' s · '+fmtW(st.w) : 'pomp in rust'}</span>${st.run ? ' <span>· wc vult</span>' : ''}`; }
function regenLabels(){
  if(!REGEN.lbl) return;
  const on = flowSel.labels && lbl.all, t = regenText();
  if(t!==REGEN.lblTxt){ REGEN.lbl.innerHTML = t; REGEN.lblTxt = t; }
  placeLabel(REGEN.lbl, PUTTEN.regen.lblPos, on && !!W.regen);
  placeLabel(REGEN.lblZ, PUTTEN.zuivering.lblPos, on && !!W.lucht);
  placeLabel(TUINLBL.el, TUINLBL.pos, lbl.all && lbl.gevels!==false && mode!==-1);
}
function regenHTML(r){
  if(!['buiten','k-hal','wc','k-toilet'].includes(r.id)) return '';
  if(r.id==='k-toilet') return '<div class="sub" style="margin-top:8px">Toilet in aanbouw · nog niet aangesloten op het regenwater.</div>';
  const st = regenState(); if(!st.p) return '';
  const wcN = REGEN.wcs.map(id=>byId[id] && byId[id].name).filter(Boolean).join(' + ');
  const last = REGEN.lastRun ? ` Laatst: ${new Date(REGEN.lastRun.at).toLocaleTimeString('nl-BE',{hour:'2-digit',minute:'2-digit'})} (${Math.round(REGEN.lastRun.s)} s).` : '';
  return `<div class="setpoint"><span>Regenwater → ${wcN}</span><div class="ctl"><b style="color:${st.run ? 'var(--hum)' : 'var(--muted)'}">${!st.p.on ? 'stekker uit' : st.run ? 'pompt '+st.s+' s · '+fmtW(st.w) : 'rust'}</b></div></div>
    <div class="sub" style="margin-top:4px">De pomp draait zodra de stekker stroom trekt (&gt; ${REGEN.minW} W): er is doorgespoeld en het inbouwreservoir vult (normaal &lt; 30 s).${last} Niveau in de put: geen sensor.</div>`;
}
function regenAlerts(add){ if(!REGEN.run) return; const s = (Date.now()-REGEN.since)/1000;
  if(s > REGEN.maxS) add('warn','regenlang-'+REGEN.since, `<b>Regenwaterpomp</b> draait al ${Math.round(s)} s (normaal &lt; 30 s). Lekt het reservoir, of is de put leeg?`); }
// demo: af en toe wordt er doorgespoeld (eerste keer na ±6 s), de pomp trekt dan ±450 W gedurende 18–27 s
function regenDemo(){ const p = regenPlug(); if(!p) return; if(!p.on){ p.w = 0; return; }
  const t = Date.now(); if(REGEN.demoFirst==null) REGEN.demoFirst = t + 6000;
  if(REGEN.demoFirst && t > REGEN.demoFirst){ REGEN.demoFirst = 0; REGEN.demoUntil = t + 24000; }
  if(t < REGEN.demoUntil) p.w = 430 + Math.round(Math.random()*60);
  else { p.w = 0; if(Math.random() < 0.03) REGEN.demoUntil = t + 18000 + Math.random()*9000; } }
