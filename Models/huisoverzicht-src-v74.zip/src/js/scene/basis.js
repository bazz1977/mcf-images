/* ---------- Scène ---------- */
const canvas = document.getElementById('c');
const stage = document.getElementById('stage');
const renderer = new THREE.WebGLRenderer({canvas, antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
// (v65) Details-menu: onthouden in de browser
const DET = {bomen:true, tuin:true, grond:'alles', schaduw:true, wolken:true, scherp:true, zuinig:false};
try{ Object.assign(DET, JSON.parse(localStorage.getItem('huis-details-v1')||'{}')); }catch(_){}
if(DET.grond===true) DET.grond = 'alles'; else if(DET.grond===false) DET.grond = 'uit';
if(!DET.scherp) renderer.setPixelRatio(1);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.outputColorSpace = THREE.SRGBColorSpace;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 200);
const HOME_POS = new THREE.Vector3(10, 11, 12.5);
camera.position.copy(HOME_POS);

const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;
controls.dampingFactor = 0.07;
controls.autoRotate = true;
controls.autoRotateSpeed = 0.7;
controls.maxPolarAngle = 1.42;
controls.minDistance = 5;
controls.maxDistance = 75;   // (v34) heel het perceel in beeld
controls.target.set(0,0.6,0);

const hemi = new THREE.HemisphereLight(0xcfe3ff, 0x3a3326, 1);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffffff, 2);
sun.position.set(10,18,7);
sun.castShadow = true;
sun.shadow.mapSize.set(2048,2048);
Object.assign(sun.shadow.camera,{left:-14,right:14,top:14,bottom:-14,near:1,far:110});   // (v38) zon staat op 45 m afstand
sun.shadow.bias = -0.0005;
sun.shadow.autoUpdate = false; sun.shadow.needsUpdate = true;
scene.add(sun);

