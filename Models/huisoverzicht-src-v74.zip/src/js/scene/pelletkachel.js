// (v33) Pelletkachel RED Primula 9 kW in de woonkamer, voor de middelste paal, ruit naar de kamer
{
  const r = byId.woon, g = new THREE.Group(), S = STOVE;
  const body = new THREE.Mesh(new THREE.BoxGeometry(S.d, S.h, S.w), new THREE.MeshStandardMaterial({color:0x2b2c2f, roughness:.55, metalness:.35}));
  body.position.y = S.h/2; body.castShadow = true; body.receiveShadow = true;
  const top = new THREE.Mesh(new THREE.BoxGeometry(S.d+0.02, 0.03, S.w+0.02), new THREE.MeshStandardMaterial({color:0x1b1c1e, roughness:.4, metalness:.5})); top.position.y = S.h+0.015;
  const door = new THREE.Mesh(new THREE.BoxGeometry(0.02, S.gh+0.12, S.gw+0.12), new THREE.MeshStandardMaterial({color:0x151618, roughness:.4, metalness:.6})); door.position.set(-S.d/2-0.01, S.h/2, 0);
  STOVE.glassMat = new THREE.MeshStandardMaterial({color:0x0a0a0a, emissive:0xff7a1a, emissiveIntensity:0, roughness:.1});
  const glass = new THREE.Mesh(new THREE.PlaneGeometry(S.gw, S.gh), STOVE.glassMat); glass.rotation.y = -Math.PI/2; glass.position.set(-S.d/2-0.021, S.h/2, 0);
  // vlammetjes achter de ruit
  const flameMat = new THREE.MeshBasicMaterial({color:0xffa53a, transparent:true, opacity:.9, depthWrite:false, blending:THREE.AdditiveBlending});
  STOVE.flames = [-0.08,0,0.08].map((z,i)=>{ const f = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.18, 12), flameMat.clone()); f.position.set(-S.d/2+0.06, S.h/2-S.gh/2+0.11, z); f.userData.ph = i*2.1; f.visible = false; g.add(f); return f; });
  const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.06,0.06,H_WOON-S.h,16), new THREE.MeshStandardMaterial({color:0x222326, roughness:.5, metalness:.5}));
  pipe.geometry.translate(0,(H_WOON-S.h)/2,0); pipe.position.set(0.1, S.h, 0);
  STOVE.light = new THREE.PointLight(0xff8a3d, 0, 5, 1.8); STOVE.light.position.set(-S.d/2-0.3, S.h/2, 0);
  g.add(body, top, door, glass, pipe, STOVE.light); STOVE.pipe = pipe;
  g.position.set(mx(S.x), 0, mz(S.y)); house.add(g);   // niet in 'walls': de kachel zakt niet mee, alleen de rookpijp verdwijnt als de muren laag staan
  const hit = new THREE.Mesh(new THREE.BoxGeometry(S.d+0.1, S.h, S.w+0.1), new THREE.MeshBasicMaterial({visible:false})); hit.position.set(mx(S.x), S.h/2, mz(S.y)); hit.userData.room = r; house.add(hit); pickables.push(hit);
}
// (v56) kachelstand uit het stroomverbruik: < 15 W uit/stand-by · 15–250 W brandt (ventilatoren + pelletvijzel) · > 250 W aansteken (gloeiweerstand)
const STOVE_W = {on:15, ignite:250};
const stoveW = ()=>{ const p = byId.woon.plugs.find(p=>p.name==='Pelletkachel'); return p && p.on ? (p.w||0) : 0; };
const stoveMode = ()=>{ const w = stoveW(); return w > STOVE_W.ignite ? 'aansteken' : w > STOVE_W.on ? 'brandt' : 'uit'; };
const stoveOn = ()=> stoveMode()!=='uit';
