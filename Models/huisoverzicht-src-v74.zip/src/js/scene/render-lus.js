/* ---------- Render-lus ---------- */
function resize(){
  const w = stage.clientWidth, h = stage.clientHeight;
  renderer.setSize(w,h,false); camera.aspect = w/h; camera.updateProjectionMatrix();
}
new ResizeObserver(resize).observe(stage);
resize();
if(matchMedia('(prefers-reduced-motion: reduce)').matches){ controls.autoRotate=false; syncRotateBtn(); }

// (v38) wolken: drijven langzaam over, dekking volgt de bewolking
const clouds = new THREE.Group(); scene.add(clouds);
{ const cm = new THREE.MeshStandardMaterial({color:0xf4f6f8, roughness:1, transparent:true, opacity:0, depthWrite:false, flatShading:true});
  let sd = 9; const rn = ()=>{ sd = (sd*16807) % 2147483647; return sd/2147483647; };
  for(let i=0;i<16;i++){ const g = new THREE.Group();
    for(let k=0;k<4+Math.floor(rn()*3);k++){ const b = new THREE.Mesh(new THREE.IcosahedronGeometry(2+rn()*2.2,1), cm); b.position.set((rn()-.5)*7, (rn()-.5)*1.2, (rn()-.5)*4); b.scale.y = 0.45; g.add(b); }
    const a = rn()*Math.PI*2, r = 60+rn()*35; g.position.set(Math.cos(a)*r, 12+rn()*12, Math.sin(a)*r); g.scale.setScalar(1.6+rn()*1.2); g.userData.k = i/16; g.userData.a = a; g.userData.r = r; clouds.add(g); }   // rondom aan de horizon
  clouds.userData.mat = cm; }
let lastT = performance.now();
let frameN = 0, fpsT = performance.now(), fpsN = 0, fpsNow = 0, lastRender = 0;
function loop(){
  requestAnimationFrame(loop);
  if(DET.zuinig && performance.now() - lastRender < 31) return;   // (v65) zuinig: max. ±30 beelden per seconde
  lastRender = performance.now(); frameN++; fpsN++;
  if(lastRender - fpsT > 1000){ fpsNow = Math.round(fpsN*1000/(lastRender-fpsT)); fpsN = 0; fpsT = lastRender; const fe = document.getElementById('fps'); if(fe) fe.textContent = fpsNow+' beelden/s'; }
  const now = performance.now(), dtS = Math.min(0.1,(now-lastT)/1000); flowTick(dtS); netTick(dtS); lastT = now;
  { const c = sky.cloudOpacity||0; clouds.visible = c > 0.04 && mode!==-1 && DET.wolken; clouds.userData.mat.opacity = Math.min(0.9, c*1.1);
    if(clouds.visible) clouds.children.forEach((g,i)=>{ g.visible = g.userData.k < c + 0.08; g.userData.a += dtS*0.004*(1 + (i%3)*0.3); g.position.x = G_CX*0.4 + Math.cos(g.userData.a)*g.userData.r; g.position.z = G_CZ*0.4 + Math.sin(g.userData.a)*g.userData.r; }); }
  for(const m of wallMounts) m.obj.position.y = m.h * m.g.scale.y;
  Object.values(HP).forEach(u=>{ if(!u.fan) return; const act = HP_MODE(u.v.status)[0]!=='idle' || (u.v.comp||0)>0; if(act) u.fan.rotation.z -= Math.max(0.25, Math.min(0.5, (u.v.comp||0)/100*0.6)); });   // (v31) draait zodra de warmtepomp actief is
  { const u = HP.lp9, md = HP_MODE(u.v.status), m = md[0], act = m!=='idle';      // (v57) lampje, leidingen, vloerverwarming
    if(!u.outPipe) hpBuitenPipe();
    u.ledMat.emissive.setHex(act ? 0x3fa7ff : 0x46d17a); u.ledMat.emissiveIntensity = act ? 0.6 + 1.4*(0.5+0.5*Math.sin(now/350)) : 1.1;
    const col = m==='heat' ? 0xff8a3d : m==='dhw' ? 0xb07be0 : m==='cool' || m==='defrost' ? 0x3fa7ff : 0xffc46b;
    const run = (f, on, speed, c)=>{ if(!f) return; if(c!=null) f.dm.color.setHex(c); f.t = (f.t + 0.004*speed) % 1; f.dots.forEach((d,i)=>{ d.visible = on; if(on) d.position.copy(f.curve.getPointAt((f.t + i/f.dots.length) % 1)); }); };
    const F = u.hpFlows || {};
    (u.outPipes||[]).forEach((pp,i)=>{ pp.tube.visible = !!W.buiten; pp.tm.opacity = act ? 0.6 : 0.3;
      if(i===1 && act){ pp.t = (pp.t - 0.0096 + 1) % 1; pp.dm.color.setHex(0x6fb6ff); pp.dots.forEach((d,j)=>{ d.visible = W.buiten; if(d.visible) d.position.copy(pp.curve.getPointAt((pp.t + j/pp.dots.length) % 1)); }); }
      else if(i===0) run(pp, act && W.buiten, 1.2, col); else pp.dots.forEach(d=>d.visible = false); }); run(F.buiten, act && W.buiten, 1.2, col);
    run(F.vvIn, m==='heat' && W.vloer, 1); run(F.vvOut, m==='heat' && W.vloer, 1); run(F.coil, m==='dhw' && W.boiler, 1.2);
    if(u.floorGlow) u.floorGlow.opacity += ((m==='heat' && W.vloer && house.visible ? 0.10 + 0.04*Math.sin(now/900) : 0) - u.floorGlow.opacity)*0.05; }
  { const u = HP.lp9, dhw = HP_MODE(u.v.status)[0]==='dhw';                       // (v33) boiler vullen
    if(u.water){ const avg = u.v.sww!=null ? (u.v.swwLow!=null ? (u.v.sww+u.v.swwLow)/2 : u.v.sww) : null;
      const frac = avg==null ? 0 : Math.min(1, Math.max(0.04, (avg-30)/25)); u.water.scale.y += (frac - u.water.scale.y)*0.05;
      u.waterMat.emissiveIntensity = dhw ? 0.9 + 0.3*Math.sin(now/400) : 0.2;
      const lvl = 0.03 + 1.39*u.water.scale.y, t = (now/1800) % 1; u.wave.position.y = 0.05 + t*(lvl-0.05); u.waveMat.opacity = dhw ? 0.8*(1-t) : 0;
      const tap = !!u.tapping && W.kraan; u.cold.scale.y += ((tap ? 0.35 + 0.08*Math.sin(now/300) : 0.001) - u.cold.scale.y)*0.04; u.coldMat.opacity += ((tap ? 0.55 : 0) - u.coldMat.opacity)*0.08;
      u.drops.forEach((d,i)=>{ d.visible = tap && upWalls.visible; if(d.visible) d.position.copy(u.tapCurve.getPointAt(((now/1400) + i/u.drops.length) % 1)); }); } }
  { const on = stoveOn(); STOVE.pipe.visible = walls.scale.y > 0.9;                                                            // (v33) pelletkachel: vlam + rook
    STOVE.glassMat.emissiveIntensity = on ? 0.55 + 0.15*Math.sin(now/90) : 0; STOVE.light.intensity = on ? (night ? 2.2 : 0.8) * (0.85 + 0.15*Math.sin(now/70)) : 0;
    const ign = stoveMode()==='aansteken';
    STOVE.flames.forEach(f=>{ f.visible = on; if(on){ const k = (ign ? 0.35 : 0.75) + (ign ? 0.2 : 0.35)*Math.abs(Math.sin(now/(ign?60:120) + f.userData.ph)); f.scale.set(1, k, 1); f.position.y = STOVE.h/2 - STOVE.gh/2 + 0.02 + 0.09*k; } });
    smoke.forEach(m=>{ m.visible = on && flatRoof.visible; if(!m.visible) return; const t = (m.userData.t + now/9000) % 1;
      m.position.set(mx(STOVE.x+0.1) + t*0.6 + Math.sin(t*6+m.userData.t*9)*0.08, FR+1.02 + t*2.2, mz(STOVE.y) - t*0.3); m.scale.setScalar(0.6 + t*2.6); m.material.opacity = (ign ? 0.2 : 0.45)*(1-t)*Math.min(1, t*6); }); }
  rooms.forEach(r=>{ if(r.ac && r.ac.outFan && r.climState && !['off','unavailable','unknown'].includes(r.climState)) r.ac.outFan.rotation.z -= 0.35; });   // (v31) LG buitenunits draaien als de airco aan staat
  regenTick(now, dtS);   // (v72) regenwaterpomp → wc-reservoirs
  const playing = MEDIA.sonos.state==='playing';
  sonosWaves.forEach((w,i)=>{ w.material.opacity = playing ? 0.25 + 0.25*Math.sin(now/300 - i*1.2) : 0; });
  walls.scale.y += (wallScale - walls.scale.y)*0.15;
  upWalls.scale.y += (upScale - upWalls.scale.y)*0.15;
  cellarWalls.scale.y += (cellarScale - cellarWalls.scale.y)*0.15;
  controls.target.y += (targetY - controls.target.y)*0.08;
  controls.update();
  { const moving = Math.abs(wallScale-walls.scale.y) + Math.abs(upScale-upWalls.scale.y) + Math.abs(cellarScale-cellarWalls.scale.y) > 0.002;   // (v65) schaduwen hoeven niet elk beeld opnieuw
    if(moving || frameN % 6 === 0) sun.shadow.needsUpdate = true; }
  renderer.render(scene, camera);
  positionLabels();
}
