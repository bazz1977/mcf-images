/* ---------- Woning bouwen ---------- */
const house = new THREE.Group(); scene.add(house);
const wallMat = new THREE.MeshStandardMaterial({color:0xe3e0da, roughness:.92});
// Gevelbekleding woning (gevels + schuin dak): red cedar shingles — textuur 1 × 1 m, rijen van 12,5 cm
function makeShingleTex(){
  const S = 512, CH = 64, c = document.createElement('canvas'); c.width = S; c.height = S; const g = c.getContext('2d');
  let seed = 11; const rnd = ()=>{ seed = (seed*16807) % 2147483647; return seed/2147483647; };
  const tones = ['#9a5a3a','#a4623f','#935536','#ab6843','#8c5033','#a15d3b','#b06d47','#96583a','#874c30'].map((c,i)=>'#'+new THREE.Color(c).lerp(new THREE.Color(0x8d8883), 0.38 + (i%3)*0.06).getHexString());   // (v61) verweerd: grijzer
  g.fillStyle = '#2e1a10'; g.fillRect(0,0,S,S);
  for(let row=0; row<S/CH; row++){
    const y0 = row*CH, widths = []; let rem = S;
    while(rem>0){ let w = Math.min(rem, 34+Math.floor(rnd()*96)); if(rem-w>0 && rem-w<30) w = rem; widths.push(w); rem -= w; }
    let x = Math.floor(rnd()*S);
    widths.forEach(w=>{
      const col = tones[Math.floor(rnd()*tones.length)];
      [x, x-S].forEach(px=>{
        const gr = g.createLinearGradient(0,y0,0,y0+CH); gr.addColorStop(0, shadeHex(col,-0.25)); gr.addColorStop(0.18, col); gr.addColorStop(1, shadeHex(col,0.06));
        g.fillStyle = gr; g.fillRect(px+1.5, y0, w-3, CH-2);
        g.strokeStyle = 'rgba(40,20,10,.16)'; g.lineWidth = 1;
        for(let k=0;k<3;k++){ const gx = px+4+rnd()*(w-8); g.beginPath(); g.moveTo(gx,y0+6); g.lineTo(gx+rnd()*3-1.5,y0+CH-3); g.stroke(); }
      });
      x = (x + w) % S;
    });
    g.fillStyle = 'rgba(20,10,5,.55)'; g.fillRect(0, y0+CH-3, S, 3);        // schaduwlijn onder de onderrand
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = renderer.capabilities.getMaxAnisotropy(); return t;
}
function shadeHex(hex, f){ const c = new THREE.Color(hex); return '#'+c.lerp(new THREE.Color(f<0?0x000000:0xffffff), Math.abs(f)).getHexString(); }
const shingleTex = makeShingleTex();
const brickMat = new THREE.MeshStandardMaterial({color:0xffffff, map:shingleTex, roughness:.9});          // naam blijft 'brickMat': alle gevels
const roofShingleMat = new THREE.MeshStandardMaterial({color:0xe2d2c8, map:shingleTex, roughness:.92});  // schuin dak, iets verweerder
const frameMat = new THREE.MeshStandardMaterial({color:0x2a3036, roughness:.5, metalness:.3});
const merantiMat = new THREE.MeshStandardMaterial({color:0x7a3a22, roughness:.55});                        // (v40) meranti deuren + kader
const cedarTrim = new THREE.MeshStandardMaterial({color:0xa86a44, roughness:.8});                          // (v40) gladde ceder omlijsting
const aluMat = new THREE.MeshStandardMaterial({color:0xc4c8cb, roughness:.38, metalness:.55});           // woonkamer: lichtgrijs aluminium
const roofingMat = new THREE.MeshStandardMaterial({color:0x17181a, roughness:.96});                        // plat dak woonkamer: zwarte roofing
// UV's in meters, zodat de shingles overal even groot zijn (box-projectie per vlak)
function boxUV(mesh, localOnly){
  const gm = mesh.geometry, p = gm.attributes.position, n = gm.attributes.normal, uv = gm.attributes.uv; if(!p || !n || !uv) return;
  const o = localOnly ? {x:0,y:0,z:0} : mesh.position;
  for(let i=0;i<p.count;i++){
    const ax = Math.abs(n.getX(i)), ay = Math.abs(n.getY(i)), az = Math.abs(n.getZ(i));
    const x = p.getX(i)+o.x, y = p.getY(i)+o.y, z = p.getZ(i)+o.z;
    if(ay>=ax && ay>=az) uv.setXY(i, x, z); else if(ax>=az) uv.setXY(i, z, y); else uv.setXY(i, x, y);
  }
  uv.needsUpdate = true;
}
const pickables = [], lampList = [];
rooms.forEach(r=>r.glass=[]);

function box(w,h,d,mat,x,y,z){
  const g = new THREE.BoxGeometry(w,h,d); g.translate(0,h/2,0);   // draaipunt onderaan, zodat muren kunnen zakken
  const m = new THREE.Mesh(g,mat);
  m.position.set(x,y,z); m.castShadow = true; m.receiveShadow = true;
  return m;
}
// gevel? dan buitenkant baksteen
function sideMat(x1,y1,x2,y2){
  const horiz = y1===y2;
  // (v28) ook de kopse kanten in bekleding: geen z-fighting meer op de hoeken
  if(horiz && (y1===0 || y1===D_M)){ const m=Array(6).fill(wallMat); m[y1===0?5:4]=brickMat; m[0]=m[1]=brickMat; return m; }
  if(!horiz && (x1===0 || x1===W_M)){ const m=Array(6).fill(wallMat); m[x1===0?1:0]=brickMat; m[4]=m[5]=brickMat; return m; }
  return null;
}

// ondervloer
// (v28) ondervloer blijft binnen de gevels; rondom een sokkel in gevelmateriaal, zodat je in zijaanzicht geen vloerrand meer ziet
const base = new THREE.Mesh(new THREE.BoxGeometry(W_M-0.1,0.2,D_M-0.1), new THREE.MeshStandardMaterial({color:0x4a4640, roughness:1}));
base.position.y = -0.25; base.receiveShadow = true; house.add(base);
{
  const SOK = 0.35, T = 0.32, WX = 6.47;      // 1 cm voor de kelderwand, zodat de vlakken niet samenvallen
  // [van, tot, vaste coördinaat, langs x?, materiaal]
  [[-0.16, WX, 0, true, 'h'], [WX, W_M+0.16, WK_IN, true, 'w'], [-0.16, WX, D_M, true, 'h'], [WX, W_M+0.16, D_M-WK_IN, true, 'w'],
   [0.15, D_M-0.15, 0, false, 'h'], [WK_IN+0.15, D_M-WK_IN-0.15, W_M, false, 'w']].forEach(([a,b,c,alongX,k])=>{
    const len = b-a, mid = (a+b)/2, mat = k==='w' ? aluMat : brickMat;
    house.add(alongX ? box(len, SOK, T, mat, mx(mid), -SOK, mz(c)) : box(T, SOK, len, mat, mx(c), -SOK, mz(mid)));
  });
  // (v29) achterhuis: ceder loopt aan de achtergevel door over de kelderwand tot 10 cm boven het maaiveld (-1,35 → -1,25)
  const C_BOT = -0.2 - GRADE_DROP + 0.1, C_TOP = -SOK, AX0 = -0.16, AX1 = WX+0.16, z = mz(D_M) + 0.155;   // (v35) tot de hoek
  const clad = (a,b,y0,y1)=>{ if(b-a>0.005 && y1-y0>0.005) house.add(box(b-a, y1-y0, 0.01, brickMat, mx((a+b)/2), y0, z)); };
  let cx0 = AX0;
  K_WIN.filter(([a,b])=>a<AX1).forEach(([a,b])=>{
    const wb = Y_K+KW_B, wt = Y_K+KW_T;
    clad(cx0, a, C_BOT, C_TOP); clad(a, b, C_BOT, wb); clad(a, b, wt, C_TOP); cx0 = b; });
  clad(cx0, AX1, C_BOT, C_TOP);
  house.add(box(0.01, C_TOP-C_BOT, K_REC+0.01, brickMat, mx(WX+0.155), C_BOT, mz(D_M-K_REC+0.15+ (K_REC)/2 + 0.005)));   // (v35) blootgekomen zijkant achterhuis in ceder
}

const walls = new THREE.Group(); house.add(walls);
let wallScale = 0.42;

// dichte muren
SOLID.forEach(([x1,y1,x2,y2,h])=>{
  const outer = sideMat(x1,y1,x2,y2);
  const t = outer ? 0.3 : 0.1;
  const horiz = y1===y2;
  const len = Math.hypot(x2-x1,y2-y1) + t;
  const cx = mx((x1+x2)/2), cz = mz((y1+y2)/2);
  walls.add(box(...(horiz?[len,h,t]:[t,h,len]), outer||wallMat, cx,0,cz));
});

// glas met kozijnen en vlakverdeling
GLASS.forEach(g=>{
  const [x1,y1]=g.a, [x2,y2]=g.b, horiz = y1===y2;
  const len = Math.hypot(x2-x1,y2-y1);
  const dx = Math.sign(x2-x1), dy = Math.sign(y2-y1);
  const at = s=>[mx(x1+dx*s), mz(y1+dy*s)];
  const outer = sideMat(x1,y1,x2,y2);
  const t = outer ? 0.3 : 0.1;
  const base = g.sill || 0;
  const glassTop = base + g.rows.reduce((a,b)=>a+b,0);
  const glassMat = new THREE.MeshStandardMaterial({color:0x8fb4cc, transparent:true, opacity:.26, roughness:.05, metalness:.1});
  byId[g.room].glass.push(glassMat);
  const inset = g.frameless ? 0 : 0.035;

  let s = 0;
  g.cols.forEach(cw=>{
    let h = base;
    g.rows.forEach(rh=>{
      const [cx,cz] = at(s+cw/2);
      const w = cw-2*inset, hh = rh-2*inset;
      const pane = box(...(horiz?[w,hh,0.03]:[0.03,hh,w]), glassMat, cx, h+inset, cz);
      pane.castShadow = false; walls.add(pane);
      h += rh;
    });
    s += cw;
  });
  const fm = g.room==='woon' ? aluMat : g.wood ? merantiMat : frameMat;          // woonkamer lichtgrijs alu; voor- en achterdeur meranti
  if(!g.frameless){
    const fd = 0.12;
    let acc = 0; const vstops=[0]; g.cols.forEach(c=>{acc+=c; vstops.push(acc)});
    vstops.forEach(v=>{ const [cx,cz]=at(v); walls.add(box(...(horiz?[0.07,glassTop-base,fd]:[fd,glassTop-base,0.07]), fm, cx,base,cz)); });
    let hacc = base; const hstops=[base]; g.rows.forEach(r=>{hacc+=r; hstops.push(hacc)});
    const [mcx,mcz] = at(len/2);
    hstops.forEach(hv=>{ walls.add(box(...(horiz?[len,0.07,fd]:[fd,0.07,len]), fm, mcx, Math.max(base,Math.min(hv-0.035, glassTop-0.07)), mcz)); });
    if(g.door || g.slide){ // greep
      const [hx,hz] = at(g.slide ? g.cols[0]-0.12 : len-0.15);
      walls.add(box(...(horiz?[0.04,0.5,0.18]:[0.18,0.5,0.04]), fm, hx, 0.8, hz));
    }
  } else {
    // alleen een dun profiel in vloer en plafondaansluiting
    const [mcx,mcz] = at(len/2);
    walls.add(box(...(horiz?[len,0.03,0.05]:[0.05,0.03,len]), fm, mcx, 0, mcz));
  }
  if(base > 0){ const [mcx,mcz] = at(len/2); walls.add(box(...(horiz?[len,base,t]:[t,base,len]), outer||wallMat, mcx, 0, mcz)); }
  if(g.wallTo > glassTop+0.01){
    const [mcx,mcz] = at(len/2), h = g.wallTo-glassTop;
    walls.add(box(...(horiz?[len,h,t]:[t,h,len]), outer||wallMat, mcx, glassTop, mcz));
  }
});
// (v28) hoeken woonkamer: slanke aluminium profielen die op de gevels aansluiten (was 30 × 30 cm)
POSTS.forEach(([x,y,h])=> walls.add(box(0.1,h,0.12, aluMat, mx(x),0,mz(y))));
// (v59) strook ceder (15 cm) tussen het deurkader en de woonkamer, voor- en achtergevel; loopt om de hoek zodat het (10 cm smallere) aluminium erin valt
[[-0.15,-0.07],[D_M+0.07,D_M+0.15]].forEach(([y0,y1])=>{
  walls.add(box(0.15, 3.05, y1-y0, brickMat, mx(6.545), 0, mz((y0+y1)/2)));
  house.add(box(0.15, 0.35, y1-y0, brickMat, mx(6.545), -0.35, mz((y0+y1)/2)));
});
// (v41) meranti deuren in kader: kaderstijlen vullen de hal tot aan de muren, bovendorpel, deurblad met glas, drempel en greep
[0, D_M].forEach(y=>{
  const D = HAL_DOOR, len = D.x1-D.x0, K = (len-D.w)/2, TOPK = 0.07, dep = 0.16, z = mz(y), out = y===0 ? -1 : 1;
  walls.add(box(len, H_REST-D.h-TOPK, 0.3, sideMat(D.x0,y,D.x1,y), mx(D.xc), D.h+TOPK, z));                  // gevel boven de deur
  [D.x0+K/2, D.x1-K/2].forEach(x=>walls.add(box(K, D.h+TOPK, dep, merantiMat, mx(x), 0, z)));                 // kaderstijlen
  walls.add(box(len, TOPK, dep, merantiMat, mx(D.xc), D.h, z));                                                    // bovendorpel
  walls.add(box(len, 0.025, 0.3, frameMat, mx(D.xc), 0, z));                                                       // drempel
  const gm = new THREE.MeshStandardMaterial({color:0x8fb4cc, transparent:true, opacity:.26, roughness:.05, metalness:.1}); byId.hal.glass.push(gm);
  const pane = box(D.w-0.18, D.h-0.26, 0.03, gm, mx(D.xc), 0.17, z); pane.castShadow = false; walls.add(pane);
  [D.x0+K+0.045, D.x1-K-0.045].forEach(x=>walls.add(box(0.09, D.h, 0.06, merantiMat, mx(x), 0, z)));            // deurblad: stijlen
  [[0,0.17],[D.h-0.09,0.09]].forEach(([h0,hh])=>walls.add(box(D.w-0.18, hh, 0.06, merantiMat, mx(D.xc), h0, z))); // onder- en bovenregel
  [1,-1].forEach(sd=>walls.add(box(0.03, 0.4, 0.03, frameMat, mx(D.x1-K-0.12), 0.85, z + sd*0.05)));            // greep binnen en buiten
});
// doorgangen begane grond: kozijn + bovenlicht dicht tot plafond (binnendeuren weggelaten in v28)
const doorFrameM = new THREE.MeshStandardMaterial({color:0xefeee9, roughness:.6}), doorLeafM = new THREE.MeshStandardMaterial({color:0xf5f4f0, roughness:.55});
const WIRE_MATS = new Set([doorFrameM, doorLeafM]);   // extra materialen die in wireframe-modus als muur tellen
G_DOORS.forEach(([x1,y1,x2,y2,hinge,swing,deg])=>{
  const horiz = y1===y2, len = Math.hypot(x2-x1,y2-y1), cx = (x1+x2)/2, cy = (y1+y2)/2, DH = 2.1, T = 0.1;
  const tag = m=>{ m.userData.struct = true; return m; };
  walls.add(tag(box(horiz?len:T, H_REST-DH, horiz?T:len, wallMat, mx(cx), DH, mz(cy))));
  [0,1].forEach(e=>{ const px = e?x2:x1, py = e?y2:y1, dx = horiz?(e?-0.03:0.03):0, dy = horiz?0:(e?-0.03:0.03);
    walls.add(tag(box(horiz?0.06:0.12, DH, horiz?0.12:0.06, doorFrameM, mx(px+dx), 0, mz(py+dy)))); });
  walls.add(tag(box(horiz?len:0.12, 0.05, horiz?0.12:len, doorFrameM, mx(cx), DH-0.05, mz(cy))));
  // (v28) geen deurblad meer: alleen de open doorgang met kozijn
});
PILLARS.forEach(y=>{ const c = new THREE.Mesh(new THREE.CylinderGeometry(0.1,0.1,H_WOON,24), frameMat);
  c.geometry.translate(0,H_WOON/2,0); c.position.set(mx(K_X1),0,mz(y)); c.castShadow = true; walls.add(c); });

