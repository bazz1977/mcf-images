/* ---------- Daken en zonnepanelen ---------- */
const roofGroup = new THREE.Group(); scene.add(roofGroup);   // schuin dak (alleen Buitenkant)
const flatRoof = new THREE.Group(); scene.add(flatRoof);     // plat dak woonkamer (Verdieping + Buitenkant)
const roofMat = new THREE.MeshStandardMaterial({color:0x33383e, roughness:.85});
const panelMat = new THREE.MeshStandardMaterial({color:0x16233a, roughness:.25, metalness:.5, emissive:0x2d64c8, emissiveIntensity:0});
const panelEdge = new THREE.MeshStandardMaterial({color:0xb9c0c7, roughness:.4, metalness:.7});
const PW = 1.134, PL = 1.722;   // standaard 395 Wp paneel (±1,72 × 1,13 m)

function slope(y0,h0,y1,h1,x0,x1,thick,mat,parent){
  const L = Math.hypot(y1-y0,h1-h0), a = Math.atan2(h1-h0,y1-y0);
  const m = new THREE.Mesh(new THREE.BoxGeometry(x1-x0, thick, L), mat);
  const ny = -Math.sin(a), nh = Math.cos(a);
  m.position.set(mx((x0+x1)/2), F1+(h0+h1)/2+nh*thick/2, mz((y0+y1)/2)+ny*thick/2);
  m.rotation.x = -a; m.castShadow = true; m.receiveShadow = true;
  parent.add(m); return a;
}
const OV = 0.35, tf = (RIDGE_H-KNEE)/RIDGE_Y, tb = (RIDGE_H-KNEE)/(D_M-RIDGE_Y);
const aF = slope(-OV, KNEE-OV*tf, RIDGE_Y, RIDGE_H, -0.3, PITCH_W+0.15, 0.18, roofShingleMat, roofGroup);   // red cedar shingles
slope(RIDGE_Y, RIDGE_H, D_M+OV, KNEE-OV*tb, -0.3, PITCH_W+0.15, 0.18, roofShingleMat, roofGroup);
// (v64) nok: twee cederplanken in het verlengde van de dakvlakken, zelfde materiaal en belichting als het dak; ze kruisen elkaar en sluiten de nok
{ const tf2 = (RIDGE_H-KNEE)/RIDGE_Y, tb2 = (RIDGE_H-KNEE)/(D_M-RIDGE_Y), e = 0.14;
  slope(RIDGE_Y-0.32, RIDGE_H-0.32*tf2, RIDGE_Y+e, RIDGE_H+e*tf2, -0.3, PITCH_W+0.15, 0.24, roofShingleMat, roofGroup);
  slope(RIDGE_Y-e, RIDGE_H+e*tb2, RIDGE_Y+0.34, RIDGE_H-0.34*tb2, -0.3, PITCH_W+0.15, 0.24, roofShingleMat, roofGroup); }

// iets op het voordakvlak leggen: s = afstand langs het dakvlak vanaf de goot (y=0)
function onFrontSlope(mesh, xc, s, lift){
  const y = Math.cos(aF)*s, h = KNEE + Math.sin(aF)*s;
  mesh.position.set(mx(xc), F1+h+Math.cos(aF)*lift, mz(y)-Math.sin(aF)*lift);
  mesh.rotation.x = -aF; roofGroup.add(mesh);
}
function panel(){ const g=new THREE.Group();
  const p=new THREE.Mesh(new THREE.BoxGeometry(PW-0.02,0.035,PL-0.02),panelMat); p.castShadow=true;
  const e=new THREE.Mesh(new THREE.BoxGeometry(PW,0.03,PL),panelEdge); e.position.y=-0.01;
  g.add(e,p); return g; }
// 10 panelen op het schuine dak: 1 kolom × 2, dakraam, 4 kolommen × 2 (staand)
const rowS = [0.35+PL/2, 0.35+PL*1.5+0.03];
const colsX = [0.05+PW/2, ...[0,1,2,3].map(i=>1.74+PW/2+i*(PW+0.03))];
colsX.forEach(xc=>rowS.forEach(sv=>onFrontSlope(panel(), xc, sv, 0.2)));
// (v33) Velux voordakvlak netjes in de strook tussen de panelen (x 1,18–1,74): 0,50 breed, zelfde hoogte als rij 1+2
const veluxMat = ()=> new THREE.MeshStandardMaterial({color:0x6f93b0, roughness:.1, metalness:.3, emissive:0x000000});
function veluxOf(w,l,room){ const g = new THREE.Group(); const m = veluxMat(); if(room && byId[room]) byId[room].glass.push(m);
  const frame = new THREE.Mesh(new THREE.BoxGeometry(w,0.07,l), new THREE.MeshStandardMaterial({color:0x3a3f45, roughness:.5}));
  const pane = new THREE.Mesh(new THREE.BoxGeometry(w-0.08,0.075,l-0.08), m); g.add(frame, pane); return g; }
const velux = veluxOf(0.50, 1.50, 'jolie');   // (v35) 1,50 m hoog, iets lager
onFrontSlope(velux, (0.05+PW+1.74)/2, 1.55, 0.21);
// achterdakvlak: 1 Velux bij kamer Jolie, 2 bij kamer Lucas (AANNAME: 0,55 × 0,98, halverwege het dakvlak)
const aB = Math.atan2(RIDGE_H-KNEE, D_M-RIDGE_Y);
function onBackSlope(mesh, xc, y, lift){ const h = roofH(y);
  mesh.position.set(mx(xc), F1+h+Math.cos(aB)*lift, mz(y)+Math.sin(aB)*lift); mesh.rotation.x = aB; roofGroup.add(mesh); }
[[1.5,'jolie'],[4.2,'lucas'],[5.4,'lucas']].forEach(([x,room])=> onBackSlope(veluxOf(0.55,1.50,room), x, 5.15, 0.2));   // (v35) 1,50 m hoog, iets lager

// plat dak woonkamer 3,0 m + dakrand
const WX0 = 6.47, WX1 = W_M;
// (v28) boeiboord en dakrand lichtgrijs aluminium, bovenop zwarte roofing
// (v37) dakrand woonkamer = zelfde als de rand onderaan (sokkel): 0,35 m hoog, 0,32 m dik op de gevellijn, geen overstek meer;
//       zwarte roofing ligt 2 cm lager dan de bovenkant van de rand
const RIM_H = 0.35, RIM_T = 0.32, ROOFING = 0.02;
flatRoof.add(box(WX1+RIM_T/2-WX0, RIM_H-ROOFING, D_M-2*WK_IN+RIM_T, [aluMat,aluMat,roofingMat,aluMat,aluMat,aluMat], mx((WX0+WX1+RIM_T/2)/2), H_WOON, 0));
[[WK_IN],[D_M-WK_IN]].forEach(([y])=>flatRoof.add(box(WX1+RIM_T/2-WX0, RIM_H, RIM_T, aluMat, mx((WX0+WX1+RIM_T/2)/2), H_WOON, mz(y))));
flatRoof.add(box(RIM_T, RIM_H, D_M-2*WK_IN+RIM_T, aluMat, mx(WX1), H_WOON, 0));
// 7 panelen: 5 liggend in een kolom + 2 staand, licht gekanteld — (v28) helling richting de linkergevel
const FR = H_WOON+RIM_H-ROOFING,   /* (v37) bovenkant roofing */ TILT = 8*Math.PI/180;
function flatPanel(xc,yc,landscape){
  const g = panel(); if(landscape) g.rotation.y = Math.PI/2;
  const holder = new THREE.Group(); holder.add(g);
  holder.position.set(mx(xc), FR+0.18, mz(yc)); holder.rotation.z = -TILT;   // lage kant aan de linkergevel (x+)
  flatRoof.add(holder);
}
for(let i=0;i<5;i++) flatPanel(6.75+PL/2, 0.35+PW/2+i*(PW+0.03), true);
flatPanel(9.2+PW/2, 0.3+PL/2, false);
flatPanel(9.2+PW/2, 4.7+PL/2, false);
// schouw, 1 m boven het dak
const chim = new THREE.Mesh(new THREE.CylinderGeometry(0.1,0.1,1.0,20), panelEdge);   // (v30) even dik als de palen (Ø 20 cm)
chim.position.set(mx(STOVE.x+0.1), FR+0.5, mz(STOVE.y)); chim.castShadow = true; flatRoof.add(chim);   // (v33) recht boven de pelletkachel
// rook uit de schouw zolang de pelletkachel brandt
const smokeMat = new THREE.MeshStandardMaterial({color:0xb9bcc0, transparent:true, opacity:0, depthWrite:false, roughness:1});
const smoke = Array.from({length:14}, (_,i)=>{ const m = new THREE.Mesh(new THREE.IcosahedronGeometry(0.12,1), smokeMat.clone()); m.userData.t = i/14; m.visible = false; flatRoof.add(m); return m; });
// Starlink-schotel op het platte dak (achterhoek)
{
  const g = new THREE.Group();
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(.025,.025,.45,8), spotRing); mast.position.y = .225;
  const foot = new THREE.Mesh(new THREE.BoxGeometry(.5,.04,.5), new THREE.MeshStandardMaterial({color:0x444})); foot.position.y = .02;
  const dish = new THREE.Mesh(new THREE.BoxGeometry(.38,.035,.59), new THREE.MeshStandardMaterial({color:0xf1f1ef, roughness:.35}));
  dish.position.y = .48; dish.rotation.z = 0.5;
  g.add(foot, mast, dish); g.traverse(o=>o.castShadow=true);
  g.position.set(mx(STARLINK_DISH[0]), FR, mz(STARLINK_DISH[1])); flatRoof.add(g);
}

