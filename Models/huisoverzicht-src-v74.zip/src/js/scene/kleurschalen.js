/* ---------- Kleurschalen ---------- */
const TEMP_STOPS=[[15,'#3f6fd6'],[18,'#4fb2c6'],[20.5,'#8fd17a'],[22.5,'#f2b84b'],[25,'#e5603f']];
const HUM_STOPS =[[30,'#e8c56a'],[45,'#9fd3a8'],[60,'#5fa8d9'],[75,'#3d5fc4']];
function scale(stops,v){
  if(v<=stops[0][0]) return new THREE.Color(stops[0][1]);
  for(let i=1;i<stops.length;i++){
    if(v<=stops[i][0]){
      const [a,ca]=stops[i-1],[b,cb]=stops[i];
      return new THREE.Color(ca).lerp(new THREE.Color(cb),(v-a)/(b-a));
    }
  }
  return new THREE.Color(stops[stops.length-1][1]);
}
const NEUTRAL = new THREE.Color('#b39b7c');
const NO_DATA = new THREE.Color('#7d8288');   // ruimte zonder sensor

