// (v42) tuin: grindpad met kastanjehekje, zwembad, laurierhagen, vijver met pompput, buitenstopcontact op het trapmuurtje
{
  const at = (x,y,dy=0)=> gradeAt(mx(x), mz(y)) + dy;
  // (v74) oud grindpad + kastanjehekje vervallen: organisch pad langs de straatzijde, zie js/scene/voortuin-regenwater.js
  // zwembad Intex Ultra XTR Frame 732 × 366 × 132 cm met filterpomp (lange kant evenwijdig aan de rechtergevel)
  { const P = {x:2.9, y:17.0, L:7.32, W:3.66, H:1.32}, base = at(P.x, P.y), g = new THREE.Group();
    const wallM = new THREE.MeshStandardMaterial({color:0x8e959b, roughness:.7}), frameM = new THREE.MeshStandardMaterial({color:0x5d6368, roughness:.5, metalness:.3});
    const water = new THREE.MeshStandardMaterial({color:0x3aa7c9, roughness:.08, metalness:.1, transparent:true, opacity:.85});
    g.add(box(P.W, P.H, P.L, [wallM,wallM,water,wallM,wallM,wallM], 0, 0, 0));
    g.children[0].scale.y = 1; const top = box(P.W+0.12, 0.05, P.L+0.12, frameM, 0, P.H-0.02, 0); g.add(top);
    const water2 = new THREE.Mesh(new THREE.PlaneGeometry(P.W-0.1, P.L-0.1), water); water2.rotation.x = -Math.PI/2; water2.position.y = P.H-0.12; g.add(water2);
    for(let i=0;i<=6;i++){ const zz = -P.L/2 + i*P.L/6; [-1,1].forEach(sd=>g.add(box(0.06, P.H+0.02, 0.06, frameM, sd*(P.W/2+0.06), 0, zz))); }
    [-1,1].forEach(sd=>[-0.9,0.9].forEach(xx=>g.add(box(0.06, P.H+0.02, 0.06, frameM, xx, 0, sd*(P.L/2+0.06)))));
    g.position.set(mx(P.x), base, mz(P.y)); g.traverse(o=>{ if(o.isMesh){ o.castShadow = true; o.receiveShadow = true; } }); scene.add(g); garden.push(g);
    const pump = new THREE.Group(); const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.22,0.25,0.62,20), new THREE.MeshStandardMaterial({color:0x2d3a46, roughness:.5})); tank.position.y = 0.31+0.08;
    const pbase = box(0.62, 0.08, 0.5, frameM, 0.08, 0, 0); const motor = box(0.2, 0.22, 0.3, new THREE.MeshStandardMaterial({color:0x2b2f33}), 0.32, 0.08, 0);
    pump.add(pbase, tank, motor); pump.position.set(mx(P.x+P.W/2+0.7), at(P.x+P.W/2+0.7, P.y-P.L/2+0.8), mz(P.y-P.L/2+0.8)); pump.traverse(o=>{ if(o.isMesh) o.castShadow = true; }); scene.add(pump); garden.push(pump);
    POOL.pump = pump; }
  // Portugese laurierhagen naast het zwembad: 0,6 m dik, 2,0 m hoog
  { const laurel = [new THREE.MeshStandardMaterial({color:0x2a4a24, roughness:.7, flatShading:true}), new THREE.MeshStandardMaterial({color:0x33552a, roughness:.7, flatShading:true})];
    let sd = 3; const rn = ()=>{ sd = (sd*16807) % 2147483647; return sd/2147483647; };
    [[11.5,16.4],[17.6,22.6]].forEach(([y0,y1])=>{ const x = 6.7, len = y1-y0, b = Math.min(at(x,y0), at(x,y1), at(x,(y0+y1)/2));
      const hg = box(0.6, 2.0, len, laurel[0], mx(x), b-0.05, mz((y0+y1)/2)); scene.add(hg); garden.push(hg);
      for(let k=0;k<Math.round(len*3);k++){ const lump = new THREE.Mesh(new THREE.IcosahedronGeometry(0.2+rn()*0.14,0), laurel[k%2]); lump.position.set(mx(x)+(rn()<.5?-1:1)*0.3, b+0.2+rn()*1.8, mz(y0+rn()*len)); lump.castShadow = true; scene.add(lump); garden.push(lump); } }); }
  // ronde vijver (±10 m) met rand en een kleine pompput (Ø 80 cm) met pomp en stroompunt
  { const water = new THREE.Mesh(new THREE.CircleGeometry(POND.r, 64), new THREE.MeshStandardMaterial({color:0x2c5560, roughness:.06, metalness:.15, transparent:true, opacity:.9}));
    water.rotation.x = -Math.PI/2; water.position.set(mx(POND.x), POND.lvl, mz(POND.y)); water.receiveShadow = true; scene.add(water); garden.push(water);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(POND.r, 0.12, 6, 64), new THREE.MeshStandardMaterial({color:0x7d7a70, roughness:1})); rim.rotation.x = Math.PI/2; rim.position.set(mx(POND.x), POND.lvl+0.04, mz(POND.y)); scene.add(rim); garden.push(rim);
    const PP = {x:POND.x, y:POND.y+POND.r+1.4}, pb = at(PP.x, PP.y);
    const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.4,0.4,0.12,28,1,true), new THREE.MeshStandardMaterial({color:0x7a7a74, roughness:1, side:THREE.DoubleSide})); ring.position.set(mx(PP.x), pb+0.02, mz(PP.y));
    const lid = new THREE.Mesh(new THREE.CircleGeometry(0.37, 28), new THREE.MeshStandardMaterial({color:0x1e2226, roughness:.9})); lid.rotation.x = -Math.PI/2; lid.position.set(mx(PP.x), pb+0.06, mz(PP.y));
    const post = box(0.1, 0.8, 0.1, new THREE.MeshStandardMaterial({color:0x3a3f45}), mx(PP.x+0.6), pb, mz(PP.y));      // stroompunt (paaltje met stopcontact)
    const sock = box(0.09, 0.09, 0.05, new THREE.MeshStandardMaterial({color:0x5c6166}), mx(PP.x+0.6), pb+0.6, mz(PP.y)-0.07);
    [ring, lid, post, sock].forEach(m=>{ scene.add(m); garden.push(m); }); POND.pit = PP; }
  // (v72) oud pad rechtsvoor + poort in de klimop vervallen: zie js/scene/voortuin-regenwater.js
  // enkel buitenstopcontact op de buitenkant van het trapmuurtje langs de achtergevel, rechts onderaan
  { const y = STAIR_YL+1.0+0.15, x = TR_X0-0.2, b = -0.2 - GRADE_DROP;
    const plate = box(0.09, 0.11, 0.04, new THREE.MeshStandardMaterial({color:0x5c6166, roughness:.6}), mx(x), b+0.28, mz(y)+0.02);
    const lid = box(0.08, 0.05, 0.03, new THREE.MeshStandardMaterial({color:0x6d7277}), mx(x), b+0.345, mz(y)+0.045);
    [plate, lid].forEach(m=>{ sideTerrace.add(m); }); }
}
