// ===== (v38) ZON, SCHEMERING EN BEWOLKING ======================================
// Ligging (kompas Bas): de linkergevel (+x, woonkamer) kijkt naar 156° ZO; voorgevel ≈ 66° ONO, achtergevel ≈ 246° WZW, rechtergevel ≈ 336° NNW.
const SITE = {lat:51.47, lon:4.47, bearingX:156};
const sky = {mode:'auto', simMin:null, cloud:0.3, liveSun:false, liveCloud:false, elev:null, az:null, cur:{elev:0, az:0}};
function sunPos(d, lat, lon){                     // benadering (NOAA), ±0,5° — genoeg voor schaduw
  const R = Math.PI/180, n = d.getTime()/86400000 + 2440587.5 - 2451545.0;
  const L = (280.46 + 0.9856474*n) % 360, g = (357.528 + 0.9856003*n) % 360;
  const lam = L + 1.915*Math.sin(g*R) + 0.020*Math.sin(2*g*R), eps = 23.439 - 0.0000004*n;
  const ra = Math.atan2(Math.cos(eps*R)*Math.sin(lam*R), Math.cos(lam*R)), dec = Math.asin(Math.sin(eps*R)*Math.sin(lam*R));
  const gmst = ((18.697374558 + 24.06570982441908*n) % 24 + 24) % 24, ha = (gmst*15 + lon)*R - ra, la = lat*R;
  const el = Math.asin(Math.sin(la)*Math.sin(dec) + Math.cos(la)*Math.cos(dec)*Math.cos(ha));
  const az = Math.atan2(-Math.sin(ha), Math.tan(dec)*Math.cos(la) - Math.sin(la)*Math.cos(ha));
  return {elev: el/R, az: ((az/R) % 360 + 360) % 360};
}
const C = h => new THREE.Color(h), tmpC = new THREE.Color();
const SKY = {night:C(0x0b1119), dusk:C(0x3b4466), glow:C(0xe8a46a), day:C(0xbfd6e6), grey:C(0xa7b0b8)};
function currentSun(){
  if(sky.mode==='day') return {elev:38, az:200};
  if(sky.mode==='night') return {elev:-20, az:340};
  if(sky.simMin==null && LIVE && sky.liveSun && sky.elev!=null) return {elev:sky.elev, az:sky.az};
  const d = new Date(); if(sky.simMin!=null){ d.setHours(0,0,0,0); d.setMinutes(sky.simMin); }
  return sunPos(d, SITE.lat, SITE.lon);
}
function updateSky(force){
  const {elev, az} = currentSun(); sky.cur = {elev, az};
  const fcC = (sky.simMin!=null && sky.liveCloud) ? (wxAt(simDate())||{}).cloud : null;   // live: voorspelde bewolking op het gekozen uur
  const c = Math.max(0, Math.min(1, fcC!=null ? fcC : sky.cloud)), day = sstep(-7, 6, elev), up = sstep(-1, 4, elev), low = 1 - sstep(3, 22, elev);
  // richting naar de zon in modelcoördinaten (+x = 156°, +y = 246°)
  const rel = (az - SITE.bearingX)*Math.PI/180, ce = Math.cos(Math.max(elev, 4)*Math.PI/180);
  if(up > 0) sun.position.set(Math.cos(rel)*ce*45, Math.sin(Math.max(elev,4)*Math.PI/180)*45, Math.sin(rel)*ce*45);
  else sun.position.set(18, 32, -14);            // maanlicht, vaste stand
  sun.intensity = (1-up)*0.3 + up*2.6*(1-0.78*c);
  sun.color.copy(C(0x9db4ff)).lerp(C(0xfff4e0), up).lerp(C(0xffa865), up*low*(1-0.6*c));
  hemi.intensity = 0.38 + day*(0.72 + 0.4*c); hemi.color.copy(C(0x8fa6d6)).lerp(C(0xcfe3ff), day);
  const bg = tmpC.copy(SKY.night).lerp(SKY.dusk, sstep(-9,-2,elev)).lerp(SKY.glow, Math.max(0, 1-Math.abs(elev-1)/7)*(1-c)*0.7).lerp(SKY.day, sstep(2, 12, elev));
  bg.lerp(SKY.grey, c*0.65*day).lerp(SKY.night, 0);
  if(!(scene.background && scene.background.isColor)) scene.background = new THREE.Color();
  scene.background.copy(bg);
  if(!scene.fog) scene.fog = new THREE.Fog(bg, 60, 150); scene.fog.color.copy(bg); scene.fog.near = 55 + 15*day - 20*c*day; scene.fog.far = 130 + 30*day - 40*c*day;
  renderer.toneMappingExposure = 1.1 - 0.1*day;
  sky.cloudOpacity = c;
  const n = elev < -3;
  if(n !== night || force){ night = n; applyLamps(); applyPV(); wireColor(); }
  syncNightBtn();
  const lbl = document.getElementById('simlbl'); if(lbl && sky.simMin==null){ const t = new Date(); lbl.textContent = 'nu'; const st = document.getElementById('simtime'); if(st && document.activeElement!==st) st.value = t.getHours()*60+t.getMinutes(); }
}
function applyNight(){ updateSky(true); }
function applyPV(){ if(!LIVE){ if(night) energy.pv = 0; else if(energy.pv===0) energy.pv = 3.4; } panelMat.emissiveIntensity = 0.5*(energy.pv||0)/PV_KWP; }
let targetY = 0.6;
function applyMode(){
  const k = mode===-1;
  house.visible = !k; terrace.visible = !k; path.visible = !k; terraceRoof.visible = !k; sideTerrace.visible = !k;
  try{ applyDetail(); }catch(_){}   // (v65) bij het opstarten bestaat het detailmenu nog niet
  upper.visible = mode>=1;
  flatRoof.visible = mode>=1;
  roofGroup.visible = mode===2;
  wallScale = mode===0 && !wire ? 0.42 : 1;          // wireframe: muren op volle hoogte, je kijkt er toch doorheen
  upScale = mode===1 && !wire ? 0.42 : 1;
  cellarScale = k && !wire ? 0.5 : 1;
  targetY = {'-1':Y_K+0.6, 0:0.6, 1:F1+0.6, 2:3.2}[mode];
  document.querySelectorAll('.seg button').forEach(b=>b.setAttribute('aria-pressed', String(+b.dataset.mode===mode)));
}

