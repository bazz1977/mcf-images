// Tuin
const stoneMat = new THREE.MeshStandardMaterial({color:0x8f8a82, roughness:.9});
// maaiveld (v28) — gevels: voorgevel y=0 (voordeur), achtergevel y=6,7, linkergevel x=10,52 (woonkamer), rechtergevel x=0 (slaapkamer)
//  · voorgevel en rechtergevel (terras over de hele lengte): maaiveld op nulpas (-0,2)
//  · achtergevel: over de hele lengte ±1 m kelder vrij (maaiveld -1,35); de daling zit binnen de gevellijn, dus direct tegen de kelder
//  · linkergevel: glooiing begint halverwege het terras (y ≈ -2) en loopt organisch af tot de achterhoek
const sstep = (a,b,v)=>{ const t=Math.min(1,Math.max(0,(v-a)/(b-a))); return t*t*(3-2*t); };
const GRADE_DROP = 1.35,   /* (v32) 1,20 m vrij tot onderkant woonkamer/sokkel */ TR_X0 = -4.15, STAIR_X0 = -5.15,   /* (v74) terras noord 4 m (4 tegels) vanaf de gevel; trap schuift mee */ STAIR_Y0 = 5.73, STAIR_YL = 6.85, HEDGE_X = -5.5;   /* (v36) trap: 4 treden // rechtergevel, bordes 1×1 m achter de keerwandlijn, 1 trede haaks naar de lage tuin */   // (v31) trap 1 m breed naast het terras; grens met klimop        // daling achter/links; buitenrand terras rechtergevel
// (v30) profiel linkergevel volgens schets Bas: daalt vooral langs het terras (±0,95 m tot aan de woonkamer), daarna rustig tot de achterhoek
const LEFT_PROFILE = [[-3.3,0],[-2.6,0.08],[-1.75,0.23],[-0.6,0.5],[0,0.56],[1.5,0.72],[2.8,0.9],[4.0,1],[6.9,1]];   // (v31) lijn Bas 26-09
function leftProfile(y){
  const P = LEFT_PROFILE; if(y<=P[0][0]) return 0; if(y>=P[P.length-1][0]) return 1;
  for(let i=1;i<P.length;i++) if(y<=P[i][0]){ const [a,fa]=P[i-1],[b,fb]=P[i], t=(y-a)/(b-a); return fa+(fb-fa)*t*t*(3-2*t); }
  return 1;
}
// (v34) perceel ±1800 m² (≈ 47,5 × 38 m, lange zijde langs de voorgevel); hoofdweg (onverhard) 9 m voor de voorgevel,
// weg van de buren (onverhard) 5,5 m rechts van het huis; klimop op de rechtergrens, hek 2 m voor, 1,5 m links en achter
const PLOT = {x0:HEDGE_X, x1:HEDGE_X+47.5, y0:-9, y1:-9+38}, ROAD_W = 4;
// (v72) voortuin volgens tekening Bas 27-09: tuinpad 1 m (15 × 15 betonklinkers) van de hoofdweg tot de dubbele poort bij het pad langs het huis
const TUINPAD = {x0:-3.25, x1:-1.75, y0:-9, y1:-2.75};   // (v74) 1,5 m opgeschoven richting klimop en 1,5 m breed
const TERRAS_HEK_X = -0.5;   // hek 2,0 m tussen de zwarte aarde en de border van het klinkerterras
// (v35) hek rondom op nulpas: de lage tuin loopt langs het achterhek, het linkerhek en achteraan de rechtergrens organisch terug omhoog
const POOL = {};
const POND = {x:30, y:19, r:5, lvl:-0.2-1.35-0.12};   // (v42) ronde vijver ±10 × 10 m, rechts achterin
function gradeAt(X,Z){
  const x = X + W_M/2, y = Z + D_M/2;
  if(x < HEDGE_X-0.05 || x > PLOT.x1 || y > PLOT.y1 || y < PLOT.y0) return -0.2;   // buiten het perceel en de wegen: nulpas
  const drop = -0.2 - gradeIn(x, y); if(drop <= 0) return -0.2 - drop;
  const wb = 1.2*Math.sin(x*0.23+0.8) + 0.7*Math.sin(x*0.61+2.0), wl = 1.1*Math.sin(y*0.27+1.3) + 0.6*Math.sin(y*0.7), wr = 0.9*Math.sin(y*0.35+0.4);
  const fBack = sstep(0.3, 5.5+wb, PLOT.y1 - y), fLeft = sstep(0.3, 5.5+wl, PLOT.x1 - x);
  const fRight = 1 - (1 - sstep(0.3, 4.5+wr, x - HEDGE_X)) * sstep(8, 12, y);          // rechts alleen achteraan, niet bij het huis
  const g = -0.2 - drop * Math.min(fBack, fLeft, fRight);
  const dp = Math.hypot(x-POND.x, y-POND.y);                                             // (v42) vijver: kom in het gras
  return dp < POND.r+0.6 ? Math.min(g, POND.lvl - 0.5*sstep(POND.r+0.6, POND.r-1.5, dp) + 0.12*sstep(POND.r, POND.r+0.6, dp)) : g;
}
function gradeIn(x, y){
  const X = x - W_M/2, Z = y - D_M/2;
  // (v36) rechts van het terras: gras op nulpas; trapgat (treden + bordes + trede); achter het bordes een talud naar de lage tuin
  if(x < TR_X0+0.3){
    if(x > STAIR_X0-0.2 && y > STAIR_Y0-0.1 && y < STAIR_YL+1.05) return -0.2 - GRADE_DROP;
    if(!(x > TR_X0-0.05 && y < D_M+0.2)){
      const fx = sstep(STAIR_X0-0.2, TR_X0+0.3, x);
      return -0.2 - GRADE_DROP * fx * sstep(7.95, 8.7, y + 1.85*fx);
    }
  }
  const back = (x>6.3 && x<K_X1+0.3) ? sstep(D_M-K_REC-0.45, D_M-K_REC+0.08, y) : sstep(D_M-0.45, D_M+0.15, y);   // (v35) insprong onder de woonkamer
  const far = Math.max(0, x-10.2);
  const wob = (0.9*Math.sin(0.55*x+0.7) + 0.5*Math.sin(1.35*x+2.1) + 0.35*Math.sin(0.8*y+0.3*x)) * Math.min(1, far/4);
  const left = sstep(9.6, 9.95, x) * leftProfile(y + wob);   // (v32) gras koud tegen de keldermuur (overgang zit binnen de muur)
  return -0.2 - GRADE_DROP*Math.max(back, left);
}
const G_CX = mx(20), G_CZ = mz(12);                                                    // (v34) groter maaiveld: perceel + wegen
const gGeo = new THREE.PlaneGeometry(84,70,336,280); gGeo.rotateX(-Math.PI/2); gGeo.translate(G_CX,0,G_CZ);
{ const pos = gGeo.attributes.position;
  for(let i=0;i<pos.count;i++) pos.setY(i, gradeAt(pos.getX(i), pos.getZ(i)));
  gGeo.computeVertexNormals(); }
const ground = new THREE.Mesh(gGeo, new THREE.MeshStandardMaterial({color:0x3e5a3a, roughness:1}));
ground.receiveShadow = true; scene.add(ground);
// (v66) licht grasveld: 4 m rondom het huis (±9 k driehoeken i.p.v. 188 k), zelfde glooiing
const GR4 = {x0:-4, x1:W_M+4, y0:-4, y1:D_M+4};
const g4Geo = new THREE.PlaneGeometry(GR4.x1-GR4.x0, GR4.y1-GR4.y0, Math.round((GR4.x1-GR4.x0)*4), Math.round((GR4.y1-GR4.y0)*4)); g4Geo.rotateX(-Math.PI/2); g4Geo.translate(mx((GR4.x0+GR4.x1)/2), 0, mz((GR4.y0+GR4.y1)/2));
{ const pos = g4Geo.attributes.position; for(let i=0;i<pos.count;i++) pos.setY(i, gradeAt(pos.getX(i), pos.getZ(i))); g4Geo.computeVertexNormals(); }
const ground4 = new THREE.Mesh(g4Geo, ground.material); ground4.receiveShadow = true; ground4.visible = false; scene.add(ground4);
// terras aan de voorzijde voor de woonkamer, boven de kelderuitbouw
const terrace = new THREE.Mesh(new THREE.BoxGeometry(K_X1+0.15-6.385,0.08,TERR_D), stoneMat);   // (v73) sluit aan op het pad (x 6,385), geen overlap
terrace.position.set(mx((6.385+K_X1+0.15)/2),-0.16,mz(-TERR_D/2)); terrace.receiveShadow = true; scene.add(terrace);
const path = new THREE.Mesh(new THREE.BoxGeometry(1.0,0.06,8.85), stoneMat);   // (v34) pad tot aan het hek aan de hoofdweg
path.position.set(mx(HAL_DOOR.xc),-0.15,mz(-4.575));   /* (v73) bovenkant -0,12 = zelfde hoogte als de terrassen */ path.receiveShadow = true; scene.add(path);   // (v41) 1 m breed, recht voor de voordeur
// terras langs de rechtergevel (over de hele lengte, op nulpas); achteraan een keerwand waar het maaiveld 1 m zakt
const sideTerrace = new THREE.Group(); scene.add(sideTerrace);
{
  const retainMat = new THREE.MeshStandardMaterial({color:0x77726b, roughness:.95});
  const w = -0.15 - TR_X0, cx = mx((TR_X0-0.15)/2), cz = mz((D_M-0.15+0.15)/2), d = D_M+0.3;
  const bh = GRADE_DROP+0.09, blk = new THREE.Mesh(new THREE.BoxGeometry(w, bh, d), retainMat); blk.position.set(cx, -0.16-bh/2, cz); blk.receiveShadow = true; blk.castShadow = true;
  const top = new THREE.Mesh(new THREE.BoxGeometry(w, 0.04, d), stoneMat); top.position.set(cx, -0.14, cz); top.receiveShadow = true;
  sideTerrace.add(blk, top);
  // (v30) betonnen muur op het terras, in lijn met de keldermuur onder de palen (x = 10,02); AANNAME: 1,0 m hoog, 0,3 m dik; (v31) y -3,5 → -0,5 (50 cm vrij van het glas)
  const cw = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.12, 3.0), new THREE.MeshStandardMaterial({color:0x8e8b86, roughness:1}));
  cw.position.set(mx(K_X1), -0.12+0.56, mz(-2.0)); cw.castShadow = true; cw.receiveShadow = true; sideTerrace.add(cw);
}
const garden = [];
function tree(x,z,s=1){
  const g=new THREE.Group();
  const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.12*s,.16*s,1.4*s,8),new THREE.MeshStandardMaterial({color:0x5b4331}));
  trunk.position.y=.7*s;
  const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(1.2*s,1),new THREE.MeshStandardMaterial({color:0x2f5b33,flatShading:true,roughness:1}));
  crown.position.y=2*s;
  [trunk,crown].forEach(m=>{m.castShadow=true;g.add(m)});
  g.position.set(x,gradeAt(x,z),z); garden.push(g); scene.add(g);
}
// (v42) bomen volgens schets Bas: rondom langs de hekken, 10–15 m hoog (plan-x, plan-y); 'dark' = de zwarte cirkel
const TREES = [
  [39.1,1.5],[39.3,4.7],[39.3,8.5],[39.4,13.0],[39.3,16.4],[39.5,20.1],[39.3,23.3],[39.7,26.5],          // langs het linkerhek
  [35.0,26.9],[31.1,25.9],[26.5,27.4],[20.7,26.5],[15.0,26.6],[9.9,26.3],[4.5,26.5],[-1.5,26.8],         // langs het achterhek
  [-2.1,17.7],[-2.7,22.1],[-2.4,14.3,'dark'],                                                            // langs de klimop rechts
  [34.9,-8.2],[31.2,-7.9],[27.9,-8.0],[25.1,-8.1],[22.0,-7.9],[18.1,-8.1],                               // langs het voorhek (links)
  [-4.9,-8.4],                                                                                            // (v72) hoek voortuin rechts: helemaal in de hoek (voorhek × klimop)
];
{ let sd = 21; const rn = ()=>{ sd = (sd*16807) % 2147483647; return sd/2147483647; };
  const barkM = new THREE.MeshStandardMaterial({color:0x5b4331, roughness:1});
  const leafM = [0x2f5b33,0x355f2c,0x2a5230,0x3b6431].map(c=>new THREE.MeshStandardMaterial({color:c, flatShading:true, roughness:1})), darkM = new THREE.MeshStandardMaterial({color:0x1f3a24, flatShading:true, roughness:1});
  TREES.forEach(([x,y,kind])=>{
    const H = 10 + rn()*5, R = 2.2 + rn()*1.2, tH = H*0.38, cH = (H-tH)/2, g = new THREE.Group();
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.16+H*0.006, 0.24+H*0.01, tH+cH*0.4, 8), barkM); trunk.position.y = (tH+cH*0.4)/2;
    const crown = new THREE.Mesh(new THREE.IcosahedronGeometry(1,1), kind==='dark' ? darkM : leafM[Math.floor(rn()*4)]); crown.scale.set(R, cH*1.05, R*(0.9+rn()*0.2)); crown.position.y = tH + cH;
    [trunk, crown].forEach(m=>{ m.castShadow = true; g.add(m); });
    const X = mx(x), Z = mz(y); g.position.set(X, gradeAt(X,Z), Z); g.rotation.y = rn()*6.28; g.userData.tree = true; garden.push(g); scene.add(g); }); }

