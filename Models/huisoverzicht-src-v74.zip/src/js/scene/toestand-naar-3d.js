/* ---------- Toestand naar 3D ---------- */
function applyColors(){
  rooms.forEach(r=>{
    const c = colorMode==='temp' ? (r.temp!=null ? scale(TEMP_STOPS,r.temp) : NO_DATA) : colorMode==='hum' ? (r.hum!=null ? scale(HUM_STOPS,r.hum) : NO_DATA) : NEUTRAL;
    r.slabMat.color.copy(c);
    r.slabMat.emissive.set(r===selected ? 0x3a2a0a : 0x000000);
  });
  renderLegend();
}
function applyLamps(){
  lampList.forEach(l=>{
    const f = 0.2 + 0.8*Math.min(1,(l.bri ?? 255)/255), col = new THREE.Color().setRGB(...lampRGB(l).map(v=>v/255), THREE.SRGBColorSpace);
    l.bulbMat.emissive.copy(col);
    l.bulbMat.emissiveIntensity = l.on ? (l.kind==='floor' ? 1.2 : 4)*f : 0;
    if(l.light){ l.light.color.copy(col); l.light.intensity = l.on ? (night ? 7 : 2.5)*f : 0; }
    if(l.beam && l.on){ if(l.beam.material===beamMat) l.beam.material = beamMat.clone(); l.beam.material.color.copy(col); l.beam.material.opacity = 0.07*f; }
    if(l.beam) l.beam.visible = l.on && night;
    if(l.beams) l.beams.forEach(b=>b.visible = l.on && night);
  });
  rooms.forEach(r=>{
    const n = r.lampObjs.filter(l=>l.on && l.placed && l.kind!=='floor').length;
    if(r.spotLight){ const on = r.lampObjs.filter(l=>l.on && l.placed && l.kind!=='floor');
      const f = on.length ? on.reduce((s,l)=>s+0.2+0.8*Math.min(1,(l.bri ?? 255)/255),0)/on.length : 1;
      if(on.length){ const c = on.reduce((a,l)=>{ const v = lampRGB(l); return a.map((x,i)=>x+v[i]/on.length); },[0,0,0]); r.spotLight.color.setRGB(c[0]/255,c[1]/255,c[2]/255, THREE.SRGBColorSpace); }
      r.spotLight.intensity = n ? (night ? 3.5 : 1.2) * Math.sqrt(n) * f : 0; }
    const lit = r.lampObjs.some(l=>l.on) && night;
    r.glass.forEach(m=>{
      m.emissive.set(lit ? 0xffb85c : 0x000000);
      m.emissiveIntensity = lit ? 0.9 : 0;
      m.opacity = lit ? 0.55 : 0.28;
    });
  });
}
