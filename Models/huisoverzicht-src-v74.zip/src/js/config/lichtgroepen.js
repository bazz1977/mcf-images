// ===== LICHTGROEPEN — makkelijk aan te passen: naam + ruimtes (alle lampen van die ruimtes) =====
const LAMP_GROUPS = [
  {name:'Slaapkamer + dressing',             rooms:['slaap','dress']},
  {name:'Badkamer',                          rooms:['bad']},
  {name:'Hal · 4 spots',                     rooms:['hal']},
  {name:'Woonkamer + hal + keuken',          rooms:['woon','hal','keuken']},
  {name:'Badkamer + slaapkamer + dressing',  rooms:['bad','slaap','dress']},
  {name:'Lucas',                             rooms:['lucas','lucas2']},
  {name:'Jolie',                             rooms:['jolie']},
  {name:'Amélie',                            rooms:['amelie','k-dress']},
  {name:'Alle hallen (behalve de lange hal)', rooms:['hal-wc','overloop','k-hal']},
];
// ==========================================================================
