/* ---------- Kelder ---------- */
// ===== (v43) OMADA-netwerk (TP-Link Omada-integratie) =====================================
// Apparaatnamen zoals in Omada/HA. pos: [plan-x, plan-y, hoogte, verdieping (0 BG / -1 kelder / 'out' buiten), gericht]
const OMADA = { devices:[
  {name:'Router',                           model:'TL-R605',        kind:'router', room:'k-tech'},
  {name:'Switch',                           model:'TL-SG2428P',     kind:'switch', room:'k-tech'},
  {name:'AccesPoint Hal_Woonkamer',         model:'EAP245 v4',      kind:'ap', room:'hal',    pos:[5.35,5.05,2.45,0,'x+'], existing:true},   // (v62) hal tussen woonkamer en keuken
  {name:'AccesPoint Hal',                   model:'EAP245 v3',      kind:'ap', room:'trap',   pos:[1.76,1.25,2.35,0,'x+']},               // (v62) hal begane grond, tegen de wand van de dressing
  {name:'AccessPoint LP2 Technische Ruimte',model:'EAP245 v3',      kind:'ap', room:'k-tech', pos:[1.0,2.44,2.15,-1,'y-']},               // technische ruimte
  {name:'AccesPoint Kelder',                model:'EAP245 v3',      kind:'ap', room:'k-hal',  pos:[3.0,0.16,2.15,-1,'y+'], guess:true},   // AANNAME: hal kelder
  {name:'Point2Point_Master',               model:'EAP211-Bridge',  kind:'bridge', room:'buiten', pos:[0.35,-0.19,F1-0.65,'out','y-']},   // voorgevel, helemaal rechts bovenaan
  {name:'Point2Point_Slave',                model:'EAP211-Bridge',  kind:'bridge', room:'buiten', pos:[-9.5,-12.5,2.2,'out','y+']},       // overzijde, hoek tuin bij de buren
 ], ports:Array.from({length:24}, (_,i)=>({n:i+1, poe:null, w:null})), clients:0, live:false, portLeds:null };
OMADA.devices.forEach(d=>{ d.online = true; d.update = false; d.ents = []; d.clients = null; });
// demo: PoE op de poorten van de 4 AP's, bridge-master, OC200 en Bold Connect-bridge
[[1,6.8],[2,7.4],[3,6.1],[4,5.9],[5,4.2],[6,3.1],[8,1.4]].forEach(([n,w])=>{ OMADA.ports[n-1].poe = true; OMADA.ports[n-1].w = w; });
[9,10,11,12,17].forEach(n=>{ OMADA.ports[n-1].poe = false; OMADA.ports[n-1].w = 0; OMADA.ports[n-1].link = true; });
OMADA.devices.filter(d=>d.kind==='ap').forEach((d,i)=>d.clients = [9,6,3,2][i]); OMADA.clients = 23;
