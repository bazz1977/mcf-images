// ===== VEILIGHEIDSPOOL =====================================================
// Stekkers die niet zomaar uit mogen. Toevoegen/verwijderen = één regel hier.
//   'bevestigen' → aan/uit zetten kan, maar pas na OK in een melding
//   'nooit-uit'  → uitzetten kan helemaal niet vanuit dit overzicht (aanzetten wel, na OK)
// Pool-stekkers worden ALTIJD overgeslagen bij 'Alles uit'.
const VEILIGHEIDSPOOL = {
  'switch.inspelning_smart_plug_5': 'bevestigen',   // Vaatwasser (keuken)
  'switch.inspelning_smart_plug_6': 'bevestigen',   // Koelkast (keuken)
  'switch.inspelning_smart_plug_9': 'bevestigen',   // Koelkast kelder (hal kelder)
  'switch.stekker_12':              'bevestigen',   // Regenwaterpomp regenput (kelder) — zit in een HA-automatisering
  'switch.inspelning_smart_plug_3': 'nooit-uit',    // (v65) Patchkast (technische ruimte): router, switch, OC200, Hue Bridge, Home Assistant
  'switch.aquarium_2':              'nooit-uit',    // (v33) Pelletkachel woonkamer: stroom eraf tijdens branden = rook/geen afzuiging
};
// ==========================================================================
