// ---------- Kelder (zelfde maten als begane grond; woonkamer steekt 0,5 m over) ----------
const K_H = 2.5, Y_K = -0.25 - K_H - 0.1;   // vloer kelder t.o.v. vloer begane grond
const K_X1 = W_M - 0.5, TERR_D = 4.0;       // palenas / linker keldermuur; uitbouw 4 m onder terras
const K_REC = 0.3;   // (v35) kelderwand onder de woonkamer springt aan de achtergevel 30 cm naar binnen
const K_OUTER = [[0,0],[6.47,0],[6.47,-TERR_D],[K_X1,-TERR_D],[K_X1,D_M-K_REC],[0,D_M]];
const K_WALLS = [
  [1.7,0,1.7,1.65],                                     // technische ruimte (deur 1,65–2,5)
  [0,2.5,3.8,2.5],                                      // technische ruimte + trap | kamer Amélie
  [3.8,0,3.8,1.2], [3.8,1.2,4.15,1.2], [4.95,1.2,5.3,1.2], [5.3,0,5.3,1.2],  // toilet kelder (deur 4,15–4,95)
  [4.7,2.0,4.7,2.9], [4.7,3.6,4.7,4.7], [4.7,2.0,5.3,2.0], [4.7,4.7,5.3,4.7], [5.3,4.7,5.3,6.7],   // dressing Amélie (deur 2,9–3,6)
  [6.47,0,6.47,1.2], [6.47,2.0,6.47,6.7],               // kamer Lucas 2 (deur 1,2–2,0)
  [5.3,2.6,6.47,2.6], [5.3,2.0,5.3,2.6],                // hal kelder | dressing Amélie: muur 60 cm de dressing in (stopcontact koelkast)
];
// Deuren kelder: [x1,y1,x2,y2] (deuropening met blad, bovenlicht dicht tot plafond)
const K_DOORS = [
  [3.8,2.5,4.7,2.5],                                    // hal kelder → kamer Amélie
  [4.15,1.2,4.95,1.2],                                  // hal kelder → toilet kelder
];
// Kelderramen achtergevel (v28): [x van, x tot, ruimte]; onder- en bovenkant t.o.v. keldervloer
const K_WIN = [[0.55, 3.30, 'amelie'], [6.87, 9.62, 'lucas2']], KW_B = 1.65, KW_T = 2.45;
const PILLARS = [0.3, 3.9, 6.4];            // ronde palen woonkamer op de as van de linker keldermuur
rooms.push(
  {id:'k-tech',   name:'Technische ruimte', floor:-1, rects:[[0,0,1.7,2.5]],
    t:'sensor.temp_hum_temperatuur', h:'sensor.temp_hum_luchtvochtigheid', temp:17.2, hum:58, tech:true,
    lamps:[[0.95,1.25,'TL-lamp',false,'tl',null]]},
  {id:'k-hal',    name:'Hal kelder', floor:-1, rects:[[3.8,1.2,5.3,2.0],[1.7,0,3.8,2.5],[3.8,2.0,4.7,2.5],[5.3,0,6.47,2.6]], hole:false,
    t:'sensor.motion_hal_beneden_temperatuur', temp:16.4,
    sensor:{ha:'binary_sensor.motion_hal_beneden_beweging', luxHa:'sensor.motion_hal_beneden_licht', motion:false, lux:3},
    lamps:[[4.45,1.5,'Lamp 1',false,'spot','light.hal_kelder_1'],[4.45,2.2,'Lamp 2',false,'spot',null]]},
  {id:'k-toilet', name:'Toilet kelder', floor:-1, rects:[[3.8,0,5.3,1.2]],
    lamps:[[null,null,'Toilet kelder',false,'unplaced','light.toilet_kelder']]},
  {id:'amelie',   name:'Kamer Amélie', floor:-1, rects:[[0,2.5,4.7,6.7],[4.7,4.7,5.3,6.7]],
    t:'sensor.timmerflotte_temp_hmd_sensor_temperatuur', h:'sensor.timmerflotte_temp_hmd_sensor_luchtvochtigheid', clim:'climate.airco_amelie', temp:19.1, hum:54, target:19,
    lamps:[[0.4,2.85,'Bed links',false,'pendant','light.bed_links'],[0.4,5.95,'Bed rechts',true,'pendant','light.bed_rechts'],[3.35,5.95,'Vloer',false,'pendant','light.hue_ambiance_lamp_1'],[4.25,2.85,'Deur',false,'pendant','light.deur']]},
  {id:'k-dress',  name:'Dressing Amélie', floor:-1, rects:[[4.7,2.6,6.47,4.7],[4.7,2.0,5.3,2.6],[5.3,4.7,6.47,6.7]], lamps:[]},
  {id:'lucas2',   name:'Kamer Lucas 2', floor:-1, rects:[[6.47,-TERR_D,K_X1,D_M-K_REC]], clim:'climate.airco_lucas', temp:18.2, target:19, lamps:[]},
);
const FLOOR_NAME = {'-1':'Kelder', 0:'Begane grond', 1:'Verdieping'};
const floorY = f => f===1 ? F1 : f===-1 ? Y_K : 0;
