// ===== (v45) DATAVERKEER (overlay): Starlink → ER605 → switch → AP's / bridge / vaste UTP; kleur en snelheid volgen de belasting =====
const netGroup = new THREE.Group(); netGroup.visible = false; scene.add(netGroup);
let showNet = false;
const NET_COL = t => new THREE.Color(0x3fa7ff).lerp(new THREE.Color(0xffc46b), Math.min(1,t*2)).lerp(new THREE.Color(0xff4d3d), Math.max(0,t*2-1));
function mkNet(pts, cap){
  const curve = ortho(pts);
  const lineMat = new THREE.MeshBasicMaterial({color:0x3fa7ff, transparent:true, opacity:.3, depthTest:false});
  const line = new THREE.Mesh(new THREE.TubeGeometry(curve, 260, 0.02, 6, false), lineMat); line.renderOrder = 22; netGroup.add(line);
  const dotMat = new THREE.MeshBasicMaterial({color:0x3fa7ff, depthTest:false, transparent:true});
  const dots = Array.from({length:14}, ()=>{ const m = new THREE.Mesh(new THREE.SphereGeometry(.06,8,6), dotMat); m.renderOrder = 23; netGroup.add(m); return m; });
  const upMat = new THREE.MeshBasicMaterial({color:0x7dffb0, depthTest:false, transparent:true});   // (v67) upload: groene bolletjes terug naar de switch
  const upDots = Array.from({length:7}, ()=>{ const m = new THREE.Mesh(new THREE.SphereGeometry(.045,8,6), upMat); m.renderOrder = 23; m.visible = false; netGroup.add(m); return m; });
  return {curve, line, lineMat, dotMat, dots, upDots, upT:0, upSpeed:0, t:0, speed:0, cap, mbit:0};
}
const NP = { dish:V(STARLINK_DISH[0], FR+0.55, STARLINK_DISH[1]), slr:V(STARLINK[0], F1+0.25, STARLINK[1]), er:V(1.38, Y_K+1.55, 0.66), sw:V(1.38, Y_K+1.22, 0.68) };
const apPos = n => { const d = OMADA.devices.find(x=>x.name===n); if(!d || !d.pos) return null; const [x,y,h,fl] = d.pos; return fl==='out' ? V(x, h, y) : V(x, (fl===-1 ? Y_K : 0) + h, y); };
const slavePos = ()=>{ const d = OMADA.devices.find(x=>x.name==='Point2Point_Slave'); const [x,y,h] = d.pos; return V(x, gradeAt(mx(x),mz(y))+h, y); };
// UTP vanaf de switch: omhoog naar het kelderplafond, langs het plafond tot onder het apparaat, dan recht omhoog (in de muur)
const fromSw = (x,y,end, via=KC)=> [NP.sw, V(1.38,via,0.68), V(x,via,0.68), V(x,via,y), end];
const KG = Y_K+2.3;    // kabelgoot in de kelder (op 2,30 m)
const NETF = {
  wan:   mkNet([NP.dish, V(STARLINK_DISH[0],FR+0.08,STARLINK_DISH[1]), V(STARLINK_DISH[0],FR+0.08,6.3), V(6.3,FR+0.08,6.3), V(6.3,F1+0.25,6.3), NP.slr], 250),
  utp:   mkNet([NP.slr, V(6.3,F1+0.25,6.3), V(6.3,F1+0.05,6.3), V(6.3,KC,6.3), V(6.3,KC,0.66), V(1.38,KC,0.66), NP.er], 250),
  sw:    mkNet([NP.er, NP.sw], 250),
  apHal: mkNet(fromSw(5.35,5.05, apPos('AccesPoint Hal_Woonkamer')), 120),
  apTrap:mkNet(fromSw(1.76,1.25, apPos('AccesPoint Hal')), 120),
  lucas: mkNet([apPos('AccesPoint Hal_Woonkamer'), V(5.35,2.72,5.05), V(5.35,F1-0.08,5.05), V(5.35,F1-0.08,5.6), V(5.35,F1+0.3,5.6)], 100),   // (v62) UTP van het AP naar de kamer van Lucas
  apTech:mkNet(fromSw(1.0,2.44, apPos('AccessPoint LP2 Technische Ruimte'), KG), 120),
  apKel: mkNet(fromSw(3.0,0.16, apPos('AccesPoint Kelder'), KG), 120),
  p2p:   mkNet([...fromSw(0.35,0.12, V(0.35,2.4,0.12)), apPos('Point2Point_Master')], 100),
  air:   mkNet([apPos('Point2Point_Master'), FREE(slavePos())], 100),
  woon:  mkNet(fromSw(6.55,0.35, V(6.55,0.55,0.35)), 100),   // vaste UTP: Apple TV, PS5, Sony
};
const NET_AP = {apHal:'AccesPoint Hal_Woonkamer', apTrap:'AccesPoint Hal', apTech:'AccessPoint LP2 Technische Ruimte', apKel:'AccesPoint Kelder', p2p:'Point2Point_Master', air:'Point2Point_Master'};
const netLabels = {};
function initNetLabels(){ if(Object.keys(netLabels).length) return;
[['wan',NP.dish],['sw',NP.sw],['apHal',apPos('AccesPoint Hal_Woonkamer')],['apTrap',apPos('AccesPoint Hal')],['lucas',V(5.35,F1+0.3,5.6)],['apTech',apPos('AccessPoint LP2 Technische Ruimte')],['apKel',apPos('AccesPoint Kelder')],['air',slavePos()],['woon',V(6.55,0.9,0.35)]]
  .forEach(([k,pos])=>{ const el = document.createElement('div'); el.className = 'label nlabel'; labelsEl.appendChild(el); netLabels[k] = {el, pos:pos.clone().add(new THREE.Vector3(0,.45,0))}; }); }
// (v65) geen doorvoer beschikbaar (de standaard Omada-integratie levert geen Mbit/s per AP): toon status, clients en CPU
function apInfo(k){ const n = NET_AP[k]; if(!n) return '–'; const d = OMADA.devices.find(x=>x.name===n); if(!d) return '–';
  if(d.online===false) return '<span style="color:var(--warn)">offline</span>';
  const bits = [d.clients!=null ? d.clients+' client'+(d.clients===1?'':'s') : null, d.cpu!=null ? 'CPU '+Math.round(d.cpu)+'%' : null].filter(Boolean);
  return bits.length ? bits.join(' · ') : (d.ents && d.ents.length ? 'online' : '–'); }
function fmtMb(v){ return v==null ? '–' : v >= 100 ? Math.round(v)+' Mbit/s' : fmt(v,1)+' Mbit/s'; }
function netLoad(){                            // Mbit/s per verbinding: live uit HA waar beschikbaar, anders een schatting uit het aantal clients
  const wan = (OMADA.wan && OMADA.wan.rx!=null) ? OMADA.wan.rx + (OMADA.wan.tx||0) : (starlink.down!=null ? (LIVE ? (starlink.down||0)+(starlink.up||0) : (starlink.down*0.35 + (starlink.up||0))) : null);
  const aps = {}; let sum = 0;
  Object.entries(NET_AP).forEach(([k,n])=>{ const d = OMADA.devices.find(x=>x.name===n); if(!d) return;
    let v = (d.rx!=null || d.tx!=null) ? (d.rx||0)+(d.tx||0) : null, up = d.rx!=null || d.tx!=null ? (d.tx||0) : null;
    if(v==null && !LIVE){ v = (d.clients||1) * (2 + 3*Math.abs(Math.sin(performance.now()/7000 + k.length))); up = v*0.2; }
    aps[k] = v; if(NETF[k]){ NETF[k].up = up; NETF[k].down = v==null ? null : v-(up||0); } if(v!=null && k!=='air') sum += v; });
  const woon = LIVE ? (OMADA.wired ?? null) : (mediaOn(MEDIA.tv) ? 18 : 0.5) + (mediaOn(MEDIA.ps5) ? 25 : 0);
  const lucas = LIVE ? null : 6 + 4*Math.abs(Math.sin(performance.now()/9000));
  return {wan, sw:wan, utp:wan, woon, lucas, ...aps};
}
function renderNetFlows(){
  initNetLabels();
  const L = netLoad();
  Object.entries(NETF).forEach(([k,f])=>{
    const v = L[k], t = v==null ? 0 : Math.min(1, v / f.cap); f.mbit = v;
    const c = NET_COL(t); f.lineMat.color.copy(c); f.dotMat.color.copy(c); f.lineMat.opacity = v==null ? .12 : .25 + .45*t;
    f.speed = v==null || v < 0.05 ? 0 : 0.15 + 0.9*Math.sqrt(t); f.dots.forEach(d=>d.visible = f.speed>0);
    f.upSpeed = f.up==null || f.up < 0.05 ? 0 : 0.15 + 0.9*Math.sqrt(Math.min(1, f.up/f.cap)); f.upDots.forEach(d=>d.visible = f.upSpeed>0 && f.sel);
    f.line.scale.setScalar(1);
  });
  const lab = (k,name)=>{ const o = netLabels[k]; if(!o) return; const f = NETF[k]; o.el.innerHTML = `<b>${name}</b><span class="t">${f.mbit==null ? apInfo(k) : f.up!=null && NET_AP[k] ? '↓ '+fmtMb(f.down)+' <span style="color:#7dffb0">↑ '+fmtMb(f.up)+'</span>' : fmtMb(f.mbit)}</span>`; o.el.style.borderColor = '#'+NET_COL(f.mbit==null?0:Math.min(1,f.mbit/f.cap)).getHexString(); };
  lab('wan','Starlink'); lab('sw','Switch · totaal'); lab('apHal','AP hal/woonkamer'); lab('apTrap','AP hal'); lab('lucas','UTP kamer Lucas'); lab('apTech','AP techn. ruimte'); lab('apKel','AP kelder'); lab('air','Straalverbinding'); lab('woon','Vaste UTP woonkamer');
}
function netTick(dt){
  if(!netGroup.visible) return;
  Object.values(NETF).forEach(f=>{ if(!f.sel){ f.dots.forEach(d=>d.visible = false); f.upDots.forEach(d=>d.visible = false); return; }
    if(f.upSpeed){ f.upT = (f.upT - dt*f.upSpeed*0.4 + 1) % 1; f.upDots.forEach((d,i)=>{ d.visible = true; d.position.copy(f.curve.getPointAt((f.upT + (i+0.5)/f.upDots.length) % 1)); }); }
    if(!f.speed) return; f.t = (f.t + dt*f.speed*0.4) % 1; f.dots.forEach((d,i)=>{ d.visible = true; d.position.copy(f.curve.getPointAt((f.t + i/f.dots.length) % 1)); }); });
}
setInterval(()=>{ if(showNet) renderNetFlows(); }, 2000);
function flowTick(dt){
  if(!flowGroup.visible) return;
  Object.values(FLOWS).forEach(f=>{ if(!f.sel){ f.dots.forEach(d=>d.visible = false); return; } if(!f.speed) return; f.t = (f.t + dt*f.speed*0.35*f.dir + 1) % 1;
    f.dots.forEach((d,i)=>{ d.visible = true; const u = (f.t + i/f.dots.length) % 1; d.position.copy(f.curve.getPointAt(u)); }); });
}

