// ===== (v41) BUITEN: temperatuur + wind, nu en voorspelling (volgt de tijdschuif) =====
const WX = {ent:null, unit:'km/h', now:{wind:14, bearing:235}, hourly:[], live:false};
const BFT_KMH = [1,6,12,20,29,39,50,62,75,89,103,118];
const toKmh = (v,u)=> v==null ? null : u==='m/s' ? v*3.6 : u==='mph' ? v*1.609 : u==='kn' ? v*1.852 : v;
const bft = kmh => kmh==null ? null : BFT_KMH.findIndex(t=>kmh < t) === -1 ? 12 : BFT_KMH.findIndex(t=>kmh < t);
const WIND_NL = ['N','NNO','NO','ONO','O','OZO','ZO','ZZO','Z','ZZW','ZW','WZW','W','WNW','NW','NNW'];
const windDir = b => b==null ? '' : WIND_NL[Math.round(((+b%360)+360)%360/22.5)%16];
// demo: aannemelijke 48 u-voorspelling vanaf vandaag 00:00 (dagcurve temperatuur, wind 2–5 Bft uit het ZW)
(function demoForecast(){ const t0 = new Date(); t0.setHours(0,0,0,0);
  for(let h=0; h<48; h++){ const hr = h%24, d = Math.floor(h/24);
    WX.hourly.push({t: t0.getTime()+h*3600e3, temp: 12.5 + d*0.8 + 4.5*Math.sin((hr-9)/24*Math.PI*2) + Math.sin(h*1.7)*0.4,
      wind: 12 + 8*Math.sin((h-4)/24*Math.PI*2 - 0.6) + 5*Math.sin(h*0.45) + d*4, bearing: 225 + 25*Math.sin(h/9), cloud: 0.25 + 0.35*(0.5+0.5*Math.sin(h/7)) }); } })();
function simDate(){ const d = new Date(); if(sky.simMin!=null){ d.setHours(0,0,0,0); d.setMinutes(sky.simMin); } return d; }
function wxAt(date){
  const H = WX.hourly, t = date.getTime();
  if(!H.length) return null;
  if(t <= H[0].t) return {...H[0], exact: Math.abs(t-H[0].t) < 3600e3};
  for(let i=1;i<H.length;i++) if(t <= H[i].t){ const a = H[i-1], b = H[i], f = (t-a.t)/(b.t-a.t), L = (x,y)=> x==null ? y : y==null ? x : x+(y-x)*f;
    return {t, temp:L(a.temp,b.temp), wind:L(a.wind,b.wind), bearing: f<0.5 ? a.bearing : b.bearing, cloud:L(a.cloud,b.cloud), exact:true}; }
  return {...H[H.length-1], exact:false};
}
// wat staat er op het buitenlabel: nu (sensoren) of het gekozen tijdstip (voorspelling)
function outsideNow(){
  const sim = sky.simMin!=null, f = wxAt(simDate());
  if(!sim || !f){ const w = LIVE && WX.live ? toKmh(WX.now.wind, WX.unit) : (f ? f.wind : WX.now.wind); return {temp:outside.temp, hum:outside.hum, wind:w, bearing: LIVE && WX.live ? WX.now.bearing : (f ? f.bearing : WX.now.bearing), fc:false}; }
  return {temp:f.temp, hum:null, wind: LIVE ? toKmh(f.wind, WX.unit) : f.wind, bearing:f.bearing, fc:true};
}
function windHTML(o){ if(o.wind==null) return ''; const b = bft(o.wind); return `<span>wind ${b} Bft${o.bearing!=null?' '+windDir(o.bearing):''}</span>`; }
function labelHTML(name,t,h,w){
  const bits=[];
  if(lbl.parts.temp && t!=null) bits.push(`<span class="t">${fmt(t)} °C</span>`);
  if(lbl.parts.hum && h!=null) bits.push(`<span>${Math.round(h)}%</span>`);
  if(lbl.parts.power && w!=null) bits.push(`<span style="color:var(--lamp)">${fmtW(w)}</span>`);
  return (lbl.parts.name?`<b>${name}</b>`:'') + bits.join(' <span>·</span> ');
}
function updateLabels(){
  rooms.forEach(r=>{
    const warn = r.hum!=null && r.hum>=65;
    r.labelEl.className = 'label' + (r===selected?' sel':'') + (warn?' warn':'');
    r.labelEl.innerHTML = labelHTML(r.name, r.temp, r.hum, roomW(r)); r.labelEmpty = !r.labelEl.innerHTML;
  });
  { const o = outsideNow(), hh = String(Math.floor((sky.simMin||0)/60)).padStart(2,'0')+':'+String((sky.simMin||0)%60).padStart(2,'0');
    outLabel.innerHTML = labelHTML(o.fc ? 'Buiten · '+hh+' (verwachting)' : 'Buiten', o.temp, o.hum) + (lbl.parts.temp || lbl.parts.hum ? ' <span>·</span> ' : '') + windHTML(o); }
}
function renderLblPanel(){
  const el = $('lblpanel');
  const cb = (key, checked, text, cls='') => `<label class="${cls}"><input type="checkbox" data-k="${key}" ${checked?'checked':''}> ${text}</label>`;
  let h = `<div class="grp master-grp">${cb('all', lbl.all, 'Alle labels tonen', 'master')}</div>`;
  h += `<div class="grp"><h3>Wat staat erop</h3>${cb('p:name',lbl.parts.name,'Naam')}${cb('p:temp',lbl.parts.temp,'Temperatuur')}${cb('p:hum',lbl.parts.hum,'Luchtvochtigheid')}${cb('p:power',lbl.parts.power,'Verbruik stekkers')}${cb('outside',lbl.outside,'Buitensensor')}${cb('gevels',lbl.gevels,'Gevelnamen')}${cb('kompas',lbl.kompas,'Windrichtingen')}</div>`;
  h += `<div class="grp"><h3>Per ruimte</h3><div class="row2"><button class="mini" data-bulk="1">Alles aan</button><button class="mini" data-bulk="0">Alles uit</button></div>`;
  [0,1,-1].forEach(f=>{
    h += cb('f:'+f, lbl.floors[f], FLOOR_NAME[f]);
    rooms.filter(r=>r.floor===f).forEach(r=> h += cb('r:'+r.id, roomOn(r), r.name, 'sub'));
  });
  h += `</div>`;
  el.innerHTML = h;
  el.classList.toggle('off', !lbl.all);
  $('lblbtn').setAttribute('aria-pressed', String(lbl.all));
}
function onLblChange(e){
  const k = e.target.dataset.k; if(!k) return; const v = e.target.checked;
  if(k==='all') lbl.all = v;
  else if(k==='outside') lbl.outside = v;
  else if(k==='gevels') lbl.gevels = v;
  else if(k==='kompas') lbl.kompas = v;
  else if(k.startsWith('p:')) lbl.parts[k.slice(2)] = v;
  else if(k.startsWith('f:')){ const f = k.slice(2); lbl.floors[f] = v; rooms.filter(r=>String(r.floor)===f).forEach(r=>lbl.rooms[r.id]=v); }
  else if(k.startsWith('r:')){ const r = byId[k.slice(2)]; lbl.rooms[r.id] = v; if(v) lbl.floors[r.floor] = true; }
  if(k!=='all' && v) lbl.all = true;
  saveLbl(); renderLblPanel(); updateLabels();
}
const v3 = new THREE.Vector3(), tmp = new THREE.Vector3();
function placeLabel(el, pos, show){
  if(!show){ el.style.display='none'; return; }
  v3.copy(pos).project(camera);
  if(v3.z>1){ el.style.display='none'; return; }
  el.style.display='';
  el.style.left = ((v3.x+1)/2*stage.clientWidth)+'px';
  el.style.top  = ((1-v3.y)/2*stage.clientHeight)+'px';
}
function positionLabels(){
  const on = lbl.all && anyPart();
  rooms.forEach(r=> placeLabel(r.labelEl, tmp.set(r.cx, floorY(r.floor)+1.25, r.cz), on && !r.labelEmpty && mode===r.floor && lbl.floors[r.floor] && roomOn(r)));
  placeLabel(outLabel, OUT_POS, on && lbl.outside);
  KOMPAS.forEach(k=> placeLabel(k.el, k.pos, lbl.all && lbl.kompas!==false && mode!==-1));
  GEVELS.forEach(g=> placeLabel(g.el, g.pos, lbl.all && lbl.gevels!==false && mode!==-1 && (camera.position.x*g.n[0] + camera.position.z*g.n[1]) > (g.n[0] ? W_M/2 : D_M/2)));   // alleen gevels die naar je toe staan
  Object.entries(eLabels).forEach(([k,el])=> placeLabel(el, ENODES[k], showEnergy && eLabelOn(k)));
  regenLabels();
  if(typeof netLabels!=='undefined') Object.entries(netLabels).forEach(([k,o])=> placeLabel(o.el, o.pos, showNet && nLabelOn(k)));
}

