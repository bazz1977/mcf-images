/* ---------- Energiestromen (overlay) ---------- */
const flowGroup = new THREE.Group(); flowGroup.visible = false; scene.add(flowGroup);
const V = (x,h,y)=> new THREE.Vector3(mx(x), h, mz(y));
// (v47) kabels in rechte stukken met haakse hoeken (zoals kabelgoten): lijn door de opgegeven punten; ortho() voegt tussenpunten toe zodat elk stuk langs één as loopt (eerst verticaal, dan x, dan y)
function ortho(pts){
  const P = [pts[0].clone()];
  for(let i=1;i<pts.length;i++){ const a = P[P.length-1], b = pts[i];
    const n = [a.x!==b.x, a.y!==b.y, a.z!==b.z].filter(Boolean).length;
    if(n > 1 && !b.userData_free){ const q1 = new THREE.Vector3(a.x, b.y, a.z), q2 = new THREE.Vector3(b.x, b.y, a.z); [q1,q2].forEach(q=>{ if(!q.equals(P[P.length-1])) P.push(q); }); }
    if(!b.equals(P[P.length-1])) P.push(b.clone()); }
  const cp = new THREE.CurvePath(); for(let i=1;i<P.length;i++) cp.add(new THREE.LineCurve3(P[i-1], P[i])); return cp;
}
const FREE = v => { v.userData_free = true; return v; };   // draadloos: rechte lijn door de lucht
function mkFlow(pts, color){
  const curve = ortho(pts);
  const line = new THREE.Mesh(new THREE.TubeGeometry(curve, 260, 0.022, 6, false), new THREE.MeshBasicMaterial({color, transparent:true, opacity:.28, depthTest:false}));
  line.renderOrder = 20; flowGroup.add(line);
  const dots = Array.from({length:12}, ()=>{ const m = new THREE.Mesh(new THREE.SphereGeometry(.075,10,8), new THREE.MeshBasicMaterial({color, depthTest:false, transparent:true})); m.renderOrder = 21; flowGroup.add(m); return m; });
  return {curve, line, dots, t:0, speed:0, dir:1};
}
const sPt = (x, sv)=> V(x, F1 + KNEE + Math.sin(aF)*sv + 0.35, Math.cos(aF)*sv);
const P_GW = V(0.36, Y_K+1.65, 0.74), P_BYD = V(0.45, Y_K+1.0, 0.74), P_MK = V(0.6, Y_K+1.35, 0.33);
const KC = -0.45, BGC = 2.72;             // kabelgoot: plafond kelder / plafond begane grond
const pvP = sPt(3.5,1.9);
const FLOWS = {
  // zonnepanelen schuin dak: over het dakvlak naar de rechtergevel, in de gevel omlaag tot de omvormer
  pv1:  mkFlow([pvP, V(0.2, pvP.y, pvP.z + D_M/2), V(0.2, KC, pvP.z + D_M/2), V(0.2, KC, 0.74), V(0.36, KC, 0.74), P_GW], 0xffc46b),
  // zonnepanelen plat dak: over de roofing naar de hal-muur, omlaag, langs het kelderplafond naar de omvormer
  pv2:  mkFlow([V(8.2,FR+0.12,3.3), V(8.2,FR+0.12,0.25), V(6.35,FR+0.12,0.25), V(6.35,KC,0.25), V(0.4,KC,0.25), P_GW], 0xffc46b),
  batt: mkFlow([P_GW, V(0.45,Y_K+1.65,0.74), P_BYD], 0x8fd17a),
  house:mkFlow([P_GW, V(0.36,KC,0.74), V(0.4,KC,0.74), V(0.4,KC,0.9), V(8.3,KC,0.9), V(8.3,KC,3.4), V(8.3,1.4,3.4)], 0xf2efe6),
  hp:   mkFlow([P_GW, V(0.36,KC,0.74), V(4.6,KC,0.74), V(4.6,KC,-0.05), V(4.6,-0.6,-0.05), V(4.6,-0.6,-0.45), V(4.6,0.35,-0.45)], 0xff8a3d),   // (v63) stroom naar de Weheat-buitenunit
  grid: mkFlow([P_MK, V(0.6,Y_K+1.35,-0.3), V(0.6,-0.7,-0.3), V(2.2,-0.7,-0.3), V(2.2,-0.7,-9.6), V(2.2,0.05,-9.6)], 0x7fb6ff),   // ondergrondse kabel naar de straat
};
const gridMast = box(0.12, 1.4, 0.12, new THREE.MeshStandardMaterial({color:0x5b5f63}), mx(2.2), -0.2, mz(-9.6)); flowGroup.add(gridMast);   // (v72) in de berm, niet meer op het terras
const ENODES = {hp:V(4.6,1.2,-0.62),pv:sPt(3.5,1.9).add(new THREE.Vector3(0,.35,0)), batt:P_BYD.clone().add(new THREE.Vector3(0,.5,0)), house:V(8.3,1.9,3.4), grid:V(2.2,1.5,-9.6)};
function setFlow(f, watt, forward){
  f.speed = watt>30 ? Math.min(1.1, 0.18 + Math.sqrt(watt)/60) : 0; f.dir = forward ? 1 : -1;
  f.line.material.opacity = f.speed ? .35 : .1;
  f.dots.forEach(d=>d.visible = f.speed>0);
}
