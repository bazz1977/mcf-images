/* ---------- Live: Home Assistant ---------- */
// Werkt automatisch wanneer dit bestand vanuit Home Assistant wordt geopend (/local/...).
const ENT = {
  pv:'sensor.pv_power', batt:'sensor.battery_state_of_charge', out:null,   // buitentemperatuur: automatisch gezocht (Flint LP9, anders weather.*) — P40 is van de buren
  starOk:'binary_sensor.starlink_connectiviteit', ping:'sensor.starlink_ping', down:'sensor.starlink_downlink_doorvoer', up:'sensor.starlink_uplink_doorvoer',
  sun:'sun.sun', battW:'sensor.battery_power', house:'sensor.house_consumption', grid:'sensor.p1_meter_vermogen',
  pvToday:'sensor.today_s_pv_generation', impToday:'sensor.today_energy_import', expToday:'sensor.today_energy_export',
};
const CLIM_NL = {off:'uit', cool:'koelen', heat:'verwarmen', heat_cool:'auto', auto:'auto', dry:'drogen', fan_only:'ventilator'};
let ha = null;
function setConn(txt, ok){ const el = $('connstate'); if(el){ el.textContent = txt; el.className = 'conn' + (ok===true?' ok':ok===false?' bad':''); } }

const idx = new Map();
const on = (id, fn)=>{ if(!id) return; if(!idx.has(id)) idx.set(id, []); idx.get(id).push(fn); };
const num = st => { const v = parseFloat(st.state); return isFinite(v) ? v : null; };
function buildIndex(){
  lampList.forEach(l=> on(l.ha, st=>{
    const bad = st.state==='unavailable' || st.state==='unknown';
    if(l.status!=='nc'){ l.nc = bad; l.status = bad ? 'unavail' : null; }
    l.on = st.state==='on';
    const a = st.attributes||{};
    if(a.supported_color_modes) l.modes = a.supported_color_modes;
    if(l.on){ if(a.brightness!=null) l.bri = a.brightness; l.cmode = a.color_mode || l.cmode;
      if(a.rgb_color) l.rgb = a.rgb_color; if(a.color_temp_kelvin) l.kelvin = a.color_temp_kelvin; }
  }));
  rooms.forEach(r=>{
    if(r.t) on(r.t, st=>{ r.temp = num(st); });
    if(r.h) on(r.h, st=>{ r.hum = num(st); });
    if(r.clim) on(r.clim, st=>{ const a = st.attributes||{};
      if(!r.t) r.temp = a.current_temperature ?? null;
      r.target = a.temperature ?? r.target; r.climState = st.state; });
    if(r.sensor){
      on(r.sensor.ha, st=>{ r.sensor.motion = st.state==='on'; if(r.sensor.motion) r.sensor.lastMotion = Date.now(); if(r.sensor.ledMat) r.sensor.ledMat.emissiveIntensity = r.sensor.motion ? 2 : 0; });
      on(r.sensor.luxHa, st=>{ r.sensor.lux = num(st); });
    }
  });
  on(ENT.pv,   st=>{ const v = num(st); energy.pv = v==null ? null : Math.max(0, v/1000); });
  on(ENT.batt, st=>{ energy.batt = num(st); });
  on(ENT.out,  st=>{ outside.temp = num(st); });
  on(ENT.starOk, st=>{ starlink.ok = st.state==='on'; });
  on(ENT.ping, st=>{ starlink.ping = num(st); });
  on(ENT.down, st=>{ starlink.down = num(st); });
  on(ENT.up,   st=>{ starlink.up = num(st); });
  Object.values(HP).forEach(u=>['status','pin','pout','cop','tin','tout','comp','target','sww','swwLow'].forEach(k=>{ if(u[k]) on(u[k], st=>{ u.v[k] = k==='status' ? st.state : num(st); }); }));
  on(LEAK.ent, st=>{ LEAK.on = st.state==='on'; });
  ['battW','house','grid','pvToday','impToday','expToday'].forEach(k=> on(ENT[k], st=>{ energy[k] = num(st); }));
  rooms.forEach(r=>{
    r.plugs.forEach(p=>{ on(p.sw, st=>{ p.on = st.state==='on'; }); on(p.pw, st=>{ p.w = num(st); }); });
    if(r.ac){ on(r.ac.kwhEnt, st=>{ const v = num(st); r.ac.kwh = v==null ? null : v/1000; });
      on(r.clim, st=>{ const m = (st.attributes||{}).hvac_modes; if(Array.isArray(m) && m.length) r.acModes = m; }); }
    if(r.lampKwhEnt) on(r.lampKwhEnt, st=>{ r.lampKwh = num(st); });
  });
  on(ENT.sun,  st=>{ const a = st.attributes||{}; if(a.elevation!=null && a.azimuth!=null){ sky.elev = +a.elevation; sky.az = +a.azimuth; sky.liveSun = true; } updateSky(); });   // (v38) stand van de zon uit Home Assistant
}
function applyState(id, st){ const fns = idx.get(id); if(!fns) return; fns.forEach(f=>f(st)); refreshSoon(); }
let refreshT = null;
function refreshSoon(){
  if(refreshT) return;
  refreshT = setTimeout(()=>{ refreshT = null;
    lampList.forEach(l=>{ if(l.nc) l.on = false; });
    trackAppliances(); checkTap(); applyLamps(); applyPV(); applyAC(); applyPlugs(); applyHP(); applyColors(); updateLabels(); renderPanel();
    if(battBar) battBar.scale.y = Math.max(0.03, (energy.batt||0)/100);
    if(goodweLed) goodweLed.material.emissiveIntensity = energy.pv>0 ? 1.5 : 0.2;
  }, 150);
}

async function getToken(){
  // 1) je bestaande Home Assistant-login (werkt als "Ingelogd blijven" aan staat)
  try{
    const t = JSON.parse(localStorage.getItem('hassTokens')||'null');
    if(t && t.access_token){
      if(t.expires && Date.now() < t.expires - 60000) return t.access_token;
      if(t.refresh_token){
        const body = new URLSearchParams({grant_type:'refresh_token', client_id: t.clientId || (location.origin + '/'), refresh_token: t.refresh_token});
        const res = await fetch('/auth/token', {method:'POST', body});
        if(res.ok){ const j = await res.json(); if(j.access_token) return j.access_token; }
      }
    }
  }catch(e){}
  // 2) een zelf ingesteld langlevend token (alleen op dit apparaat bewaard)
  try{ const t = localStorage.getItem('huis-ha-token'); if(t) return t; }catch(e){}
  return null;
}
function showTokenForm(){
  if($('tokenbox')) return;
  const f = document.createElement('form'); f.id = 'tokenbox'; f.className = 'tokenbox';
  f.innerHTML = `<b>Verbinden met Home Assistant</b>
    <p>Je Home Assistant-login kon niet worden overgenomen. Maak een token aan: klik linksonder op je naam → tabblad <b>Beveiliging</b> → <b>Langlevende toegangstokens</b> → Token aanmaken. Plak het hieronder. Het wordt alleen op dit apparaat bewaard.</p>
    <input id="tokeninp" type="password" placeholder="Token plakken" autocomplete="off">
    <button class="chipbtn" type="submit">Verbinden</button>`;
  f.addEventListener('submit', e=>{ e.preventDefault(); const v = $('tokeninp').value.trim(); if(!v) return;
    try{ localStorage.setItem('huis-ha-token', v); }catch(_){}
    f.remove(); connect(); });
  stage.appendChild(f);
}

let retry = 1000;
async function connect(){
  setConn('Verbinden met Home Assistant…');
  const token = await getToken();
  if(!token){ setConn('Token nodig om te verbinden', false); showTokenForm(); return; }
  const ws = new WebSocket((location.protocol==='https:' ? 'wss://' : 'ws://') + location.host + '/api/websocket');
  let nextId = 1; const pending = new Map(); let authFailed = false;
  const send = msg => new Promise((res, rej)=>{ const id = nextId++; pending.set(id, {res, rej}); ws.send(JSON.stringify({id, ...msg})); });
  ws.onmessage = async e=>{
    const m = JSON.parse(e.data);
    if(m.type==='auth_required') ws.send(JSON.stringify({type:'auth', access_token: token}));
    else if(m.type==='auth_invalid'){ authFailed = true; try{ localStorage.removeItem('huis-ha-token'); }catch(_){}
      setConn('Inloggen mislukt', false); showTokenForm(); ws.close(); }
    else if(m.type==='auth_ok'){
      retry = 1000;
      ha = { send, call:(domain, service, data)=> send({type:'call_service', domain, service, service_data:data}) };
      setConn('Live · Home Assistant', true);
      try{
        const states = await send({type:'get_states'});
        let reg = null; try{ reg = await Promise.race([send({type:'config/entity_registry/list'}), new Promise(r=>setTimeout(()=>r(null),3000))]); }catch(_){}   // welke integratie hoort bij welke entity
        detectMedia(states, reg); detectOutside(states); detectWeather(states); detectLock(states); detectStove(states); detectAmbilight(states);
        try{ const dreg = await Promise.race([send({type:'config/device_registry/list'}), new Promise(r=>setTimeout(()=>r(null),3000))]); detectOmada(states, reg, dreg); }catch(e){ console.warn('omada', e); }
        Object.keys(BATTS).forEach(k=>delete BATTS[k]);
        states.filter(st=>/^sensor\..*_batterij$/.test(st.entity_id) && (st.attributes||{}).unit_of_measurement==='%').forEach(st=>{
          const n = ((st.attributes||{}).friendly_name||st.entity_id).replace(/\s*Batterij$/i,''); BATTS[n] = num(st); on(st.entity_id, s2=>{ BATTS[n] = num(s2); }); });
        states.forEach(st=>applyState(st.entity_id, st));
        await send({type:'subscribe_events', event_type:'state_changed'});
        loadHistory(selected);
      }catch(err){ console.warn('HA', err); }
    }
    else if(m.type==='result'){ const p = pending.get(m.id); if(p){ pending.delete(m.id); m.success ? p.res(m.result) : p.rej(m.error); } }
    else if(m.type==='event'){ const ev = m.event; if(ev && ev.event_type==='state_changed' && ev.data && ev.data.new_state) applyState(ev.data.entity_id, ev.data.new_state); }
  };
  ws.onclose = ()=>{ ha = null; if(authFailed) return;
    setConn('Verbinding verbroken · opnieuw proberen…', false);
    setTimeout(connect, retry); retry = Math.min(30000, retry*2); };
}

// (v33) IKEA-stekker 'pelletkachel': schakelaar + vermogen op naam zoeken als de standaardnamen niet bestaan
// (v49) Philips-tv slaapkamer (integratie Philips TV): Ambilight-lamp zoeken
const AMBI = {ent:null, on:false, rgb:[255,138,61]};
function detectAmbilight(states){
  const h = states.find(st=>st.entity_id.startsWith('light.') && /ambilight/i.test(st.entity_id+' '+((st.attributes||{}).friendly_name||'')) && !/hue/i.test(((st.attributes||{}).friendly_name||'')));
  if(!h) return; AMBI.ent = h.entity_id;
  on(h.entity_id, st=>{ AMBI.on = st.state==='on'; const a = st.attributes||{}; if(a.rgb_color) AMBI.rgb = a.rgb_color; });
}
function detectStove(states){
  const p = byId.woon.plugs.find(x=>x.name==='Pelletkachel'); if(!p) return;
  const ids = new Set(states.map(st=>st.entity_id)), nm = st => (st.entity_id+' '+((st.attributes||{}).friendly_name||'')).toLowerCase();
  if(!ids.has(p.sw)){ const h = states.find(st=>st.entity_id.startsWith('switch.') && /pellet/.test(nm(st))); if(h){ const old = p.sw; p.sw = h.entity_id; if(VEILIGHEIDSPOOL[old]) p.pool = VEILIGHEIDSPOOL[old]; on(p.sw, st=>{ p.on = st.state==='on'; }); } }
  if(!ids.has(p.pw)){ const h = states.find(st=>st.entity_id.startsWith('sensor.') && /pellet/.test(nm(st)) && /^k?W$/.test((st.attributes||{}).unit_of_measurement||'')); if(h){ p.pw = h.entity_id; on(p.pw, st=>{ p.w = num(st); }); } }
  console.info('Huis 3D · pelletkachel:', p.sw, p.pw);
}
// (v38) bewolking uit een weer-entiteit: cloud_coverage (%) of anders afgeleid van de toestand
// uurvoorspelling via weather.get_forecasts (Home Assistant 2023.9+)
async function loadForecast(){
  if(!ha || !WX.ent) return;
  try{
    const res = await ha.send({type:'call_service', domain:'weather', service:'get_forecasts', service_data:{type:'hourly'}, target:{entity_id:[WX.ent]}, return_response:true});
    const fc = (((res||{}).response||{})[WX.ent]||{}).forecast || [];
    if(fc.length){ WX.hourly = fc.map(f=>({t:Date.parse(f.datetime), temp:f.temperature, wind:f.wind_speed, bearing:f.wind_bearing, cloud: f.cloud_coverage!=null ? f.cloud_coverage/100 : null})).filter(f=>isFinite(f.t));
      const nowT = Date.now(); if(outside.temp!=null) WX.hourly.unshift({t:nowT-60e3, temp:outside.temp, wind:WX.now.wind, bearing:WX.now.bearing, cloud:sky.cloud});
      console.info('Huis 3D · voorspelling', WX.ent, WX.hourly.length, 'uur'); refreshSoon(); }
  }catch(err){ console.warn('voorspelling', err); }
}
function detectWeather(states){
  const w = states.find(st=>st.entity_id.startsWith('weather.') && (st.attributes||{}).cloud_coverage!=null) || states.find(st=>st.entity_id.startsWith('weather.'));
  if(!w) return;
  const COND = {'clear-night':0.05, sunny:0.05, partlycloudy:0.45, cloudy:0.9, fog:0.95, rainy:0.9, pouring:1, snowy:0.9, 'snowy-rainy':0.95, lightning:0.9, 'lightning-rainy':1, hail:0.95, windy:0.3, 'windy-variant':0.6, exceptional:0.8};
  WX.ent = w.entity_id;
  on(w.entity_id, st=>{ const a = st.attributes||{}; if(a.wind_speed!=null){ WX.now = {wind:+a.wind_speed, bearing:a.wind_bearing!=null ? +a.wind_bearing : null}; WX.unit = a.wind_speed_unit || WX.unit; WX.live = true; } });
  loadForecast(); setInterval(loadForecast, 30*60e3);
  on(w.entity_id, st=>{ const a = st.attributes||{}; const v = a.cloud_coverage!=null ? +a.cloud_coverage/100 : COND[st.state]; if(v==null || !isFinite(v)) return;
    sky.cloud = v; sky.liveCloud = true; const el = $('cloud'); if(el){ el.value = Math.round(v*100); el.disabled = true; } const lb = $('cloudlbl'); if(lb) lb.textContent = Math.round(v*100)+'% · live'; updateSky(); });
  console.info('Huis 3D · bewolking uit', w.entity_id);
}
// (v43) Omada: apparaten via het apparaatregister, PoE per poort via de naam 'Port N PoE power', clients = device_trackers van tplink_omada die thuis zijn
function detectOmada(states, reg, dreg){
  if(!reg || !dreg) return;
  const om = reg.filter(e=>e.platform==='tplink_omada'), byDev = new Map(), stById = new Map(states.map(st=>[st.entity_id, st]));
  const devName = new Map(dreg.map(d=>[d.id, d.name_by_user || d.name]));
  om.forEach(e=>{ const n = devName.get(e.device_id); if(!n) return; if(!byDev.has(n)) byDev.set(n, []); byDev.get(n).push(e.entity_id); });
  OMADA.live = true; OMADA.ports.forEach(p=>{ p.w = null; p.poe = null; p.link = false; });
  const RATE = {'bit/s':1e-6,'kbit/s':1e-3,'Kbit/s':1e-3,'Mbit/s':1,'Gbit/s':1000,'B/s':8e-6,'kB/s':8e-3,'KB/s':8e-3,'KiB/s':8.192e-3,'MB/s':8,'MiB/s':8.39};
  const bindRate = (d, id)=>{ const st0 = stById.get(id), a = (st0 && st0.attributes)||{}, fn = (a.friendly_name||id).toLowerCase(), f = RATE[a.unit_of_measurement];
    if(/cpu/.test(fn) && a.unit_of_measurement==='%'){ on(id, st=>{ d.cpu = num(st); }); return; }
    if(/client/.test(fn) && !/rate|mbit|bit\/s/.test(fn)){ on(id, st=>{ const v = num(st); if(v!=null){ d.clients = v; d.clientsLive = true; } }); return; }
    if(f==null) return; const key = /download|rx|receiv|ontvang/.test(fn) ? 'rx' : /upload|tx|transmit|verzond/.test(fn) ? 'tx' : null; if(!key) return;
    on(id, st=>{ const v = num(st); d[key] = v==null ? null : v*f; }); };
  OMADA.devices.forEach(d=>{ d.ents = byDev.get(d.name) || []; d.clients = null; d.update = false; d.ents.filter(id=>id.startsWith('sensor.')).forEach(id=>bindRate(d, id));
    const upd = ()=>{ const sts = d.ents.map(id=>stById.get(id)).filter(Boolean); d.online = !sts.length || sts.some(st=>st.state!=='unavailable');
      d.update = sts.some(st=>st.entity_id.startsWith('update.') && st.state==='on'); };
    d.ents.forEach(id=>on(id, st=>{ stById.set(id, st); upd(); })); upd(); });
  // (v67) doorvoer per AP uit eigen sensoren (bv. SNMP-poorttellers + 'Afgeleide'-helper): naam bevat de Omada-naam + download/upload
  { const byLen = [...OMADA.devices].sort((a,b)=>b.name.length-a.name.length), bound = new Set(OMADA.devices.flatMap(d=>d.ents||[]));
    states.forEach(st=>{ if(!st.entity_id.startsWith('sensor.') || bound.has(st.entity_id)) return; const a = st.attributes||{}; if(RATE[a.unit_of_measurement]==null) return;
      const fn = (a.friendly_name||'').toLowerCase().replace(/_/g,' '); if(!/download|upload/.test(fn)) return;
      const d = byLen.find(x=>fn.includes(x.name.toLowerCase().replace(/_/g,' '))); if(!d) return; bindRate(d, st.entity_id); d.rateEnts = (d.rateEnts||0)+1; });
    console.info('Huis 3D · AP-doorvoer:', OMADA.devices.filter(d=>d.rateEnts).map(d=>d.name+' ('+d.rateEnts+')').join(', ') || 'geen download/upload-sensoren gevonden'); }
  const sw = OMADA.devices.find(d=>d.kind==='switch');
  { const r = OMADA.devices.find(d=>d.kind==='router'); if(r) OMADA.wan = r; }   // (v45) WAN-doorvoer van de router als die er is
  (sw ? sw.ents : []).forEach(id=>{ const st = stById.get(id); const fn = ((st && st.attributes)||{}).friendly_name || id; const m = /port[ _]?(\d+)[ _]poe[ _]power/i.exec(fn) || /port_(\d+)_poe_power/.exec(id);
    if(m){ const p = OMADA.ports[+m[1]-1]; if(p) on(id, s2=>{ p.w = num(s2); p.link = p.link || (p.w>0); }); }
    const m2 = /port[ _]?(\d+)[ _]poe$/i.exec(fn); if(m2 && id.startsWith('switch.')){ const p = OMADA.ports[+m2[1]-1]; if(p) on(id, s2=>{ p.poe = s2.state==='on'; }); } });
  const trackers = om.filter(e=>e.entity_id.startsWith('device_tracker.')).map(e=>e.entity_id);
  const count = ()=>{ OMADA.clients = trackers.filter(id=>(stById.get(id)||{}).state==='home').length;
    const per = {}; trackers.forEach(id=>{ const a = ((stById.get(id)||{}).attributes)||{}; const ap = a.connected_to || a.ap_name || a.ap; if(ap && (stById.get(id)||{}).state==='home') per[ap] = (per[ap]||0)+1; });
    OMADA.devices.filter(d=>d.kind==='ap' && !d.clientsLive).forEach(d=>{ d.clients = per[d.name] ?? null; }); };
  trackers.forEach(id=>on(id, st=>{ stById.set(id, st); count(); })); count();
  OMADA.devices.forEach(d=>console.info('Huis 3D · Omada-sensoren', d.name+':', d.ents.filter(id=>id.startsWith('sensor.')).map(id=>{ const a = (stById.get(id)||{}).attributes||{}; return (a.friendly_name||id)+(a.unit_of_measurement?' ['+a.unit_of_measurement+']':''); }).join(' | ')));
  console.info('Huis 3D · Omada:', OMADA.devices.map(d=>d.name+'='+d.ents.length).join(', '), '· clients', trackers.length);
}
function detectOutside(states){
  if(ENT.out) return;
  const s = states.find(st=>/^sensor\.(flint_lp9|sn_0y95_422y).*buitentemp/.test(st.entity_id));
  if(s){ ENT.out = s.entity_id; on(s.entity_id, st=>{ outside.temp = num(st); }); }
  else { const w = states.find(st=>st.entity_id.startsWith('weather.')); if(w){ ENT.out = w.entity_id; on(w.entity_id, st=>{ const t = (st.attributes||{}).temperature; outside.temp = t==null ? null : +t; }); } }
  console.info('Huis 3D · buitentemperatuur:', ENT.out);
}
function detectLock(states){
  const locks = states.filter(st=>st.entity_id.startsWith('lock.'));
  if(!LOCK.ent){ const h = locks.find(st=>LOCK.match.test(st.entity_id) || LOCK.match.test((st.attributes||{}).friendly_name||'')) || (locks.length===1 ? locks[0] : null); if(h) LOCK.ent = h.entity_id; }
  if(LOCK.ent && !LOCK.bound){ LOCK.bound = true; on(LOCK.ent, st=>{ LOCK.state = st.state; }); }
  console.info('Huis 3D · slot:', LOCK.ent, '· alle locks:', locks.map(l=>l.entity_id).join(', '));
}
let extraATV = null;   // Apple TV die niet op naam gevonden werd (valt terug als de Sony op HDMI staat)
function detectMedia(states, reg){
  const players = states.filter(st=>st.entity_id.startsWith('media_player.'));
  // Apple TV's herkennen aan de integratie (apple_tv), niet alleen aan de naam
  const plat = new Map((reg||[]).map(e=>[e.entity_id, e.platform]));
  const atvs = players.filter(st=>plat.get(st.entity_id)==='apple_tv' || /apple/i.test(((st.attributes||{}).friendly_name||'')+st.entity_id));
  const nm = st => (st.entity_id+' '+((st.attributes||{}).friendly_name||'')).toLowerCase();
  if(!MEDIA.atvSlaap.ent){ const h = atvs.find(st=>/slaap|bed/.test(nm(st))); if(h) MEDIA.atvSlaap.ent = h.entity_id; }
  if(!MEDIA.atvWoon.ent){ const h = atvs.find(st=>/living|woon|lounge/.test(nm(st)) && st.entity_id!==MEDIA.atvSlaap.ent); if(h) MEDIA.atvWoon.ent = h.entity_id; }
  const rest = atvs.filter(st=>st.entity_id!==MEDIA.atvSlaap.ent && st.entity_id!==MEDIA.atvWoon.ent);
  if(rest.length===1){ if(!MEDIA.atvSlaap.ent && MEDIA.atvWoon.ent) MEDIA.atvSlaap.ent = rest[0].entity_id; else if(!MEDIA.atvWoon.ent && MEDIA.atvSlaap.ent) MEDIA.atvWoon.ent = rest[0].entity_id; }
  console.info('Huis 3D · Apple TV\'s:', atvs.map(st=>st.entity_id+' ('+((st.attributes||{}).friendly_name||'')+', '+st.state+')').join(', ') || 'geen');
  const remotes = states.filter(st=>st.entity_id.startsWith('remote.'));
  const hit = (list, m)=> list.find(st=> m.match.test(st.entity_id) || m.match.test((st.attributes||{}).friendly_name||''));
  const tv = MEDIA.tv, so = MEDIA.sonos;
  if(!tv.ent){ const h = hit(players, tv); if(h) tv.ent = h.entity_id; }
  if(!tv.remote){ const h = hit(remotes, tv); if(h) tv.remote = h.entity_id; }
  if(!so.ent){
    const pref = (so.prefer||[]).find(id=>players.some(p=>p.entity_id===id));
    const h = pref ? {entity_id:pref} : (hit(players, so) || players.find(p=>p.entity_id!==tv.ent && Array.isArray((p.attributes||{}).group_members)));
    if(h) so.ent = h.entity_id;
  }
  const used = new Set([tv.ent, so.ent]);
  Object.values(MEDIA).filter(m=>m.simple).forEach(m=>{ if(!m.ent && m.prefer){ const p = m.prefer.find(id=>players.some(x=>x.entity_id===id)); if(p) m.ent = p; }
    if(!m.ent){ const h = players.find(st=>!used.has(st.entity_id) && (m.match.test(st.entity_id) || m.match.test((st.attributes||{}).friendly_name||''))); if(h) m.ent = h.entity_id; } used.add(m.ent); });
  if(!MEDIA.atvWoon.ent){ const known = new Set(Object.values(MEDIA).map(m=>m.ent).filter(Boolean));
    const h = players.find(st=>!known.has(st.entity_id) && /apple|atv/i.test(st.entity_id+' '+((st.attributes||{}).friendly_name||'')+' '+((st.attributes||{}).device_class||'')));
    if(h){ extraATV = {ent:h.entity_id, state:h.state, a:h.attributes||{}}; on(h.entity_id, st=>{ extraATV.state = st.state; extraATV.a = st.attributes||{}; }); } }
  Object.values(MEDIA).forEach(m=>{ if(m.ent && !m.bound){ m.bound = true; on(m.ent, st=>{ m.state = st.state; m.a = st.attributes||{}; }); } });
  console.info('Huis 3D · tv:', tv.ent, tv.remote, '· speaker:', so.ent, '· overig:', Object.entries(MEDIA).filter(([,m])=>m.simple).map(([k,m])=>k+'='+m.ent).join(' '), '· alle media_players:', players.map(p=>p.entity_id).join(', '));
}
// temperatuurverloop van de laatste 24 uur uit de HA-geschiedenis
const histCache = {};
async function loadHistory(r){
  if(!LIVE || !ha || !r) return;
  const id = r.t || r.clim; if(!id) return;
  const c = histCache[r.id]; if(c && Date.now()-c.at < 600000){ r.hist = c.h; renderPanel(); return; }
  try{
    const start = new Date(Date.now() - 24*3600e3).toISOString();
    const res = await ha.send({type:'history/history_during_period', start_time:start, entity_ids:[id],
      minimal_response: !!r.t, no_attributes: !!r.t, significant_changes_only:false});
    const rows = (res && res[id]) || [];
    const pts = rows.map(p=>({t:(p.lu ?? p.lc)*1000, v: r.t ? parseFloat(p.s) : (p.a ? p.a.current_temperature : NaN)})).filter(p=>isFinite(p.v));
    if(!pts.length) return;
    const now = Date.now(), h = []; let last = pts[0].v, k = 0;
    for(let i=0;i<24;i++){ const end = now - (23-i)*3600e3; while(k<pts.length && pts[k].t<=end){ last = pts[k].v; k++; } h.push(+last.toFixed(2)); }
    r.hist = h; histCache[r.id] = {at:Date.now(), h}; if(selected===r) renderPanel();
  }catch(err){ console.warn('history', err); }
}

if(LIVE){
  // start zonder nepwaarden: alles leeg tot Home Assistant antwoordt
  rooms.forEach(r=>{ r.temp = null; r.hum = null; r.hist = null; if(r.sensor){ r.sensor.motion = false; r.sensor.lux = null; } });
  lampList.forEach(l=>{ l.on = false; if(!l.ha && l.status!=='nc'){ l.nc = true; l.status = 'nolink'; } else if(l.status==='broken'){ l.nc = false; l.status = null; } });
  Object.assign(energy, {pv:null, batt:null, battW:null, house:null, grid:null, pvToday:null, impToday:null, expToday:null});
  Object.values(MEDIA).forEach(m=>{ m.state = null; m.a = {}; }); LOCK.state = null;
  Object.values(HP).forEach(u=>Object.keys(u.v).forEach(k=>u.v[k]=null));
  Object.keys(BATTS).forEach(k=>delete BATTS[k]);
  rooms.forEach(r=>{ r.plugs.forEach(p=>{ p.on=false; p.w=null; }); if(r.ac){ r.ac.kwh=null; r.climState=null; } if(r.lampKwhEnt) r.lampKwh=null; }); Object.assign(starlink, {ok:false, ping:null, down:null, up:null}); Object.assign(outside, {temp:null, hum:null});
  buildIndex(); connect();
}

