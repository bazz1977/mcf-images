/* ---------- Simulatie ---------- */
function tick(){
  if(LIVE) return;   // live: alles komt uit Home Assistant
  rooms.forEach(r=>{
    if(r.hasT){ r.temp += (r.target - r.temp)*0.04 + (Math.random()-.5)*0.12; r.hist.push(+r.temp.toFixed(2)); r.hist.shift(); }
    if(r.hasH){ r.hum = Math.max(30, Math.min(85, r.hum + (Math.random()-.5)*1.2 + (55-r.hum)*0.02)); }
  });
  energy.pv = night ? 0 : Math.max(0, Math.min(PV_KWP, energy.pv + (Math.random()-.5)*0.4 || 3.4));
  energy.house = Math.round(650 + rooms.reduce((s,r)=>s+(roomW(r)||0),0) + lampList.filter(l=>l.on).length*6 + rooms.filter(r=>r.ac && r.climState!=='off').length*450 + (Math.random()-.5)*120);
  const pvW = energy.pv*1000;
  let bW = energy.house - pvW;                                   // + = ontladen
  bW = Math.max(-2500, Math.min(2500, bW));
  if(bW>0 && energy.batt<=6) bW = 0; if(bW<0 && energy.batt>=99.5) bW = 0;
  energy.battW = Math.round(bW); energy.grid = Math.round(energy.house - pvW - bW);
  energy.batt = Math.max(5, Math.min(100, energy.batt - bW/9000));
  energy.pvToday += pvW/1000*3/3600; if(energy.grid>0) energy.impToday += energy.grid/1000*3/3600; else energy.expToday += -energy.grid/1000*3/3600;
  rooms.forEach(r=>r.plugs.forEach(p=>{ if(p.on && p.base) p.w = Math.max(0, Math.round(p.base*(0.85+Math.random()*0.3))); if(p.on && /^Koelkast/.test(p.name)) p.w = Math.random()<0.5 ? 0 : 70+Math.round(Math.random()*20); }));
  rooms.forEach(r=>{ if(r.ac && r.climState!=='off') r.ac.kwh = +(r.ac.kwh + 0.0004).toFixed(3); });
  applyPV(); applyHP();
  starlink.ping = Math.max(18, Math.min(80, starlink.ping + (Math.random()-.5)*8));
  starlink.ping = Math.round(starlink.ping);
  starlink.down = Math.max(40, Math.min(300, starlink.down + (Math.random()-.5)*40));
  starlink.up = Math.max(5, Math.min(40, starlink.up + (Math.random()-.5)*4));
  if(battBar){ battBar.scale.y = Math.max(0.03, energy.batt/100); }
  if(goodweLed){ goodweLed.material.emissiveIntensity = energy.pv>0 ? 1.5 : 0.2; }
  const l9 = HP.lp9.v; if(Math.random()<0.08) l9.status = l9.status==='standby' ? (Math.random()<0.5 ? 'dhw' : 'heat') : 'standby';
  if(l9.status==='heat'){ l9.pin = 850+Math.round(Math.random()*120); l9.pout = Math.round(l9.pin*3.6); l9.cop = l9.pout/l9.pin; l9.comp = 45; } else if(l9.status==='dhw'){ l9.pin = 1400+Math.round(Math.random()*150); l9.pout = Math.round(l9.pin*2.9); l9.cop = l9.pout/l9.pin; l9.comp = 70; l9.sww = Math.min(55, l9.sww+0.3); } else { l9.pin = 12; l9.pout = 0; l9.cop = null; l9.comp = 0; l9.sww = Math.max(44, l9.sww-0.05); }
  { if(!l9.demoTap && Math.random() < 0.04) l9.demoTap = 12; if(l9.demoTap){ l9.demoTap--; l9.swwLow = Math.max(22, l9.swwLow - 1.2); if(l9.status==='dhw') l9.status = 'standby'; } else l9.swwLow = Math.min(46, l9.swwLow + 0.25); }   // (v46) demo: iemand neemt warm water
  const wm = byId.bad.plugs.find(p=>p.name==='Wasmachine'); if(wm){ wm.cycle = (wm.cycle||0)+1; wm.w = (wm.cycle % 90) < 40 ? 180+Math.round(Math.random()*1800*(Math.random()<.3)) : 1; }
  trackAppliances(); checkTap(); regenDemo();
  rooms.forEach(r=>{ if(!r.sensor) return;
    r.sensor.motion = Math.random() < 0.25;
    if(r.sensor.motion) r.sensor.lastMotion = Date.now();
    if(!r.sensor.auto){ r.sensor.lux = Math.round(r.lampObjs.some(l=>l.on) ? 150+Math.random()*30 : (night ? 1 : 30+Math.random()*20)); return; }
    const was = r.lampObjs.some(l=>l.on);   // zoals een Hue-automatisering: licht aan bij beweging, na een tijdje uit
    if(r.sensor.motion && !was){ r.lampObjs.forEach(l=>l.on=true); applyLamps(); }
    else if(!r.sensor.motion && was && Math.random()<0.3){ r.lampObjs.forEach(l=>l.on=false); applyLamps(); }
    r.sensor.lux = Math.round(r.lampObjs.some(l=>l.on) ? 180+Math.random()*20 : (night ? 1 : 25+Math.random()*10));
    r.sensor.ledMat.emissiveIntensity = r.sensor.motion ? 2 : 0; });
  outside.temp += (Math.random()-.5)*0.1;
  outside.hum = Math.max(60, Math.min(95, outside.hum + (Math.random()-.5)));
  applyColors(); updateLabels(); renderPanel();
}
setInterval(tick, 3000);
function clock(){ $('clock').textContent = new Date().toLocaleTimeString('nl-BE',{hour:'2-digit',minute:'2-digit'}); }
setInterval(clock, 10000); clock();


