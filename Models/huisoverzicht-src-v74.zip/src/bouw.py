#!/usr/bin/env python3
"""Huisoverzicht: bouwt index.html (Home Assistant, /config/www/huis/) uit sjabloon.html + de bronbestanden.
Gebruik:  python3 bouw.py            → ../index.html
Elke regel '{{bron:pad}}' in sjabloon.html wordt vervangen door de inhoud van dat bestand."""
import pathlib, re, sys
d = pathlib.Path(__file__).parent
t = (d/'sjabloon.html').read_text(encoding='utf-8')
out = re.sub(r'\{\{bron:([^}]+)\}\}\n', lambda m: (d/m.group(1)).read_text(encoding='utf-8'), t)
dst = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else d.parent/'index.html'
dst.write_text(out, encoding='utf-8'); print('geschreven:', dst, len(out), 'tekens')
